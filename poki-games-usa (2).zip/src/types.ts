export type GameCategory =
  | 'all'
  | 'girls'
  | 'racing'
  | 'action'
  | 'adventure'
  | 'two_player'
  | 'sports'
  | 'cooking'
  | 'puzzle'
  | 'classic';

export interface GameInfo {
  id: string;
  title: {
    ar: string;
    en: string;
  };
  description: {
    ar: string;
    en: string;
  };
  category: GameCategory;
  thumbnailGradient: string;
  accentColor: string;
  iconName?: string;
  bannerEmoji?: string;
  imageUrl?: string;
  videoUrl?: string;
  tileSize?: 'standard' | 'large' | 'wide' | 'tall';
  badge?: {
    ar: string;
    en: string;
    type: 'popular' | 'new' | 'classic' | 'hot' | 'top';
  };
  rating: number;
  playsCount: number;
  difficulty: 'easy' | 'medium' | 'hard';
  controls: {
    keyboard: string[];
    touch: string;
  };
  tags: string[];
  isFeatured?: boolean;
  iframeUrl?: string;
}

export interface PlayerStats {
  totalPlays: number;
  highScores: Record<string, number>;
  favorites: string[];
  likedGames: string[];
  recentGames: string[];
}

export interface Achievement {
  id: string;
  title: {
    ar: string;
    en: string;
  };
  description: {
    ar: string;
    en: string;
  };
  icon: string;
  category: 'plays' | 'score' | 'mastery';
  tier: 'bronze' | 'silver' | 'gold' | 'platinum';
  getTierColor?: string;
  checkProgress: (stats: PlayerStats) => {
    unlocked: boolean;
    current: number;
    target: number;
  };
}

export interface CustomGameSnippet {
  id: string;
  title: string;
  html: string;
  css: string;
  js: string;
  createdAt: number;
}
