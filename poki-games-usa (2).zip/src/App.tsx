/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import { GAMES_DATA } from './data/gamesData';
import { GameInfo, GameCategory, PlayerStats } from './types';
import { Header } from './components/Header';
import { GameCategoryTabs } from './components/GameCategoryTabs';
import { GameCard } from './components/GameCard';
import { GameModal } from './components/GameModal';
import { CodePlaygroundModal } from './components/CodePlaygroundModal';
import { StatsDrawer } from './components/StatsDrawer';
import { Footer } from './components/Footer';
import { sounds } from './utils/audio';
import { ACHIEVEMENTS_DATA } from './data/achievementsData';
import { CATEGORY_THEMES } from './utils/categoryThemes';
import { Sparkles, Award, CheckCircle2 } from 'lucide-react';


const STATS_STORAGE_KEY = 'gamezone_player_stats_v1';
const UNLOCKED_ACHIEVEMENTS_KEY = 'gamezone_unlocked_achievements_v1';

export default function App() {
  const [lang, setLang] = useState<'ar' | 'en'>('en');
  const [isMuted, setIsMuted] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<GameCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeGame, setActiveGame] = useState<GameInfo | null>(null);
  const [isPlaygroundOpen, setIsPlaygroundOpen] = useState(false);
  const [isStatsOpen, setIsStatsOpen] = useState(false);
  const [showOnlyFavorites, setShowOnlyFavorites] = useState(false);
  const [badgeToast, setBadgeToast] = useState<{ title: string; desc: string; icon: string; tier: string } | null>(null);

  // Persistent Player Stats
  const [stats, setStats] = useState<PlayerStats>(() => {
    try {
      const saved = localStorage.getItem(STATS_STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch {
      // fallback
    }
    return {
      totalPlays: 0,
      highScores: {
        'gamemonetize-rush': 3200,
        'gamezop-hero': 2400,
        'racing-limits': 1850,
        snake: 120,
        'car-runner': 150,
        tictactoe: 300,
        'brick-breaker': 450,
        'memory-match': 800,
        'flappy-bird': 7,
        'game-2048': 1024,
        'space-shooter': 340,
        'speed-math': 180,
        pong: 250,
        'color-match': 15,
      },
      favorites: ['gamemonetize-rush', 'gamezop-hero', 'racing-limits'],
      likedGames: [],
      recentGames: [],
    };
  });

  // Track unlocked achievement IDs
  const [knownUnlockedIds, setKnownUnlockedIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(UNLOCKED_ACHIEVEMENTS_KEY);
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return [];
  });

  // Save to localStorage whenever stats change
  useEffect(() => {
    try {
      localStorage.setItem(STATS_STORAGE_KEY, JSON.stringify(stats));
    } catch {
      // ignore
    }

    // Check for newly unlocked achievements
    const currentUnlocked = ACHIEVEMENTS_DATA.filter((ach) => ach.checkProgress(stats).unlocked);
    const newUnlocks = currentUnlocked.filter((ach) => !knownUnlockedIds.includes(ach.id));

    if (newUnlocks.length > 0 && knownUnlockedIds.length > 0) {
      const latest = newUnlocks[0];
      setBadgeToast({
        title: latest.title[lang],
        desc: latest.description[lang],
        icon: latest.icon,
        tier: latest.tier,
      });
      sounds.playBadgeEarned();

      const updatedIds = [...knownUnlockedIds, ...newUnlocks.map((u) => u.id)];
      setKnownUnlockedIds(updatedIds);
      try {
        localStorage.setItem(UNLOCKED_ACHIEVEMENTS_KEY, JSON.stringify(updatedIds));
      } catch {
        // ignore
      }

      const timer = setTimeout(() => {
        setBadgeToast(null);
      }, 5000);
      return () => clearTimeout(timer);
    } else if (knownUnlockedIds.length === 0 && currentUnlocked.length > 0) {
      const initialIds = currentUnlocked.map((u) => u.id);
      setKnownUnlockedIds(initialIds);
      try {
        localStorage.setItem(UNLOCKED_ACHIEVEMENTS_KEY, JSON.stringify(initialIds));
      } catch {
        // ignore
      }
    }
  }, [stats, lang, knownUnlockedIds]);

  useEffect(() => {
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [lang]);

  const handleToggleFavorite = (gameId: string) => {
    setStats((prev) => {
      const isFav = prev.favorites.includes(gameId);
      const newFavs = isFav ? prev.favorites.filter((id) => id !== gameId) : [...prev.favorites, gameId];
      return { ...prev, favorites: newFavs };
    });
  };

  const handleRecordScore = (gameId: string, newScore: number) => {
    setStats((prev) => {
      const prevHigh = prev.highScores[gameId] || 0;
      if (newScore > prevHigh) {
        return {
          ...prev,
          highScores: { ...prev.highScores, [gameId]: newScore },
        };
      }
      return prev;
    });
  };

  const handlePlayGame = (game: GameInfo) => {
    setActiveGame(game);
    setStats((prev) => ({
      ...prev,
      totalPlays: prev.totalPlays + 1,
      recentGames: [game.id, ...prev.recentGames.filter((id) => id !== game.id)].slice(0, 5),
    }));
  };

  const handleResetStats = () => {
    setStats({
      totalPlays: 0,
      highScores: {},
      favorites: [],
      likedGames: [],
      recentGames: [],
    });
  };

  // Filtered games
  const filteredGames = useMemo(() => {
    return GAMES_DATA.filter((game) => {
      if (selectedCategory !== 'all' && game.category !== selectedCategory) {
        return false;
      }
      if (showOnlyFavorites && !stats.favorites.includes(game.id)) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const titleAr = game.title.ar.toLowerCase();
        const titleEn = game.title.en.toLowerCase();
        const descAr = game.description.ar.toLowerCase();
        const descEn = game.description.en.toLowerCase();
        const tagsMatch = game.tags.some((t) => t.toLowerCase().includes(q));

        if (!titleAr.includes(q) && !titleEn.includes(q) && !descAr.includes(q) && !descEn.includes(q) && !tagsMatch) {
          return false;
        }
      }
      return true;
    });
  }, [selectedCategory, showOnlyFavorites, searchQuery, stats.favorites]);

  const categoryCounts = useMemo(() => {
    const counts: Partial<Record<GameCategory, number>> & { all: number } = {
      all: GAMES_DATA.length,
    };
    GAMES_DATA.forEach((g) => {
      counts[g.category] = (counts[g.category] || 0) + 1;
    });
    return counts as Record<GameCategory, number>;
  }, []);

  const currentTheme = CATEGORY_THEMES[selectedCategory] || CATEGORY_THEMES.all;

  return (
    <div
      className={`min-h-screen flex flex-col font-['Plus_Jakarta_Sans',sans-serif] transition-colors duration-500 ${currentTheme.textColor}`}
      style={{
        backgroundColor: currentTheme.pageBg,
        backgroundImage: currentTheme.pageRadial,
      }}
    >
      {/* Header */}
      <Header
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        selectedCategory={selectedCategory}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-3 sm:px-6 lg:px-8 pt-5 sm:pt-7">
        {/* Categories Bar */}
        <section className="mb-5">
          <GameCategoryTabs
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
            categoryCounts={categoryCounts}
            lang={lang}
          />
        </section>

        {/* Dynamic Category Hero Badge & Tagline */}
        <section className="mb-6">
          <div
            className={`p-3.5 sm:p-4 rounded-2xl sm:rounded-3xl border backdrop-blur-md flex items-center justify-between gap-3 transition-all duration-300 shadow-sm ${
              currentTheme.isDarkTheme
                ? 'bg-zinc-900/80 border-zinc-800'
                : 'bg-white/70 border-white/80'
            }`}
          >
            <div className="flex items-center gap-3">
              <div
                className={`w-10 h-10 sm:w-12 sm:h-12 rounded-2xl flex items-center justify-center text-xl sm:text-2xl shadow-md ${
                  currentTheme.isDarkTheme ? 'bg-zinc-800 ring-1 ring-red-500/40' : 'bg-white shadow-sm ring-1 ring-black/5'
                }`}
              >
                <span>{currentTheme.emoji}</span>
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className={`font-black text-sm sm:text-base tracking-tight ${currentTheme.isDarkTheme ? 'text-white' : 'text-slate-900'}`}>
                    {currentTheme.label[lang]}
                  </h2>
                  <span
                    className={`text-[11px] font-black px-2 py-0.5 rounded-full ${
                      currentTheme.isDarkTheme
                        ? 'bg-red-500/20 text-red-400 border border-red-500/30'
                        : 'bg-black/5 text-slate-700'
                    }`}
                  >
                    {filteredGames.length} {lang === 'ar' ? 'لعبة' : 'games'}
                  </span>
                </div>
                <p className={`text-xs mt-0.5 line-clamp-1 ${currentTheme.isDarkTheme ? 'text-zinc-400' : 'text-slate-600'}`}>
                  {currentTheme.tagline[lang]}
                </p>
              </div>
            </div>

            {selectedCategory !== 'all' && (
              <button
                onClick={() => setSelectedCategory('all')}
                className={`text-xs font-bold px-3 py-1.5 rounded-xl border transition-all cursor-pointer whitespace-nowrap active:scale-95 ${
                  currentTheme.isDarkTheme
                    ? 'bg-zinc-800 hover:bg-zinc-700 border-zinc-700 text-zinc-300'
                    : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-700'
                }`}
              >
                {lang === 'ar' ? 'عرض الكل 🕹️' : 'All Games 🕹️'}
              </button>
            )}
          </div>
        </section>

        {/* Poki-Style Uniform Grid */}
        {filteredGames.length > 0 ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
            {filteredGames.map((game) => (
              <GameCard
                key={game.id}
                game={game}
                onPlay={handlePlayGame}
                lang={lang}
              />
            ))}
          </div>
        ) : (
          <div className={`p-12 text-center rounded-3xl border my-8 space-y-4 shadow-2xl ${
            currentTheme.isDarkTheme
              ? 'bg-zinc-900/90 border-zinc-800 text-zinc-200'
              : 'bg-white/80 border-slate-200 text-slate-800'
          }`}>
            <div className="w-16 h-16 mx-auto rounded-3xl bg-slate-800/10 flex items-center justify-center text-3xl">
              🔍
            </div>
            <p className="text-sm font-bold">
              {lang === 'ar' ? 'لم يتم العثور على ألعاب مطابقة' : 'No games found'}
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedCategory('all');
                setShowOnlyFavorites(false);
              }}
              className={`px-6 py-2.5 rounded-2xl text-xs font-black shadow-lg cursor-pointer transition-all active:scale-95 ${
                currentTheme.isDarkTheme
                  ? 'bg-red-600 hover:bg-red-500 text-white shadow-red-600/30'
                  : 'bg-purple-600 hover:bg-purple-500 text-white shadow-purple-600/30'
              }`}
            >
              {lang === 'ar' ? 'إظهار جميع الألعاب' : 'Show All'}
            </button>
          </div>
        )}
      </main>


      {/* Footer */}
      <Footer lang={lang} selectedCategory={selectedCategory} />

      {/* Poki Game Playing Modal */}
      {activeGame && (
        <GameModal
          game={activeGame}
          onClose={() => setActiveGame(null)}
          highScore={stats.highScores[activeGame.id] || 0}
          onRecordScore={handleRecordScore}
          onSelectAnotherGame={(anotherGame) => setActiveGame(anotherGame)}
          lang={lang}
        />
      )}

      {/* Developer HTML/JS Sandbox Modal */}
      <CodePlaygroundModal
        isOpen={isPlaygroundOpen}
        onClose={() => setIsPlaygroundOpen(false)}
        lang={lang}
      />

      {/* Player Stats & Achievements Drawer */}
      <StatsDrawer
        isOpen={isStatsOpen}
        onClose={() => setIsStatsOpen(false)}
        stats={stats}
        onPlayGame={handlePlayGame}
        onResetStats={handleResetStats}
        lang={lang}
      />

      {/* Achievement Unlocked Toast Notification */}
      {badgeToast && (
        <div className="fixed bottom-6 right-6 left-6 sm:left-auto sm:w-96 z-50 animate-bounce-short select-none">
          <div
            onClick={() => {
              sounds.playClick();
              setIsStatsOpen(true);
              setBadgeToast(null);
            }}
            className="p-4 rounded-3xl bg-slate-900/95 border-2 border-amber-400/80 shadow-2xl backdrop-blur-2xl flex items-center gap-3.5 cursor-pointer hover:scale-105 transition-all group ring-4 ring-amber-400/20"
          >
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-400/50 flex items-center justify-center text-2xl shadow-lg shrink-0 group-hover:rotate-12 transition-transform">
              {badgeToast.icon}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-1.5 text-xs font-black text-amber-300">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>{lang === 'ar' ? 'تم فتح إنجاز جديد! 🎉' : 'Achievement Unlocked! 🎉'}</span>
              </div>
              <h4 className="text-sm font-black text-white truncate">{badgeToast.title}</h4>
              <p className="text-[11px] text-slate-300 truncate">{badgeToast.desc}</p>
            </div>
            <button
              onClick={(e) => {
                e.stopPropagation();
                setBadgeToast(null);
              }}
              className="p-1 text-slate-400 hover:text-white rounded-lg hover:bg-white/10"
            >
              ✕
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
