import React, { useState, useEffect, useRef } from 'react';
import { X, Play, RotateCcw, Copy, Check, Code, Sparkles, FileCode, Layers, Terminal } from 'lucide-react';
import { DEFAULT_SNIPPETS } from '../data/gamesData';
import { sounds } from '../utils/audio';

interface CodePlaygroundModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang?: 'ar' | 'en';
}

export const CodePlaygroundModal: React.FC<CodePlaygroundModalProps> = ({
  isOpen,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'html' | 'css' | 'js'>('html');
  const [htmlCode, setHtmlCode] = useState(DEFAULT_SNIPPETS[0].html);
  const [cssCode, setCssCode] = useState(DEFAULT_SNIPPETS[0].css);
  const [jsCode, setJsCode] = useState(DEFAULT_SNIPPETS[0].js);
  const [iframeSrcDoc, setIframeSrcDoc] = useState('');
  const [copied, setCopied] = useState(false);

  const iframeRef = useRef<HTMLIFrameElement | null>(null);

  const runCode = () => {
    sounds.playClick();
    const fullHtml = '<!DOCTYPE html>\n' +
      '<html lang="en">\n' +
      '<head>\n' +
      '  <meta charset="UTF-8">\n' +
      '  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n' +
      '  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;700;900&display=swap" rel="stylesheet">\n' +
      '  <style>\n' +
      '    body {\n' +
      '      margin: 0;\n' +
      '      padding: 15px;\n' +
      '      background: #090d16;\n' +
      '      color: #f1f5f9;\n' +
      '      font-family: "Plus Jakarta Sans", sans-serif;\n' +
      '      display: flex;\n' +
      '      flex-direction: column;\n' +
      '      align-items: center;\n' +
      '      justify-content: center;\n' +
      '      min-height: 90vh;\n' +
      '      overflow-x: hidden;\n' +
      '    }\n' +
      '    ' + cssCode + '\n' +
      '  </style>\n' +
      '</head>\n' +
      '<body>\n' +
      '  ' + htmlCode + '\n' +
      '  <' + 'script>\n' +
      '    try {\n' +
      '      ' + jsCode + '\n' +
      '    } catch(err) {\n' +
      '      console.error(err);\n' +
      '      const errDiv = document.createElement("div");\n' +
      '      errDiv.style.color = "#ef4444";\n' +
      '      errDiv.style.padding = "10px";\n' +
      '      errDiv.style.background = "rgba(239,68,68,0.1)";\n' +
      '      errDiv.style.borderRadius = "8px";\n' +
      '      errDiv.style.marginTop = "10px";\n' +
      '      errDiv.textContent = "Script Error: " + err.message;\n' +
      '      document.body.appendChild(errDiv);\n' +
      '    }\n' +
      '  <' + '/script>\n' +
      '</body>\n' +
      '</html>';

    setIframeSrcDoc(fullHtml);
  };

  useEffect(() => {
    if (isOpen) {
      runCode();
    }
  }, [isOpen]);

  const copyFullCode = () => {
    const full = `<!-- HTML -->\n${htmlCode}\n\n/* CSS */\n${cssCode}\n\n// JS\n${jsCode}`;
    navigator.clipboard?.writeText(full);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/70 backdrop-blur-xl animate-fade-in">
      <div className="relative w-full max-w-6xl h-[92vh] rounded-3xl bg-[#0a0a0c]/95 border border-white/10 shadow-2xl flex flex-col overflow-hidden backdrop-blur-2xl">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/10 bg-black/40 backdrop-blur-xl">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/30 border border-white/10">
              <Code className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-white text-lg flex items-center gap-2">
                HTML5 Game Code Sandbox
              </h3>
              <p className="text-xs text-slate-400">
                Write, modify, or test custom mini-game source code in real-time
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={runCode}
              className="px-5 py-2.5 rounded-2xl bg-white hover:bg-indigo-50 text-black font-black text-xs sm:text-sm shadow-xl flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
            >
              <Play className="w-4 h-4 fill-black text-black" />
              RUN CODE
            </button>

            <button
              onClick={copyFullCode}
              className="p-2.5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white backdrop-blur-md transition-all text-xs cursor-pointer"
              title="Copy all code"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            </button>

            <button
              onClick={onClose}
              className="p-2.5 rounded-2xl bg-white/5 hover:bg-red-500/20 hover:text-red-400 hover:border-red-500/30 border border-white/10 text-slate-300 transition-all cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Workspace Body: Left Editor Tabs + Right Live Preview */}
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 divide-y lg:divide-y-0 lg:divide-x divide-white/10 overflow-hidden">
          {/* Editor Side */}
          <div className="flex flex-col h-full bg-black/40 backdrop-blur-md">
            {/* Editor Tabs */}
            <div className="flex items-center justify-between px-4 py-2.5 border-b border-white/10 bg-white/5">
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setActiveTab('html')}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    activeTab === 'html' ? 'bg-orange-500/20 text-orange-400 border border-orange-500/40' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <FileCode className="w-3.5 h-3.5" />
                  HTML
                </button>
                <button
                  onClick={() => setActiveTab('css')}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    activeTab === 'css' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/40' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" />
                  CSS
                </button>
                <button
                  onClick={() => setActiveTab('js')}
                  className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
                    activeTab === 'js' ? 'bg-yellow-500/20 text-yellow-400 border border-yellow-500/40' : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <Terminal className="w-3.5 h-3.5" />
                  JavaScript
                </button>
              </div>

              <span className="text-[11px] text-slate-400 font-mono font-bold">
                {activeTab.toUpperCase()} Editor
              </span>
            </div>

            {/* Textarea Code Input */}
            <div className="flex-1 p-3 relative">
              {activeTab === 'html' && (
                <textarea
                  value={htmlCode}
                  onChange={(e) => setHtmlCode(e.target.value)}
                  placeholder="<!-- Insert HTML markup here -->"
                  className="w-full h-full p-4 rounded-2xl bg-white/5 border border-white/10 text-slate-100 font-mono text-xs sm:text-sm focus:outline-none focus:border-indigo-400 resize-none"
                  spellCheck={false}
                />
              )}
              {activeTab === 'css' && (
                <textarea
                  value={cssCode}
                  onChange={(e) => setCssCode(e.target.value)}
                  placeholder="/* Insert CSS styles and colors here */"
                  className="w-full h-full p-4 rounded-2xl bg-white/5 border border-white/10 text-slate-100 font-mono text-xs sm:text-sm focus:outline-none focus:border-indigo-400 resize-none"
                  spellCheck={false}
                />
              )}
              {activeTab === 'js' && (
                <textarea
                  value={jsCode}
                  onChange={(e) => setJsCode(e.target.value)}
                  placeholder="// Insert JavaScript game logic and controls here"
                  className="w-full h-full p-4 rounded-2xl bg-white/5 border border-white/10 text-slate-100 font-mono text-xs sm:text-sm focus:outline-none focus:border-indigo-400 resize-none"
                  spellCheck={false}
                />
              )}
            </div>
          </div>

          {/* Live Preview Side */}
          <div className="flex flex-col h-full bg-black/20 backdrop-blur-md">
            <div className="px-4 py-2.5 border-b border-white/10 bg-white/5 flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                Live Sandboxed Preview
              </span>
              <button
                onClick={runCode}
                className="text-xs text-indigo-300 hover:text-white flex items-center gap-1 cursor-pointer font-semibold"
              >
                <RotateCcw className="w-3 h-3" />
                Reload
              </button>
            </div>

            <div className="flex-1 p-3">
              <iframe
                ref={iframeRef}
                title="Sandbox Preview"
                srcDoc={iframeSrcDoc}
                sandbox="allow-scripts allow-modals"
                className="w-full h-full rounded-2xl border border-white/10 bg-[#0a0a0c]"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
