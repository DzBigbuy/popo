import React, { useState } from 'react';
import {
  X,
  Trophy,
  Flame,
  Heart,
  Sparkles,
  Award,
  Star,
  Gamepad2,
  RotateCcw,
  Medal,
  CheckCircle2,
  Lock,
  Play,
  Filter,
} from 'lucide-react';
import { GAMES_DATA } from '../data/gamesData';
import { ACHIEVEMENTS_DATA } from '../data/achievementsData';
import { PlayerStats, GameInfo, Achievement } from '../types';
import { sounds } from '../utils/audio';

interface StatsDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  stats: PlayerStats;
  onPlayGame: (game: GameInfo) => void;
  onResetStats: () => void;
  lang?: 'ar' | 'en';
}

const TIER_STYLES = {
  bronze: {
    bg: 'bg-amber-950/40',
    border: 'border-amber-700/50',
    badge: 'bg-amber-800/40 text-amber-300 border-amber-600/50',
    glow: 'from-amber-700/20 to-amber-900/10',
    label: { ar: 'برونزي', en: 'Bronze' },
  },
  silver: {
    bg: 'bg-slate-800/40',
    border: 'border-slate-400/50',
    badge: 'bg-slate-500/30 text-slate-200 border-slate-400/50',
    glow: 'from-slate-400/20 to-slate-600/10',
    label: { ar: 'فضي', en: 'Silver' },
  },
  gold: {
    bg: 'bg-yellow-950/40',
    border: 'border-yellow-500/50',
    badge: 'bg-yellow-500/20 text-yellow-300 border-yellow-400/50',
    glow: 'from-yellow-500/20 to-amber-600/10',
    label: { ar: 'ذهبي', en: 'Gold' },
  },
  platinum: {
    bg: 'bg-indigo-950/40',
    border: 'border-cyan-400/50',
    badge: 'bg-cyan-500/20 text-cyan-300 border-cyan-400/50',
    glow: 'from-cyan-500/20 to-indigo-600/10',
    label: { ar: 'بلاتيني', en: 'Platinum' },
  },
};

export const StatsDrawer: React.FC<StatsDrawerProps> = ({
  isOpen,
  onClose,
  stats,
  onPlayGame,
  onResetStats,
  lang = 'en',
}) => {
  const [activeTab, setActiveTab] = useState<'records' | 'achievements'>('achievements');
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'plays' | 'score' | 'mastery'>('all');
  const [showUnlockedOnly, setShowUnlockedOnly] = useState(false);

  if (!isOpen) return null;

  const playedGamesCount = Object.keys(stats.highScores || {}).length;

  // Process achievements with stats
  const achievementsWithStatus = ACHIEVEMENTS_DATA.map((ach) => {
    const progress = ach.checkProgress(stats);
    return {
      ...ach,
      progress,
    };
  });

  const unlockedCount = achievementsWithStatus.filter((a) => a.progress.unlocked).length;
  const totalAchievements = ACHIEVEMENTS_DATA.length;
  const completionPercentage = Math.round((unlockedCount / totalAchievements) * 100);

  // Filtered achievements
  const filteredAchievements = achievementsWithStatus.filter((a) => {
    if (categoryFilter !== 'all' && a.category !== categoryFilter) return false;
    if (showUnlockedOnly && !a.progress.unlocked) return false;
    return true;
  });

  // Tiers breakdown
  const tierCounts = {
    bronze: achievementsWithStatus.filter((a) => a.tier === 'bronze' && a.progress.unlocked).length,
    silver: achievementsWithStatus.filter((a) => a.tier === 'silver' && a.progress.unlocked).length,
    gold: achievementsWithStatus.filter((a) => a.tier === 'gold' && a.progress.unlocked).length,
    platinum: achievementsWithStatus.filter((a) => a.tier === 'platinum' && a.progress.unlocked).length,
  };

  const handleFindGame = (achievementId: string) => {
    const gameMap: Record<string, string> = {
      'snake-charmer': 'snake',
      'galaxy-hero': 'space-shooter',
      'brick-demolisher': 'brick-breaker',
      'puzzle-prodigy': 'game-2048',
      'sky-aviator': 'flappy-bird',
      'lightning-brain': 'speed-math',
      'ping-pong-champ': 'pong',
      'memory-master': 'memory-match',
    };

    const targetGameId = gameMap[achievementId];
    if (targetGameId) {
      const targetGame = GAMES_DATA.find((g) => g.id === targetGameId);
      if (targetGame) {
        sounds.playCoin();
        onClose();
        onPlayGame(targetGame);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/70 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-lg h-full bg-[#0a0a0c]/95 border-l border-white/10 shadow-2xl flex flex-col p-5 sm:p-6 overflow-y-auto backdrop-blur-2xl">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Trophy className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-black text-white text-lg">
                Player Hub & Badges
              </h3>
              <p className="text-xs text-slate-400">
                Track unlocked achievements, records & stats
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2.5 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 transition-all cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Switcher */}
        <div className="grid grid-cols-2 gap-2 mt-4 p-1 rounded-2xl bg-white/5 border border-white/10">
          <button
            id="stats-tab-achievements"
            onClick={() => {
              sounds.playClick();
              setActiveTab('achievements');
            }}
            className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-black flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeTab === 'achievements'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Medal className="w-4 h-4" />
            <span>Badges</span>
            <span className="px-2 py-0.5 rounded-full text-[10px] bg-white/20 text-white font-mono font-bold">
              {unlockedCount}/{totalAchievements}
            </span>
          </button>

          <button
            id="stats-tab-records"
            onClick={() => {
              sounds.playClick();
              setActiveTab('records');
            }}
            className={`py-2.5 px-3 rounded-xl text-xs sm:text-sm font-black flex items-center justify-center gap-2 transition-all cursor-pointer ${
              activeTab === 'records'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Trophy className="w-4 h-4" />
            <span>High Scores</span>
          </button>
        </div>

        {/* TAB 1: ACHIEVEMENTS VIEW */}
        {activeTab === 'achievements' && (
          <div className="flex-1 space-y-4 mt-4 overflow-y-auto pr-1">
            {/* Progress Card Banner */}
            <div className="p-5 rounded-3xl bg-gradient-to-br from-indigo-950/60 via-purple-950/40 to-black/60 border border-indigo-500/30 backdrop-blur-md relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl pointer-events-none" />

              <div className="flex items-center justify-between gap-4 mb-3">
                <div>
                  <div className="text-xs text-indigo-300 font-bold uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    Achievements Milestone
                  </div>
                  <div className="text-2xl font-black text-white mt-0.5">
                    {unlockedCount} <span className="text-sm font-normal text-slate-400">/ {totalAchievements} Unlocked</span>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-2xl font-black text-indigo-400 font-mono">
                    {completionPercentage}%
                  </div>
                  <div className="text-[10px] text-slate-400 font-semibold">Total Progress</div>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="w-full h-2.5 rounded-full bg-white/10 overflow-hidden border border-white/10">
                <div
                  className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-amber-400 rounded-full transition-all duration-500 shadow-lg shadow-indigo-500/50"
                  style={{ width: `${completionPercentage}%` }}
                />
              </div>

              {/* Tiers summary pills */}
              <div className="grid grid-cols-4 gap-2 pt-3 mt-3 border-t border-white/10 text-center">
                <div className="p-1.5 rounded-xl bg-amber-900/20 border border-amber-700/30 text-amber-300">
                  <div className="text-[10px] font-bold">Bronze</div>
                  <div className="text-xs font-bold font-mono">{tierCounts.bronze}</div>
                </div>
                <div className="p-1.5 rounded-xl bg-slate-800/40 border border-slate-500/30 text-slate-200">
                  <div className="text-[10px] font-bold">Silver</div>
                  <div className="text-xs font-bold font-mono">{tierCounts.silver}</div>
                </div>
                <div className="p-1.5 rounded-xl bg-yellow-900/20 border border-yellow-500/30 text-yellow-300">
                  <div className="text-[10px] font-bold">Gold</div>
                  <div className="text-xs font-bold font-mono">{tierCounts.gold}</div>
                </div>
                <div className="p-1.5 rounded-xl bg-cyan-900/20 border border-cyan-400/30 text-cyan-300">
                  <div className="text-[10px] font-bold">Platinum</div>
                  <div className="text-xs font-bold font-mono">{tierCounts.platinum}</div>
                </div>
              </div>
            </div>

            {/* Filter controls */}
            <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
              <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
                {(['all', 'plays', 'score', 'mastery'] as const).map((cat) => (
                  <button
                    key={cat}
                    onClick={() => {
                      sounds.playClick();
                      setCategoryFilter(cat);
                    }}
                    className={`px-3 py-1.5 rounded-xl font-bold transition-all text-xs cursor-pointer ${
                      categoryFilter === cat
                        ? 'bg-white text-black shadow-md'
                        : 'bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white border border-white/10'
                    }`}
                  >
                    {cat === 'all' && 'All'}
                    {cat === 'plays' && 'Plays'}
                    {cat === 'score' && 'Scores'}
                    {cat === 'mastery' && 'Mastery'}
                  </button>
                ))}
              </div>

              <button
                onClick={() => {
                  sounds.playClick();
                  setShowUnlockedOnly((prev) => !prev);
                }}
                className={`text-[11px] font-bold px-2.5 py-1.5 rounded-xl border transition-all cursor-pointer flex items-center gap-1 ${
                  showUnlockedOnly
                    ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                    : 'bg-white/5 border-white/10 text-slate-400 hover:text-slate-200'
                }`}
              >
                <CheckCircle2 className="w-3 h-3" />
                <span>Unlocked only</span>
              </button>
            </div>

            {/* Achievements List Cards */}
            <div className="space-y-2.5">
              {filteredAchievements.map((ach) => {
                const tierStyle = TIER_STYLES[ach.tier];
                const isUnlocked = ach.progress.unlocked;
                const percent = Math.min(100, Math.round((ach.progress.current / ach.progress.target) * 100));

                return (
                  <div
                    key={ach.id}
                    className={`relative p-3.5 rounded-2xl border transition-all backdrop-blur-md overflow-hidden ${
                      isUnlocked
                        ? `${tierStyle.bg} ${tierStyle.border} shadow-lg shadow-black/30`
                        : 'bg-white/5 border-white/10 opacity-75 hover:opacity-100'
                    }`}
                  >
                    {/* Glowing ambient for unlocked */}
                    {isUnlocked && (
                      <div
                        className={`absolute -right-6 -bottom-6 w-24 h-24 rounded-full bg-gradient-to-br ${tierStyle.glow} blur-xl pointer-events-none`}
                      />
                    )}

                    <div className="relative z-10 flex items-start gap-3">
                      {/* Badge Icon Container */}
                      <div
                        className={`w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shrink-0 border shadow-inner ${
                          isUnlocked
                            ? `${tierStyle.badge} shadow-lg animate-pulse-slow`
                            : 'bg-black/40 text-slate-500 border-white/10'
                        }`}
                      >
                        {isUnlocked ? ach.icon : <Lock className="w-5 h-5 text-slate-500" />}
                      </div>

                      {/* Content */}
                      <div className="flex-1 min-w-0 space-y-1">
                        <div className="flex items-center justify-between gap-1">
                          <div className="flex items-center gap-1.5 truncate">
                            <h4 className={`text-xs sm:text-sm font-black truncate ${isUnlocked ? 'text-white' : 'text-slate-300'}`}>
                              {ach.title.en}
                            </h4>
                            <span
                              className={`px-1.5 py-0.5 rounded-md text-[9px] font-bold uppercase border ${tierStyle.badge}`}
                            >
                              {tierStyle.label.en}
                            </span>
                          </div>

                          {isUnlocked ? (
                            <span className="inline-flex items-center gap-1 text-[10px] font-black text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-lg border border-emerald-500/20 shrink-0">
                              <CheckCircle2 className="w-3 h-3" />
                              Done
                            </span>
                          ) : (
                            <span className="text-[10px] font-mono text-slate-400 font-bold shrink-0">
                              {ach.progress.current} / {ach.progress.target}
                            </span>
                          )}
                        </div>

                        <p className="text-[11px] text-slate-400 leading-relaxed">
                          {ach.description.en}
                        </p>

                        {/* Progress bar inside badge card */}
                        <div className="pt-1.5 flex items-center gap-2">
                          <div className="flex-1 h-1.5 rounded-full bg-black/40 overflow-hidden border border-white/10">
                            <div
                              className={`h-full rounded-full transition-all duration-300 ${
                                isUnlocked ? 'bg-emerald-400' : 'bg-indigo-500'
                              }`}
                              style={{ width: `${percent}%` }}
                            />
                          </div>

                          {/* Quick launch button for game-specific badges */}
                          {ach.category === 'score' && !isUnlocked && (
                            <button
                              onClick={() => handleFindGame(ach.id)}
                              className="px-2.5 py-0.5 rounded-lg bg-indigo-600/80 hover:bg-indigo-600 text-white text-[10px] font-black transition-all flex items-center gap-1 cursor-pointer shrink-0"
                              title="Play game to achieve this badge"
                            >
                              <Play className="w-2.5 h-2.5 fill-current" />
                              <span>Play</span>
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* TAB 2: HIGH SCORES & RECORDS VIEW */}
        {activeTab === 'records' && (
          <div className="flex-1 space-y-4 mt-4 overflow-y-auto pr-1">
            {/* Highlight Cards */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
                <div className="flex items-center gap-1.5 text-xs text-indigo-300 font-semibold mb-1">
                  <Flame className="w-3.5 h-3.5 text-indigo-400" />
                  <span>Total Plays</span>
                </div>
                <div className="text-2xl font-black text-white">{stats.totalPlays}</div>
              </div>

              <div className="p-4 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md">
                <div className="flex items-center gap-1.5 text-xs text-amber-300 font-semibold mb-1">
                  <Award className="w-3.5 h-3.5 text-amber-400" />
                  <span>Games Played</span>
                </div>
                <div className="text-2xl font-black text-amber-300">{playedGamesCount}</div>
              </div>
            </div>

            {/* High Scores List */}
            <div className="space-y-3">
              <h4 className="text-xs font-bold text-slate-300 flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                High Scores by Game:
              </h4>

              <div className="space-y-2">
                {GAMES_DATA.map((game) => {
                  const score = stats.highScores[game.id] || 0;
                  const isFav = stats.favorites?.includes(game.id);

                  return (
                    <div
                      key={game.id}
                      className="flex items-center justify-between p-3 rounded-2xl bg-white/5 border border-white/10 hover:bg-white/10 hover:border-white/20 transition-all backdrop-blur-md"
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-9 h-9 rounded-xl bg-gradient-to-br ${game.thumbnailGradient} flex items-center justify-center text-sm text-white border border-white/10 shadow-sm`}
                        >
                          {game.bannerEmoji || '🎮'}
                        </div>
                        <div>
                          <div className="text-xs font-bold text-white flex items-center gap-1.5">
                            <span>{game.title.en}</span>
                            {isFav && <Heart className="w-3 h-3 text-red-400 fill-red-400" />}
                          </div>
                          <div className="text-[11px] text-slate-400 font-mono">
                            Best:{' '}
                            <span className="font-bold text-amber-400">{score}</span>
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          sounds.playClick();
                          onClose();
                          onPlayGame(game);
                        }}
                        className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-black transition-all shadow-md shadow-indigo-600/20 cursor-pointer"
                      >
                        Play
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* Reset stats button */}
        <div className="pt-4 border-t border-white/10 mt-auto">
          <button
            onClick={() => {
              if (
                window.confirm(
                  'Are you sure you want to reset all saved scores, achievements, and stats?'
                )
              ) {
                onResetStats();
              }
            }}
            className="w-full py-2.5 rounded-2xl bg-white/5 hover:bg-red-500/20 text-slate-400 hover:text-red-300 text-xs font-bold border border-white/10 flex items-center justify-center gap-1.5 transition-all cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            Reset High Scores & Badges
          </button>
        </div>
      </div>
    </div>
  );
};
