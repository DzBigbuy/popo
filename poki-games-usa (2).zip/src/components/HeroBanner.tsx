import React, { useState } from 'react';
import { RotateCcw } from 'lucide-react';
import { GameInfo } from '../types';
import { sounds } from '../utils/audio';

interface HeroBannerProps {
  featuredGame: GameInfo;
  onPlayGame: (game: GameInfo) => void;
  lang: 'ar' | 'en';
  highScore: number;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  featuredGame,
  onPlayGame,
  lang,
}) => {
  const [iframeKey, setIframeKey] = useState(0);

  return (
    <section
      className="relative w-full rounded-3xl overflow-hidden border-2 border-cyan-500/30 shadow-2xl mb-8 select-none bg-[#0a1020]"
    >
      {/* Top Header bar inside the Hero */}
      <div className="relative z-20 flex items-center justify-between p-4 sm:p-5 border-b border-cyan-500/20 bg-slate-950/80 backdrop-blur-xl">
        <h2 className="text-lg sm:text-2xl font-black text-white tracking-tight">
          {featuredGame.title[lang]}
        </h2>

        {/* Reload inline frame */}
        <button
          onClick={() => {
            sounds.playClick();
            setIframeKey((prev) => prev + 1);
          }}
          className="p-2.5 rounded-2xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 transition-all cursor-pointer shadow-md active:scale-95"
          title="Reload Game"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* Main Interactive Stage with the requested iFrame right on the front page */}
      <div className="relative z-20 w-full bg-black flex flex-col items-center justify-center overflow-hidden">
        {featuredGame.iframeUrl ? (
          <div className="w-full h-[520px] sm:h-[640px] relative bg-slate-950">
            <iframe
              key={iframeKey}
              seamless
              allowTransparency
              allowFullScreen
              frameBorder="0"
              style={{ width: '100%', height: '100%', border: '0px' }}
              src={featuredGame.iframeUrl}
              title={featuredGame.title.en}
              className="w-full h-full border-0 block"
              allow="fullscreen; autoplay; gamepad; microphone; camera"
            />
          </div>
        ) : (
          <div className="p-12 text-center text-slate-400">
            <button
              onClick={() => onPlayGame(featuredGame)}
              className="px-8 py-3 rounded-2xl bg-cyan-400 text-slate-950 font-black"
            >
              Play Game
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
