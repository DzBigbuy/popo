import React from 'react';
import { Search } from 'lucide-react';
import { GameCategory } from '../types';
import { CATEGORY_THEMES } from '../utils/categoryThemes';

interface HeaderProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedCategory?: GameCategory;
}

export const Header: React.FC<HeaderProps> = ({
  searchQuery,
  onSearchChange,
  selectedCategory = 'all',
}) => {
  const theme = CATEGORY_THEMES[selectedCategory] || CATEGORY_THEMES.all;

  return (
    <header
      className={`sticky top-0 z-40 w-full ${theme.headerBg} backdrop-blur-xl border-b ${theme.headerBorder} shadow-sm transition-all duration-300`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4">
        {/* Poki-Style Game Tile Logo */}
        <div className="flex items-center gap-3 cursor-pointer group select-none">
          <div className="relative w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-400 via-blue-500 to-indigo-600 flex items-center justify-center shadow-md shadow-indigo-500/20 ring-2 ring-indigo-300/40 group-hover:scale-105 group-hover:rotate-3 transition-all duration-300">
            {/* 3D Glossy shine */}
            <div className="absolute top-1 left-1.5 w-5 h-2.5 bg-white/50 rounded-full blur-[1px]" />
            <span className="font-black text-white text-xl tracking-tighter drop-shadow-md">
              poki
            </span>
          </div>
        </div>

        {/* Poki-Style Centered Capsule Search */}
        <div className="flex-1 max-w-md">
          <div className="relative">
            <Search className={`absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 ${theme.searchIconColor} pointer-events-none transition-colors`} />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search..."
              className={`w-full pl-11 pr-10 py-2.5 rounded-full ${
                theme.isDarkTheme ? 'bg-zinc-900/90 text-zinc-100 placeholder-zinc-500' : 'bg-white/95 text-slate-900 placeholder-slate-400'
              } border ${theme.searchBorder} ${theme.searchFocusRing} focus:bg-white text-xs sm:text-sm transition-all outline-none shadow-sm`}
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className={`absolute right-3.5 top-1/2 -translate-y-1/2 text-xs px-1.5 py-0.5 rounded-full cursor-pointer ${
                  theme.isDarkTheme
                    ? 'bg-zinc-800 text-zinc-300 hover:text-white'
                    : 'bg-purple-100 text-purple-600 hover:text-purple-900'
                }`}
              >
                ✕
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

