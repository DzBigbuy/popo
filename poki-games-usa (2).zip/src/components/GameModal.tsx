import React, { useState, useEffect, useRef } from 'react';
import { X, Loader2, Maximize, Minimize } from 'lucide-react';
import { GameInfo } from '../types';
import { SnakeGame } from '../games/SnakeGame';
import { TicTacToeGame } from '../games/TicTacToeGame';
import { BrickBreakerGame } from '../games/BrickBreakerGame';
import { MemoryMatchGame } from '../games/MemoryMatchGame';
import { FlappyBirdGame } from '../games/FlappyBirdGame';
import { Game2048 } from '../games/Game2048';
import { SpaceShooterGame } from '../games/SpaceShooterGame';
import { SpeedMathGame } from '../games/SpeedMathGame';
import { PongGame } from '../games/PongGame';
import { CarRunnerGame } from '../games/CarRunnerGame';
import { ColorMatchGame } from '../games/ColorMatchGame';
import { RacingLimitsGame } from '../games/RacingLimitsGame';
import { WaterSortGame } from '../games/WaterSortGame';
import { BlockPuzzleGame } from '../games/BlockPuzzleGame';
import { sounds } from '../utils/audio';

interface GameModalProps {
  game: GameInfo | null;
  onClose: () => void;
  highScore?: number;
  onRecordScore?: (gameId: string, score: number) => void;
  onSelectAnotherGame?: (game: GameInfo) => void;
  lang?: 'ar' | 'en';
}

export const GameModal: React.FC<GameModalProps> = ({
  game,
  onClose,
  highScore = 0,
  onRecordScore,
  lang = 'ar',
}) => {
  const [iframeLoaded, setIframeLoaded] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const modalContainerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    document.addEventListener('webkitfullscreenchange', handleFullscreenChange);
    document.addEventListener('mozfullscreenchange', handleFullscreenChange);
    document.addEventListener('MSFullscreenChange', handleFullscreenChange);

    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
      document.removeEventListener('webkitfullscreenchange', handleFullscreenChange);
      document.removeEventListener('mozfullscreenchange', handleFullscreenChange);
      document.removeEventListener('MSFullscreenChange', handleFullscreenChange);
    };
  }, []);

  if (!game) return null;

  const toggleFullscreen = () => {
    sounds.playClick();
    if (!document.fullscreenElement) {
      if (modalContainerRef.current?.requestFullscreen) {
        modalContainerRef.current.requestFullscreen().catch(() => {});
      } else if ((modalContainerRef.current as any)?.webkitRequestFullscreen) {
        (modalContainerRef.current as any).webkitRequestFullscreen();
      } else if ((modalContainerRef.current as any)?.msRequestFullscreen) {
        (modalContainerRef.current as any).msRequestFullscreen();
      }
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
      } else if ((document as any)?.webkitExitFullscreen) {
        (document as any).webkitExitFullscreen();
      } else if ((document as any)?.msExitFullscreen) {
        (document as any).msExitFullscreen();
      }
    }
  };

  const handleScoreUpdate = (score: number) => {
    if (onRecordScore && score > highScore) {
      onRecordScore(game.id, score);
    }
  };

  const renderGameComponent = () => {
    if (game.iframeUrl) {
      return (
        <div className="relative w-full h-full min-h-[500px] bg-black flex flex-col items-center justify-center">
          {!iframeLoaded && (
            <div className="absolute inset-0 z-10 flex items-center justify-center bg-black/90">
              <Loader2 className="w-10 h-10 text-cyan-400 animate-spin" />
            </div>
          )}
          <iframe
            src={game.iframeUrl}
            title={game.title.en}
            seamless
            allowTransparency
            allowFullScreen
            frameBorder="0"
            className="w-full h-full flex-1 border-0 bg-black"
            allow="fullscreen; autoplay; gamepad; microphone; camera"
            onLoad={() => setIframeLoaded(true)}
            style={{ width: '100%', height: '100%', border: '0px' }}
          />
        </div>
      );
    }

    switch (game.id) {
      case 'racing-limits':
        return <RacingLimitsGame onScoreUpdate={handleScoreUpdate} highScore={highScore} />;
      case 'snake':
        return <SnakeGame onScoreUpdate={handleScoreUpdate} highScore={highScore} />;
      case 'car-runner':
        return <CarRunnerGame onScoreUpdate={handleScoreUpdate} highScore={highScore} />;
      case 'tictactoe':
        return <TicTacToeGame onScoreUpdate={handleScoreUpdate} highScore={highScore} />;
      case 'brick-breaker':
        return <BrickBreakerGame onScoreUpdate={handleScoreUpdate} highScore={highScore} />;
      case 'memory-match':
        return <MemoryMatchGame onScoreUpdate={handleScoreUpdate} highScore={highScore} />;
      case 'flappy-bird':
        return <FlappyBirdGame onScoreUpdate={handleScoreUpdate} highScore={highScore} />;
      case 'game-2048':
        return <Game2048 onScoreUpdate={handleScoreUpdate} highScore={highScore} />;
      case 'space-shooter':
        return <SpaceShooterGame onScoreUpdate={handleScoreUpdate} highScore={highScore} />;
      case 'speed-math':
        return <SpeedMathGame onScoreUpdate={handleScoreUpdate} highScore={highScore} />;
      case 'pong':
        return <PongGame onScoreUpdate={handleScoreUpdate} highScore={highScore} />;
      case 'color-match':
        return <ColorMatchGame onScoreUpdate={handleScoreUpdate} highScore={highScore} />;
      case 'water-sort-puzzle':
        return <WaterSortGame onScoreUpdate={handleScoreUpdate} highScore={highScore} />;
      case 'block-puzzle-jewel':
        return <BlockPuzzleGame onScoreUpdate={handleScoreUpdate} highScore={highScore} />;
      default:
        return (
          <div className="p-8 text-center text-slate-400">
            Game loaded
          </div>
        );
    }
  };

  return (
    <div
      ref={modalContainerRef}
      className={`fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-md animate-fade-in ${
        isFullscreen ? 'p-0' : 'p-2 sm:p-4'
      }`}
    >
      {/* Floating Control Buttons: Fullscreen (Plein écran) & Close (X) */}
      <div className="fixed top-3 right-3 sm:top-4 sm:right-4 z-50 flex items-center gap-2">
        {/* Fullscreen Button (Plein Écran / ملء الشاشة) */}
        <button
          id="btn-fullscreen-toggle"
          onClick={toggleFullscreen}
          className="h-11 px-3 sm:px-4 rounded-full bg-slate-900/90 hover:bg-cyan-600 text-white border-2 border-cyan-400/40 hover:border-cyan-300 flex items-center justify-center gap-1.5 transition-all duration-200 shadow-2xl cursor-pointer active:scale-90 group backdrop-blur-md"
          title={lang === 'ar' ? 'ملء الشاشة (Plein Écran)' : 'Fullscreen (Plein Écran)'}
          aria-label="Toggle Fullscreen"
        >
          {isFullscreen ? (
            <>
              <Minimize className="w-5 h-5 text-cyan-300 group-hover:scale-110 transition-transform" />
              <span className="hidden sm:inline font-bold text-xs text-white">
                {lang === 'ar' ? 'شاشة عادية' : 'Exit Fullscreen'}
              </span>
            </>
          ) : (
            <>
              <Maximize className="w-5 h-5 text-cyan-300 group-hover:scale-110 transition-transform" />
              <span className="hidden sm:inline font-bold text-xs text-white">
                {lang === 'ar' ? 'ملء الشاشة' : 'Plein Écran'}
              </span>
            </>
          )}
        </button>

        {/* Close Button (X) */}
        <button
          id="btn-close-game-modal"
          onClick={() => {
            sounds.playClick();
            if (document.fullscreenElement) {
              document.exitFullscreen().catch(() => {});
            }
            onClose();
          }}
          className="w-11 h-11 rounded-full bg-slate-900/90 hover:bg-rose-600 text-white border-2 border-white/20 hover:border-rose-400 flex items-center justify-center transition-all duration-200 shadow-2xl cursor-pointer active:scale-90 group backdrop-blur-md"
          title={lang === 'ar' ? 'إغلاق اللعبة' : 'Close game'}
          aria-label="Close game"
        >
          <X className="w-6 h-6 group-hover:rotate-90 transition-transform duration-200" />
        </button>
      </div>

      {/* Standalone Game Window */}
      <div
        className={`relative w-full h-full bg-black shadow-2xl overflow-hidden flex flex-col items-center justify-center transition-all duration-300 ${
          isFullscreen
            ? 'w-screen h-screen max-w-none max-h-none rounded-none border-0'
            : 'max-w-6xl max-h-[92vh] rounded-2xl sm:rounded-3xl border border-white/10'
        }`}
      >
        <div className="w-full h-full flex items-center justify-center overflow-hidden">
          {renderGameComponent()}
        </div>
      </div>
    </div>
  );
};
