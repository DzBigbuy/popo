import React from 'react';
import { Gamepad2 } from 'lucide-react';
import { GameCategory } from '../types';
import { CATEGORY_THEMES } from '../utils/categoryThemes';

interface FooterProps {
  lang: 'ar' | 'en';
  selectedCategory?: GameCategory;
}

export const Footer: React.FC<FooterProps> = ({
  selectedCategory = 'all',
}) => {
  const theme = CATEGORY_THEMES[selectedCategory] || CATEGORY_THEMES.all;

  return (
    <footer
      className={`w-full mt-16 border-t ${theme.headerBorder} ${
        theme.isDarkTheme ? 'bg-zinc-950/80 text-zinc-400' : 'bg-white/40 text-slate-600'
      } backdrop-blur-md py-8 px-4 text-center transition-colors duration-300`}
    >
      <div className="max-w-7xl mx-auto flex items-center justify-center gap-3">
        <div
          className={`w-8 h-8 rounded-xl flex items-center justify-center text-white shadow-md transition-all ${
            theme.isDarkTheme
              ? 'bg-gradient-to-tr from-red-600 to-zinc-800'
              : 'bg-gradient-to-tr from-purple-500 to-indigo-600'
          }`}
        >
          <Gamepad2 className="w-4 h-4" />
        </div>
        <span
          className={`font-black text-sm tracking-wide ${
            theme.isDarkTheme ? 'text-zinc-200' : 'text-slate-900'
          }`}
        >
          POKI GAMES
        </span>
      </div>
    </footer>
  );
};

