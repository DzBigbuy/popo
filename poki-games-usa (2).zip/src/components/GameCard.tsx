import React, { useState } from 'react';
import { GameInfo } from '../types';
import { CATEGORY_THEMES } from '../utils/categoryThemes';
import { sounds } from '../utils/audio';

interface GameCardProps {
  game: GameInfo;
  onPlay: (game: GameInfo) => void;
  isFavorite?: boolean;
  onToggleFavorite?: (id: string) => void;
  highScore?: number;
  lang: 'ar' | 'en';
}

export const GameCard: React.FC<GameCardProps> = ({
  game,
  onPlay,
  lang,
}) => {
  const emoji = game.bannerEmoji || '🎮';
  const [imgSrc, setImgSrc] = useState<string | undefined>(game.imageUrl);
  const theme = CATEGORY_THEMES[game.category] || CATEGORY_THEMES.all;

  const handleImageError = () => {
    setImgSrc(undefined);
  };

  return (
    <div
      id={`game-tile-${game.id}`}
      onClick={() => {
        sounds.playClick();
        onPlay(game);
      }}
      className={`group relative rounded-2xl sm:rounded-3xl bg-[#14192b] ${theme.cardBorder} ${theme.cardHoverBorder} overflow-hidden cursor-pointer transition-all duration-300 transform hover:-translate-y-2 hover:scale-[1.03] hover:shadow-2xl ${theme.cardHoverShadow} active:scale-[0.97] select-none aspect-square w-full shadow-md border`}
    >
      {/* Background Gradient fallback */}
      <div
        className={`absolute inset-0 bg-gradient-to-br ${game.thumbnailGradient} opacity-95`}
      />

      {/* Full-bleed Game Image */}
      {imgSrc ? (
        <img
          src={imgSrc}
          alt={game.title[lang]}
          loading="lazy"
          referrerPolicy="no-referrer"
          className="absolute inset-0 w-full h-full object-cover group-hover:scale-110 transition-transform duration-500 z-0"
          onError={handleImageError}
        />
      ) : (
        <div className="absolute inset-0 flex items-center justify-center z-0">
          <div className="absolute inset-0 bg-white/10 rounded-full blur-2xl transform scale-75 group-hover:scale-125 transition-transform duration-300 pointer-events-none" />
          <span className="inline-block text-6xl sm:text-7xl drop-shadow-2xl transform transition-transform duration-300 group-hover:scale-115 group-hover:rotate-6">
            {emoji}
          </span>
        </div>
      )}

      {/* Glossy top highlight shine */}
      <div className="absolute -top-12 -left-12 w-32 h-32 bg-white/20 rounded-full blur-xl pointer-events-none group-hover:scale-150 transition-transform duration-500 z-20" />

      {/* Bottom Gradient Shade for Title Legibility */}
      <div className="absolute inset-x-0 bottom-0 h-16 bg-gradient-to-t from-black/85 via-black/40 to-transparent pointer-events-none z-20" />

      {/* Game Title Bar (Poki Style) */}
      <div className="absolute inset-x-0 bottom-0 p-2 sm:p-2.5 z-30">
        <div
          className={`py-1 px-2 rounded-xl bg-black/65 backdrop-blur-md border border-white/15 text-center w-full ${theme.cardTitleHoverBg} ${theme.cardTitleHoverBorder} transition-all`}
        >
          <h4 className="font-black text-white text-xs sm:text-sm truncate tracking-tight">
            {game.title[lang]}
          </h4>
        </div>
      </div>
    </div>
  );
};
