import React from 'react';
import { GameCategory } from '../types';
import { CATEGORIES_LIST } from '../data/gamesData';
import { CATEGORY_THEMES } from '../utils/categoryThemes';
import { sounds } from '../utils/audio';

interface GameCategoryTabsProps {
  selectedCategory: GameCategory;
  onSelectCategory: (category: GameCategory) => void;
  categoryCounts?: Record<GameCategory, number>;
  lang: 'ar' | 'en';
}

export const GameCategoryTabs: React.FC<GameCategoryTabsProps> = ({
  selectedCategory,
  onSelectCategory,
  categoryCounts,
  lang,
}) => {
  return (
    <div className="flex items-center gap-2.5 overflow-x-auto py-2.5 px-1 scrollbar-none select-none">
      {CATEGORIES_LIST.map((cat) => {
        const isSelected = selectedCategory === cat.id;
        const count = categoryCounts ? categoryCounts[cat.id as GameCategory] || 0 : null;
        const theme = CATEGORY_THEMES[cat.id as GameCategory] || CATEGORY_THEMES.all;

        return (
          <button
            key={cat.id}
            id={`tab-cat-${cat.id}`}
            onClick={() => {
              sounds.playClick();
              onSelectCategory(cat.id as GameCategory);
            }}
            className={`flex items-center gap-2 px-3.5 sm:px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-black whitespace-nowrap transition-all duration-300 shrink-0 border cursor-pointer active:scale-95 shadow-sm ${
              isSelected
                ? theme.tabActive
                : theme.tabInactive
            }`}
          >
            <span className="text-base sm:text-lg transition-transform group-hover:scale-110">
              {cat.emoji}
            </span>
            <span className="tracking-tight">{cat.label[lang]}</span>
            {count !== null && count > 0 && (
              <span
                className={`text-[10px] sm:text-xs font-black px-2 py-0.5 rounded-full transition-all ${
                  isSelected ? theme.badgeActive : theme.badgeInactive
                }`}
              >
                {count}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
};


