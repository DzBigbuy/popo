import { Achievement, PlayerStats } from '../types';

export const ACHIEVEMENTS_DATA: Achievement[] = [
  // Total Plays Milestones
  {
    id: 'first-step',
    title: {
      ar: 'الخطوة الأولى',
      en: 'First Step',
    },
    description: {
      ar: 'العب أي لعبة لمرة واحدة على الأقل',
      en: 'Play any game at least once',
    },
    icon: '🎮',
    category: 'plays',
    tier: 'bronze',
    checkProgress: (stats: PlayerStats) => {
      const current = stats.totalPlays || 0;
      const target = 1;
      return {
        unlocked: current >= target,
        current: Math.min(current, target),
        target,
      };
    },
  },
  {
    id: 'arcade-enthusiast',
    title: {
      ar: 'عاشق الآركيد',
      en: 'Arcade Enthusiast',
    },
    description: {
      ar: 'أكمل 10 مباريات إجمالية عبر المنصة',
      en: 'Complete 10 total game rounds',
    },
    icon: '🕹️',
    category: 'plays',
    tier: 'silver',
    checkProgress: (stats: PlayerStats) => {
      const current = stats.totalPlays || 0;
      const target = 10;
      return {
        unlocked: current >= target,
        current: Math.min(current, target),
        target,
      };
    },
  },
  {
    id: 'pro-gamer',
    title: {
      ar: 'لاعب محترف',
      en: 'Pro Gamer',
    },
    description: {
      ar: 'أكمل 30 مباراة إجمالية',
      en: 'Complete 30 total game rounds',
    },
    icon: '⚡',
    category: 'plays',
    tier: 'gold',
    checkProgress: (stats: PlayerStats) => {
      const current = stats.totalPlays || 0;
      const target = 30;
      return {
        unlocked: current >= target,
        current: Math.min(current, target),
        target,
      };
    },
  },
  {
    id: 'legendary-veteran',
    title: {
      ar: 'أسطورة الألعاب',
      en: 'Gaming Legend',
    },
    description: {
      ar: 'أكمل 60 مباراة إجمالية في المنصة',
      en: 'Complete 60 total game rounds',
    },
    icon: '👑',
    category: 'plays',
    tier: 'platinum',
    checkProgress: (stats: PlayerStats) => {
      const current = stats.totalPlays || 0;
      const target = 60;
      return {
        unlocked: current >= target,
        current: Math.min(current, target),
        target,
      };
    },
  },

  // Game Variety & Exploration
  {
    id: 'game-explorer',
    title: {
      ar: 'المستكشف الفضولي',
      en: 'Game Explorer',
    },
    description: {
      ar: 'جرب وسجل أرقاماً في 4 ألعاب مختلفة',
      en: 'Play and record scores in 4 different games',
    },
    icon: '🧭',
    category: 'mastery',
    tier: 'bronze',
    checkProgress: (stats: PlayerStats) => {
      const current = Object.keys(stats.highScores || {}).length;
      const target = 4;
      return {
        unlocked: current >= target,
        current: Math.min(current, target),
        target,
      };
    },
  },
  {
    id: 'master-of-all',
    title: {
      ar: 'سيد كل الميادين',
      en: 'Master of All',
    },
    description: {
      ar: 'جرب جميع ألعاب المنصة التسعة وسجل أرقاماً فيها',
      en: 'Play and record high scores in all 9 games',
    },
    icon: '🌟',
    category: 'mastery',
    tier: 'platinum',
    checkProgress: (stats: PlayerStats) => {
      const current = Object.keys(stats.highScores || {}).length;
      const target = 9;
      return {
        unlocked: current >= target,
        current: Math.min(current, target),
        target,
      };
    },
  },

  // Specific Game High Scores
  {
    id: 'snake-charmer',
    title: {
      ar: 'مروّض الثعابين',
      en: 'Snake Charmer',
    },
    description: {
      ar: 'سجل 50 نقطة أو أكثر في لعبة الثعبان (Snake)',
      en: 'Reach a score of 50+ in Classic Snake',
    },
    icon: '🐍',
    category: 'score',
    tier: 'bronze',
    checkProgress: (stats: PlayerStats) => {
      const current = stats.highScores['snake'] || 0;
      const target = 50;
      return {
        unlocked: current >= target,
        current: Math.min(current, target),
        target,
      };
    },
  },
  {
    id: 'galaxy-hero',
    title: {
      ar: 'بطل المجرة',
      en: 'Galaxy Hero',
    },
    description: {
      ar: 'سجل 500 نقطة أو أكثر في معركة الفضاء (Space Shooter)',
      en: 'Score 500+ points in Space Shooter',
    },
    icon: '🚀',
    category: 'score',
    tier: 'silver',
    checkProgress: (stats: PlayerStats) => {
      const current = stats.highScores['space-shooter'] || 0;
      const target = 500;
      return {
        unlocked: current >= target,
        current: Math.min(current, target),
        target,
      };
    },
  },
  {
    id: 'brick-demolisher',
    title: {
      ar: 'قاهر الجدران',
      en: 'Brick Demolisher',
    },
    description: {
      ar: 'سجل 200 نقطة أو أكثر في لعبة تكسير الطوب',
      en: 'Score 200+ points in Brick Breaker',
    },
    icon: '🧱',
    category: 'score',
    tier: 'silver',
    checkProgress: (stats: PlayerStats) => {
      const current = stats.highScores['brick-breaker'] || 0;
      const target = 200;
      return {
        unlocked: current >= target,
        current: Math.min(current, target),
        target,
      };
    },
  },
  {
    id: 'puzzle-prodigy',
    title: {
      ar: 'عبقري الأرقام 2048',
      en: '2048 Prodigy',
    },
    description: {
      ar: 'سجل 1000 نقطة أو أكثر في لعبة دمج الأرقام 2048',
      en: 'Score 1,000+ points in 2048 Puzzle',
    },
    icon: '🔢',
    category: 'score',
    tier: 'gold',
    checkProgress: (stats: PlayerStats) => {
      const current = stats.highScores['game-2048'] || 0;
      const target = 1000;
      return {
        unlocked: current >= target,
        current: Math.min(current, target),
        target,
      };
    },
  },
  {
    id: 'sky-aviator',
    title: {
      ar: 'طيار الأعالي',
      en: 'Sky Aviator',
    },
    description: {
      ar: 'تجاوز 10 أنابيب في لعبة الطائر المحلق (Flappy Bird)',
      en: 'Score 10+ pipes in Flappy Bird',
    },
    icon: '🦅',
    category: 'score',
    tier: 'silver',
    checkProgress: (stats: PlayerStats) => {
      const current = stats.highScores['flappy-bird'] || 0;
      const target = 10;
      return {
        unlocked: current >= target,
        current: Math.min(current, target),
        target,
      };
    },
  },
  {
    id: 'lightning-brain',
    title: {
      ar: 'عقل البرق',
      en: 'Lightning Brain',
    },
    description: {
      ar: 'أجب 10 مسائل صحيحة متتالية في لعبة سرعة الحساب',
      en: 'Score 10+ correct answers in Speed Math',
    },
    icon: '⚡',
    category: 'score',
    tier: 'bronze',
    checkProgress: (stats: PlayerStats) => {
      const current = stats.highScores['speed-math'] || 0;
      const target = 10;
      return {
        unlocked: current >= target,
        current: Math.min(current, target),
        target,
      };
    },
  },
  {
    id: 'ping-pong-champ',
    title: {
      ar: 'بطل كرة الطاولة',
      en: 'Pong Champion',
    },
    description: {
      ar: 'سجل 5 صدات أو أكثر في لعبة بونغ الرجعية (Retro Pong)',
      en: 'Score 5+ points in Retro Pong',
    },
    icon: '🏓',
    category: 'score',
    tier: 'bronze',
    checkProgress: (stats: PlayerStats) => {
      const current = stats.highScores['pong'] || 0;
      const target = 5;
      return {
        unlocked: current >= target,
        current: Math.min(current, target),
        target,
      };
    },
  },
  {
    id: 'memory-master',
    title: {
      ar: 'الذاكرة الخارقة',
      en: 'Super Memory',
    },
    description: {
      ar: 'أكمل تطابق البطاقات بنجاح في لعبة الذاكرة',
      en: 'Score 60+ in Memory Card Match',
    },
    icon: '🧠',
    category: 'score',
    tier: 'silver',
    checkProgress: (stats: PlayerStats) => {
      const current = stats.highScores['memory-match'] || 0;
      const target = 60;
      return {
        unlocked: current >= target,
        current: Math.min(current, target),
        target,
      };
    },
  },
  {
    id: 'highway-racer-pro',
    title: {
      ar: 'ملك الطريق السريع 3D',
      en: 'Highway Speed Demon',
    },
    description: {
      ar: 'سجل 1,500 نقطة أو أكثر في لعبة ريسينغ ليميتس (Racing Limits 3D)',
      en: 'Score 1,500+ points in Racing Limits 3D',
    },
    icon: '🏎️',
    category: 'score',
    tier: 'gold',
    checkProgress: (stats: PlayerStats) => {
      const current = stats.highScores['racing-limits'] || 0;
      const target = 1500;
      return {
        unlocked: current >= target,
        current: Math.min(current, target),
        target,
      };
    },
  },
  {
    id: 'gamezop-champion',
    title: {
      ar: 'بطل غيمزوب الماسي',
      en: 'GameZop Arena Champion',
    },
    description: {
      ar: 'سجل 2,000 نقطة أو أكثر في لعبة غيمزوب أرينا المباشرة',
      en: 'Score 2,000+ points in GameZop Premier Arena',
    },
    icon: '⚡',
    category: 'score',
    tier: 'platinum',
    checkProgress: (stats: PlayerStats) => {
      const current = stats.highScores['gamezop-hero'] || 0;
      const target = 2000;
      return {
        unlocked: current >= target,
        current: Math.min(current, target),
        target,
      };
    },
  },
  {
    id: 'gamemonetize-master',
    title: {
      ar: 'أسطورة السرعة القصوى',
      en: 'Cyber Velocity Master',
    },
    description: {
      ar: 'سجل 3,000 نقطة أو أكثر في لعبة Cyber Velocity Rush',
      en: 'Score 3,000+ points in Cyber Velocity Rush',
    },
    icon: '🚀',
    category: 'score',
    tier: 'platinum',
    checkProgress: (stats: PlayerStats) => {
      const current = stats.highScores['gamemonetize-rush'] || 0;
      const target = 3000;
      return {
        unlocked: current >= target,
        current: Math.min(current, target),
        target,
      };
    },
  },
];
