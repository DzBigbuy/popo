import React, { useEffect, useRef, useState } from 'react';
import { Play, RotateCcw, Trophy } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sounds } from '../utils/audio';

interface FlappyBirdProps {
  onScoreUpdate: (score: number) => void;
  highScore: number;
}

interface Pipe {
  x: number;
  topHeight: number;
  bottomHeight: number;
  passed: boolean;
}

export const FlappyBirdGame: React.FC<FlappyBirdProps> = ({ onScoreUpdate, highScore }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [score, setScore] = useState(0);

  const birdRef = useRef({
    x: 60,
    y: 180,
    velocity: 0,
    gravity: 0.38,
    jump: -6.5,
    radius: 14,
  });

  const pipesRef = useRef<Pipe[]>([]);
  const frameCountRef = useRef(0);

  const jump = () => {
    if (!isPlaying && !isGameOver) {
      startGame();
      return;
    }
    if (isGameOver) {
      startGame();
      return;
    }
    birdRef.current.velocity = birdRef.current.jump;
    sounds.playJump();
  };

  const startGame = () => {
    birdRef.current = {
      x: 60,
      y: 180,
      velocity: -3,
      gravity: 0.38,
      jump: -6.5,
      radius: 14,
    };
    pipesRef.current = [];
    frameCountRef.current = 0;
    setScore(0);
    setIsGameOver(false);
    setIsPlaying(true);
    sounds.playClick();
  };

  // Keyboard and click triggers
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['Space', 'ArrowUp', 'KeyW'].includes(e.code)) {
        e.preventDefault();
        jump();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  });

  useEffect(() => {
    if (!isPlaying) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    const pipeWidth = 50;
    const pipeGap = 120;

    const loop = () => {
      frameCountRef.current += 1;

      // Update Bird physics
      const bird = birdRef.current;
      bird.velocity += bird.gravity;
      bird.y += bird.velocity;

      // Spawn pipes every 100 frames
      if (frameCountRef.current % 100 === 0) {
        const topHeight = Math.floor(Math.random() * (canvas.height - pipeGap - 80)) + 40;
        const bottomHeight = canvas.height - topHeight - pipeGap;
        pipesRef.current.push({
          x: canvas.width,
          topHeight,
          bottomHeight,
          passed: false,
        });
      }

      // Update and check pipes
      pipesRef.current.forEach((pipe, index) => {
        pipe.x -= 2.2;

        // Check if scored
        if (!pipe.passed && pipe.x + pipeWidth < bird.x) {
          pipe.passed = true;
          sounds.playCoin();
          setScore((prev) => {
            const next = prev + 1;
            onScoreUpdate(next);
            return next;
          });
        }

        // Check collision
        if (
          bird.x + bird.radius > pipe.x &&
          bird.x - bird.radius < pipe.x + pipeWidth &&
          (bird.y - bird.radius < pipe.topHeight || bird.y + bird.radius > canvas.height - pipe.bottomHeight)
        ) {
          // Crash!
          setIsPlaying(false);
          setIsGameOver(true);
          sounds.playGameOver();
          if (score > highScore && score > 0) {
            confetti({ particleCount: 80, spread: 70 });
          }
        }

        // Remove off-screen pipes
        if (pipe.x + pipeWidth < -20) {
          pipesRef.current.splice(index, 1);
        }
      });

      // Ceiling / Floor collision
      if (bird.y + bird.radius >= canvas.height || bird.y - bird.radius <= 0) {
        setIsPlaying(false);
        setIsGameOver(true);
        sounds.playGameOver();
      }

      // DRAWING
      // Background gradient
      const bgGrad = ctx.createLinearGradient(0, 0, 0, canvas.height);
      bgGrad.addColorStop(0, '#0f172a');
      bgGrad.addColorStop(0.7, '#1e1b4b');
      bgGrad.addColorStop(1, '#020617');
      ctx.fillStyle = bgGrad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Distant cyber skyline / stars
      ctx.fillStyle = 'rgba(255,255,255,0.15)';
      for (let i = 0; i < 20; i++) {
        const starX = (i * 37 + frameCountRef.current * 0.2) % canvas.width;
        const starY = (i * 23) % (canvas.height - 100);
        ctx.fillRect(starX, starY, 2, 2);
      }

      // Draw Pipes
      pipesRef.current.forEach((pipe) => {
        ctx.save();
        ctx.fillStyle = '#10b981';
        ctx.shadowColor = '#059669';
        ctx.shadowBlur = 10;

        // Top pipe
        ctx.beginPath();
        ctx.roundRect(pipe.x, 0, pipeWidth, pipe.topHeight, [0, 0, 8, 8]);
        ctx.fill();

        // Top pipe cap
        ctx.fillStyle = '#34d399';
        ctx.fillRect(pipe.x - 4, pipe.topHeight - 14, pipeWidth + 8, 14);

        // Bottom pipe
        ctx.fillStyle = '#10b981';
        ctx.beginPath();
        ctx.roundRect(pipe.x, canvas.height - pipe.bottomHeight, pipeWidth, pipe.bottomHeight, [8, 8, 0, 0]);
        ctx.fill();

        // Bottom pipe cap
        ctx.fillStyle = '#34d399';
        ctx.fillRect(pipe.x - 4, canvas.height - pipe.bottomHeight, pipeWidth + 8, 14);

        ctx.restore();
      });

      // Draw Bird (Cyber Jet Bird)
      ctx.save();
      ctx.translate(bird.x, bird.y);
      const angle = Math.min(Math.PI / 4, Math.max(-Math.PI / 4, (bird.velocity * 0.1)));
      ctx.rotate(angle);

      // Jet exhaust trail
      ctx.fillStyle = '#f59e0b';
      ctx.shadowColor = '#fbbf24';
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.moveTo(-bird.radius, 0);
      ctx.lineTo(-bird.radius - 10, -4);
      ctx.lineTo(-bird.radius - 6, 0);
      ctx.lineTo(-bird.radius - 10, 4);
      ctx.closePath();
      ctx.fill();

      // Bird body
      ctx.fillStyle = '#eab308';
      ctx.shadowColor = '#facc15';
      ctx.shadowBlur = 14;
      ctx.beginPath();
      ctx.arc(0, 0, bird.radius, 0, Math.PI * 2);
      ctx.fill();

      // Eye
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(bird.radius * 0.35, -bird.radius * 0.25, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#0f172a';
      ctx.beginPath();
      ctx.arc(bird.radius * 0.45, -bird.radius * 0.25, 2, 0, Math.PI * 2);
      ctx.fill();

      // Beak
      ctx.fillStyle = '#ea580c';
      ctx.beginPath();
      ctx.moveTo(bird.radius * 0.7, -2);
      ctx.lineTo(bird.radius + 8, 2);
      ctx.lineTo(bird.radius * 0.7, 6);
      ctx.closePath();
      ctx.fill();

      ctx.restore();

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, score, highScore, onScoreUpdate]);

  return (
    <div className="flex flex-col items-center justify-center w-full max-w-lg mx-auto select-none">
      <div className="flex items-center justify-between w-full mb-3 px-4 py-2.5 rounded-2xl bg-slate-900/90 border border-slate-800 backdrop-blur-md">
        <span className="text-yellow-400 font-bold text-lg">Score: {score}</span>
        <div className="flex items-center gap-1.5 text-slate-400 text-sm">
          <Trophy className="w-4 h-4 text-amber-400" />
          <span>Best:</span>
          <span className="font-bold text-white">{Math.max(score, highScore)}</span>
        </div>
      </div>

      <div
        onClick={jump}
        className="relative w-full aspect-[4/3] max-w-[400px] rounded-3xl overflow-hidden border-2 border-slate-800 shadow-2xl shadow-yellow-950/20 bg-slate-950 cursor-pointer"
      >
        <canvas ref={canvasRef} width={400} height={380} className="w-full h-full block" />

        {(!isPlaying || isGameOver) && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-10">
            {isGameOver ? (
              <div className="space-y-4">
                <div className="w-16 h-16 mx-auto rounded-3xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-3xl text-red-400">
                  💥
                </div>
                <h3 className="text-2xl font-black text-white">Crashed! Game Over</h3>
                <p className="text-slate-300 text-sm">
                  Pipes Cleared: <span className="font-black text-yellow-400 text-base">{score}</span>
                </p>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    startGame();
                  }}
                  className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-yellow-500 to-amber-600 hover:from-yellow-400 text-slate-950 font-black shadow-xl shadow-yellow-500/25 flex items-center gap-2 mx-auto transition-all active:scale-95 cursor-pointer text-sm"
                >
                  <RotateCcw className="w-4 h-4" />
                  Fly Again
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="w-16 h-16 mx-auto rounded-3xl bg-yellow-500/20 border border-yellow-500/40 flex items-center justify-center text-3xl text-yellow-400 animate-bounce">
                  🦅
                </div>
                <div>
                  <h3 className="text-2xl font-black text-white mb-1">Cyber Jet Flappy</h3>
                  <p className="text-xs text-slate-400">Click anywhere or press Space to flap and navigate through pipes</p>
                </div>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    startGame();
                  }}
                  className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-yellow-500 to-amber-600 hover:from-yellow-400 text-slate-950 font-black shadow-xl shadow-yellow-500/25 flex items-center gap-2 mx-auto transition-all active:scale-95 cursor-pointer text-base"
                >
                  <Play className="w-5 h-5 fill-current" />
                  TAP TO FLY
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="mt-3 text-xs text-slate-400 text-center">
        💡 Click / Tap inside game box or press Spacebar to flap
      </div>
    </div>
  );
};
