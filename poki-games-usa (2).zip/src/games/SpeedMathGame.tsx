import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Play, RotateCcw, Zap, Trophy, Clock, CheckCircle2, XCircle } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sounds } from '../utils/audio';

interface SpeedMathProps {
  onScoreUpdate: (score: number) => void;
  highScore: number;
}

interface Question {
  text: string;
  options: number[];
  correct: number;
}

export const SpeedMathGame: React.FC<SpeedMathProps> = ({ onScoreUpdate, highScore }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [timeLeft, setTimeLeft] = useState(5.0);
  const [question, setQuestion] = useState<Question | null>(null);
  const [feedback, setFeedback] = useState<'correct' | 'wrong' | null>(null);

  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const generateQuestion = useCallback((): Question => {
    const ops = ['+', '-', '×'];
    const op = ops[Math.floor(Math.random() * ops.length)];
    let n1 = Math.floor(Math.random() * 12) + 2;
    let n2 = Math.floor(Math.random() * 12) + 2;
    let correct = 0;

    if (op === '+') {
      correct = n1 + n2;
    } else if (op === '-') {
      if (n1 < n2) [n1, n2] = [n2, n1];
      correct = n1 - n2;
    } else {
      n1 = Math.floor(Math.random() * 9) + 2;
      n2 = Math.floor(Math.random() * 9) + 2;
      correct = n1 * n2;
    }

    const wrongOptions = new Set<number>();
    while (wrongOptions.size < 3) {
      const delta = (Math.random() < 0.5 ? 1 : -1) * (Math.floor(Math.random() * 5) + 1);
      const wrong = correct + delta;
      if (wrong >= 0 && wrong !== correct) {
        wrongOptions.add(wrong);
      }
    }

    const options = [correct, ...Array.from(wrongOptions)].sort(() => Math.random() - 0.5);

    return {
      text: `${n1} ${op} ${n2} = ?`,
      options,
      correct,
    };
  }, []);

  const startGame = () => {
    setScore(0);
    setStreak(0);
    setTimeLeft(5.0);
    setIsGameOver(false);
    setIsPlaying(true);
    setFeedback(null);
    setQuestion(generateQuestion());
    sounds.playClick();
  };

  const handleAnswer = (val: number) => {
    if (!isPlaying || !question) return;

    if (val === question.correct) {
      sounds.playCoin();
      setFeedback('correct');
      const bonus = (streak + 1) * 10;
      const nextScore = score + bonus;
      setScore(nextScore);
      onScoreUpdate(nextScore);
      setStreak((prev) => prev + 1);
      setTimeLeft(4.5);
      setQuestion(generateQuestion());
    } else {
      sounds.playHit();
      setFeedback('wrong');
      setIsPlaying(false);
      setIsGameOver(true);
      sounds.playGameOver();
      if (score > highScore && score > 0) {
        confetti({ particleCount: 70, spread: 60 });
      }
    }
  };

  // Timer countdown
  useEffect(() => {
    if (isPlaying && !isGameOver) {
      timerRef.current = setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 0.1) {
            clearInterval(timerRef.current!);
            setIsPlaying(false);
            setIsGameOver(true);
            sounds.playGameOver();
            return 0;
          }
          return parseFloat((prev - 0.1).toFixed(1));
        });
      }, 100);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, isGameOver]);

  return (
    <div className="flex flex-col items-center justify-center w-full max-w-md mx-auto select-none">
      {/* Top bar */}
      <div className="grid grid-cols-3 gap-2 w-full mb-3 text-center">
        <div className="p-2.5 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="text-[10px] text-slate-400 font-bold uppercase">SCORE</div>
          <div className="text-xl font-black text-emerald-400">{score}</div>
        </div>
        <div className="p-2.5 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="text-[10px] text-slate-400 font-bold uppercase">STREAK</div>
          <div className="text-xl font-black text-amber-400 flex items-center justify-center gap-1">
            <Zap className="w-4 h-4 fill-current" />
            {streak}
          </div>
        </div>
        <div className="p-2.5 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="text-[10px] text-slate-400 font-bold uppercase">BEST</div>
          <div className="text-xl font-black text-white">{Math.max(score, highScore)}</div>
        </div>
      </div>

      {/* Main Game Card */}
      <div className="relative w-full aspect-[4/3] max-w-[380px] p-6 bg-slate-900/90 rounded-3xl border-2 border-slate-800 shadow-2xl backdrop-blur-md flex flex-col items-center justify-between">
        {!isPlaying || isGameOver ? (
          <div className="flex flex-col items-center justify-center h-full text-center space-y-4">
            {isGameOver ? (
              <>
                <div className="w-14 h-14 rounded-3xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-3xl text-red-400">
                  ⏱️
                </div>
                <div>
                  <h3 className="text-2xl font-black text-white">Time's Up or Wrong Answer!</h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Score: <span className="font-bold text-emerald-400">{score}</span> pts | Max Streak:{' '}
                    <span className="font-bold text-amber-400">{streak}</span>
                  </p>
                </div>
                <button
                  onClick={startGame}
                  className="px-8 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 text-slate-950 font-black shadow-xl shadow-emerald-500/25 flex items-center gap-2 cursor-pointer active:scale-95 text-sm"
                >
                  <RotateCcw className="w-4 h-4" />
                  Try Again
                </button>
              </>
            ) : (
              <>
                <div className="w-14 h-14 rounded-3xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-3xl text-emerald-400 animate-bounce">
                  ⚡
                </div>
                <div>
                  <h3 className="text-2xl font-black text-white">Speed Math Blitz</h3>
                  <p className="text-xs text-slate-400 mt-1">Answer rapid arithmetic before the clock expires!</p>
                </div>
                <button
                  onClick={startGame}
                  className="px-8 py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black shadow-xl shadow-emerald-500/25 flex items-center gap-2 text-base cursor-pointer active:scale-95"
                >
                  <Play className="w-5 h-5 fill-current" />
                  START CHALLENGE
                </button>
              </>
            )}
          </div>
        ) : (
          <>
            {/* Countdown bar */}
            <div className="w-full">
              <div className="flex justify-between items-center text-xs text-slate-400 mb-1.5 font-mono font-bold">
                <span>TIMER</span>
                <span className={timeLeft <= 1.5 ? 'text-red-400 font-bold animate-pulse' : 'text-slate-200'}>
                  {timeLeft.toFixed(1)}s
                </span>
              </div>
              <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
                <div
                  className={`h-full transition-all duration-100 ${
                    timeLeft <= 1.5 ? 'bg-red-500' : 'bg-gradient-to-r from-emerald-500 to-teal-400'
                  }`}
                  style={{ width: `${(timeLeft / 4.5) * 100}%` }}
                />
              </div>
            </div>

            {/* Question Display */}
            <div className="py-4">
              <div className="text-4xl font-black text-white font-mono tracking-wider text-center drop-shadow-md">
                {question?.text}
              </div>
            </div>

            {/* 4 Choices */}
            <div className="grid grid-cols-2 gap-3 w-full">
              {question?.options.map((opt, idx) => (
                <button
                  key={idx}
                  onClick={() => handleAnswer(opt)}
                  className="py-3.5 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 active:bg-emerald-600 active:text-slate-950 border border-slate-700 text-xl font-black text-white shadow-md transition-all active:scale-95 text-center font-mono cursor-pointer"
                >
                  {opt}
                </button>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
