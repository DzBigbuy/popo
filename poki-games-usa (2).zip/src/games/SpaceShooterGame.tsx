import React, { useEffect, useRef, useState } from 'react';
import { Play, RotateCcw, Heart, Shield, Trophy } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sounds } from '../utils/audio';

interface SpaceShooterProps {
  onScoreUpdate: (score: number) => void;
  highScore: number;
}

interface Bullet {
  x: number;
  y: number;
  speed: number;
  isTriple?: boolean;
}

interface Enemy {
  x: number;
  y: number;
  radius: number;
  speed: number;
  hp: number;
  type: 'asteroid' | 'alien';
  color: string;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  alpha: number;
  size: number;
}

interface Star {
  x: number;
  y: number;
  size: number;
  speed: number;
}

export const SpaceShooterGame: React.FC<SpaceShooterProps> = ({ onScoreUpdate, highScore }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [shieldActive, setShieldActive] = useState(false);

  const playerRef = useRef({
    x: 180,
    y: 330,
    width: 36,
    height: 36,
    speed: 6,
  });

  const bulletsRef = useRef<Bullet[]>([]);
  const enemiesRef = useRef<Enemy[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const starsRef = useRef<Star[]>([]);
  const keysRef = useRef<{ left: boolean; right: boolean; shoot: boolean }>({
    left: false,
    right: false,
    shoot: false,
  });
  const lastShotRef = useRef(0);
  const frameCountRef = useRef(0);

  // Initialize stars background
  useEffect(() => {
    const stars: Star[] = [];
    for (let i = 0; i < 45; i++) {
      stars.push({
        x: Math.random() * 400,
        y: Math.random() * 400,
        size: Math.random() * 2 + 1,
        speed: Math.random() * 2 + 0.5,
      });
    }
    starsRef.current = stars;
  }, []);

  const createExplosion = (x: number, y: number, color: string, count = 12) => {
    for (let i = 0; i < count; i++) {
      particlesRef.current.push({
        x,
        y,
        vx: (Math.random() - 0.5) * 8,
        vy: (Math.random() - 0.5) * 8,
        color,
        alpha: 1,
        size: Math.random() * 3 + 1,
      });
    }
  };

  const shoot = () => {
    const now = Date.now();
    if (now - lastShotRef.current < 200) return;
    lastShotRef.current = now;

    const p = playerRef.current;
    bulletsRef.current.push({
      x: p.x + p.width / 2,
      y: p.y - 4,
      speed: 9,
    });
    sounds.playLaser();
  };

  const startGame = () => {
    playerRef.current = {
      x: 180,
      y: 330,
      width: 36,
      height: 36,
      speed: 6,
    };
    bulletsRef.current = [];
    enemiesRef.current = [];
    particlesRef.current = [];
    setScore(0);
    setLives(3);
    setShieldActive(false);
    setIsGameOver(false);
    setIsPlaying(true);
    sounds.playClick();
  };

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['ArrowLeft', 'KeyA'].includes(e.code)) keysRef.current.left = true;
      if (['ArrowRight', 'KeyD'].includes(e.code)) keysRef.current.right = true;
      if (['Space', 'ArrowUp', 'KeyW'].includes(e.code)) {
        e.preventDefault();
        shoot();
      }
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      if (['ArrowLeft', 'KeyA'].includes(e.code)) keysRef.current.left = false;
      if (['ArrowRight', 'KeyD'].includes(e.code)) keysRef.current.right = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  });

  // Touch / mouse steering
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const relativeX = (e.clientX - rect.left) * (canvas.width / rect.width);
    playerRef.current.x = Math.max(0, Math.min(canvas.width - playerRef.current.width, relativeX - playerRef.current.width / 2));
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas || !e.touches[0]) return;
    const rect = canvas.getBoundingClientRect();
    const relativeX = (e.touches[0].clientX - rect.left) * (canvas.width / rect.width);
    playerRef.current.x = Math.max(0, Math.min(canvas.width - playerRef.current.width, relativeX - playerRef.current.width / 2));
  };

  // Game Loop
  useEffect(() => {
    if (!isPlaying) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const loop = () => {
      frameCountRef.current += 1;

      // Update Starfield
      starsRef.current.forEach((star) => {
        star.y += star.speed;
        if (star.y > canvas.height) {
          star.y = 0;
          star.x = Math.random() * canvas.width;
        }
      });

      // Player Movement
      const player = playerRef.current;
      if (keysRef.current.left && player.x > 0) {
        player.x -= player.speed;
      }
      if (keysRef.current.right && player.x < canvas.width - player.width) {
        player.x += player.speed;
      }

      // Spawn Enemies
      if (frameCountRef.current % 45 === 0) {
        const isAlien = Math.random() < 0.35;
        enemiesRef.current.push({
          x: Math.random() * (canvas.width - 40) + 20,
          y: -20,
          radius: isAlien ? 14 : Math.random() * 8 + 10,
          speed: isAlien ? 2.8 : Math.random() * 2 + 1.5,
          hp: isAlien ? 2 : 1,
          type: isAlien ? 'alien' : 'asteroid',
          color: isAlien ? '#ec4899' : '#94a3b8',
        });
      }

      // Update Bullets
      bulletsRef.current.forEach((b, bIdx) => {
        b.y -= b.speed;
        if (b.y < -10) bulletsRef.current.splice(bIdx, 1);
      });

      // Update Enemies & Collision
      enemiesRef.current.forEach((enemy, eIdx) => {
        enemy.y += enemy.speed;

        // Check bullet hit
        bulletsRef.current.forEach((bullet, bIdx) => {
          const dist = Math.hypot(bullet.x - enemy.x, bullet.y - enemy.y);
          if (dist < enemy.radius + 6) {
            bulletsRef.current.splice(bIdx, 1);
            enemy.hp -= 1;

            if (enemy.hp <= 0) {
              enemiesRef.current.splice(eIdx, 1);
              createExplosion(enemy.x, enemy.y, enemy.color);
              sounds.playCoin();

              const pts = enemy.type === 'alien' ? 30 : 15;
              setScore((prev) => {
                const nextScore = prev + pts;
                onScoreUpdate(nextScore);
                return nextScore;
              });
            } else {
              sounds.playHit();
            }
          }
        });

        // Check Player hit
        const playerCenterX = player.x + player.width / 2;
        const playerCenterY = player.y + player.height / 2;
        const playerDist = Math.hypot(playerCenterX - enemy.x, playerCenterY - enemy.y);

        if (playerDist < enemy.radius + player.width * 0.4) {
          enemiesRef.current.splice(eIdx, 1);
          createExplosion(enemy.x, enemy.y, '#ef4444', 20);
          sounds.playHit();

          setLives((prev) => {
            const next = prev - 1;
            if (next <= 0) {
              setIsPlaying(false);
              setIsGameOver(true);
              sounds.playGameOver();
              if (score > highScore && score > 0) {
                confetti({ particleCount: 80, spread: 70 });
              }
            }
            return next;
          });
        }

        // Remove offscreen
        if (enemy.y > canvas.height + 30) {
          enemiesRef.current.splice(eIdx, 1);
        }
      });

      // Update Particles
      particlesRef.current.forEach((p, pIdx) => {
        p.x += p.vx;
        p.y += p.vy;
        p.alpha -= 0.04;
        if (p.alpha <= 0) {
          particlesRef.current.splice(pIdx, 1);
        }
      });

      // DRAWING
      ctx.fillStyle = '#050711';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Stars
      ctx.fillStyle = '#ffffff';
      starsRef.current.forEach((s) => {
        ctx.fillRect(s.x, s.y, s.size, s.size);
      });

      // Draw Bullets
      bulletsRef.current.forEach((b) => {
        ctx.save();
        ctx.fillStyle = '#38bdf8';
        ctx.shadowColor = '#0284c7';
        ctx.shadowBlur = 10;
        ctx.fillRect(b.x - 2, b.y, 4, 12);
        ctx.restore();
      });

      // Draw Enemies
      enemiesRef.current.forEach((enemy) => {
        ctx.save();
        ctx.fillStyle = enemy.color;
        ctx.shadowColor = enemy.color;
        ctx.shadowBlur = 10;
        ctx.beginPath();
        if (enemy.type === 'alien') {
          // Alien craft
          ctx.ellipse(enemy.x, enemy.y, enemy.radius * 1.3, enemy.radius * 0.8, 0, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#ffffff';
          ctx.beginPath();
          ctx.arc(enemy.x, enemy.y - 2, 4, 0, Math.PI * 2);
          ctx.fill();
        } else {
          // Asteroid
          ctx.arc(enemy.x, enemy.y, enemy.radius, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      });

      // Draw Player Spaceship
      ctx.save();
      ctx.translate(player.x + player.width / 2, player.y + player.height / 2);

      // Jet trail
      ctx.fillStyle = '#38bdf8';
      ctx.shadowColor = '#60a5fa';
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.moveTo(-6, player.height / 2);
      ctx.lineTo(0, player.height / 2 + 10);
      ctx.lineTo(6, player.height / 2);
      ctx.fill();

      // Ship body
      ctx.fillStyle = '#6366f1';
      ctx.beginPath();
      ctx.moveTo(0, -player.height / 2);
      ctx.lineTo(player.width / 2, player.height / 2);
      ctx.lineTo(0, player.height / 3);
      ctx.lineTo(-player.width / 2, player.height / 2);
      ctx.closePath();
      ctx.fill();

      // Cockpit
      ctx.fillStyle = '#a5b4fc';
      ctx.beginPath();
      ctx.arc(0, -2, 5, 0, Math.PI * 2);
      ctx.fill();

      ctx.restore();

      // Draw Particles
      particlesRef.current.forEach((p) => {
        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, score, highScore, onScoreUpdate]);

  return (
    <div className="flex flex-col items-center justify-center w-full max-w-lg mx-auto select-none">
      {/* Status Bar */}
      <div className="flex items-center justify-between w-full mb-3 px-4 py-2.5 rounded-2xl bg-slate-900/90 border border-slate-800 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <span className="text-indigo-400 font-bold text-lg">Score: {score}</span>
          <div className="flex items-center gap-1">
            {Array.from({ length: 3 }).map((_, i) => (
              <Heart
                key={i}
                className={`w-4 h-4 ${i < lives ? 'text-red-500 fill-red-500' : 'text-slate-700'}`}
              />
            ))}
          </div>
        </div>
        <div className="flex items-center gap-1.5 text-slate-400 text-sm">
          <Trophy className="w-4 h-4 text-amber-400" />
          <span>Best:</span>
          <span className="font-bold text-white">{Math.max(score, highScore)}</span>
        </div>
      </div>

      {/* Canvas */}
      <div className="relative w-full aspect-[4/3] max-w-[400px] rounded-3xl overflow-hidden border-2 border-slate-800 shadow-2xl shadow-indigo-950/30 bg-slate-950">
        <canvas
          ref={canvasRef}
          width={400}
          height={380}
          onMouseMove={handleMouseMove}
          onTouchMove={handleTouchMove}
          onClick={shoot}
          className="w-full h-full block cursor-crosshair"
        />

        {/* Start / Game Over Overlay */}
        {(!isPlaying || isGameOver) && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-10">
            {isGameOver ? (
              <div className="space-y-4">
                <div className="w-16 h-16 mx-auto rounded-3xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-3xl text-red-400">
                  🚀💥
                </div>
                <h3 className="text-2xl font-black text-white">Ship Destroyed!</h3>
                <p className="text-slate-300 text-sm">
                  Final Score: <span className="font-black text-indigo-400 text-base">{score}</span>
                </p>
                <button
                  onClick={startGame}
                  className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 text-white font-black shadow-xl shadow-indigo-500/30 flex items-center gap-2 mx-auto transition-all active:scale-95 cursor-pointer text-sm"
                >
                  <RotateCcw className="w-4 h-4" />
                  Try Again
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="w-16 h-16 mx-auto rounded-3xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-3xl text-indigo-400 animate-pulse">
                  🛸
                </div>
                <div>
                  <h3 className="text-2xl font-black text-white mb-1">Galaxy Space Defender</h3>
                  <p className="text-xs text-slate-400">Move ship, blast asteroids, eliminate alien invaders</p>
                </div>
                <button
                  onClick={startGame}
                  className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-400 text-white font-black shadow-xl shadow-indigo-500/30 flex items-center gap-2 mx-auto transition-all active:scale-95 cursor-pointer text-base"
                >
                  <Play className="w-5 h-5 fill-current" />
                  START MISSION
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Mobile action bar */}
      <div className="w-full max-w-[340px] mt-4 flex items-center justify-between sm:hidden">
        <div className="text-xs text-slate-400">Drag to maneuver</div>
        <button
          onClick={shoot}
          className="px-6 py-2.5 rounded-2xl bg-indigo-600 active:bg-indigo-500 text-white font-black text-sm shadow-md"
        >
          🔥 FIRE LASER
        </button>
      </div>
    </div>
  );
};
