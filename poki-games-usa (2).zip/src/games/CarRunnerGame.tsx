import React, { useState, useEffect, useRef } from 'react';
import { Play, RotateCcw, Trophy, Sparkles, Volume2, VolumeX, Car } from 'lucide-react';
import { sounds } from '../utils/audio';

interface CarRunnerGameProps {
  onScoreUpdate?: (score: number) => void;
  highScore?: number;
}

interface Obstacle {
  id: number;
  x: number;
  y: number;
  speed: number;
  color: string;
  lane: number;
}

export const CarRunnerGame: React.FC<CarRunnerGameProps> = ({
  onScoreUpdate,
  highScore = 0,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [playerLane, setPlayerLane] = useState(1); // 0: Left, 1: Center, 2: Right
  const [speed, setSpeed] = useState(5);
  const [obstacles, setObstacles] = useState<Obstacle[]>([]);

  const animFrameRef = useRef<number | null>(null);
  const lastSpawnRef = useRef<number>(0);
  const scoreRef = useRef(0);
  const laneRef = useRef(1);
  laneRef.current = playerLane;

  const LANES = [20, 50, 80]; // percentage positions

  const startGame = () => {
    sounds.playCoin();
    setScore(0);
    scoreRef.current = 0;
    setPlayerLane(1);
    laneRef.current = 1;
    setSpeed(5);
    setObstacles([]);
    setIsGameOver(false);
    setIsPlaying(true);
    lastSpawnRef.current = Date.now();
  };

  const moveLeft = () => {
    if (!isPlaying || isGameOver) return;
    sounds.playClick();
    setPlayerLane((prev) => Math.max(0, prev - 1));
  };

  const moveRight = () => {
    if (!isPlaying || isGameOver) return;
    sounds.playClick();
    setPlayerLane((prev) => Math.min(2, prev + 1));
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        moveLeft();
      } else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        moveRight();
      } else if (e.key === ' ' && (!isPlaying || isGameOver)) {
        startGame();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, isGameOver]);

  useEffect(() => {
    if (!isPlaying || isGameOver) return;

    let lastTime = performance.now();

    const loop = (time: number) => {
      const delta = (time - lastTime) / 1000;
      lastTime = time;

      // Spawn obstacles
      if (Date.now() - lastSpawnRef.current > Math.max(600, 1600 - scoreRef.current * 15)) {
        const lane = Math.floor(Math.random() * 3);
        const colors = ['#ef4444', '#f59e0b', '#06b6d4', '#ec4899', '#8b5cf6'];
        const randomColor = colors[Math.floor(Math.random() * colors.length)];
        
        setObstacles((prev) => [
          ...prev,
          {
            id: Date.now() + Math.random(),
            lane,
            x: LANES[lane],
            y: -15,
            speed: 35 + Math.random() * 15 + scoreRef.current * 0.4,
            color: randomColor,
          },
        ]);
        lastSpawnRef.current = Date.now();
      }

      // Move obstacles & check collision
      setObstacles((prev) => {
        const updated: Obstacle[] = [];
        let hit = false;

        for (const obs of prev) {
          const newY = obs.y + obs.speed * delta;

          // Check collision with player car (player is at y: 80%)
          if (obs.lane === laneRef.current && newY > 68 && newY < 88) {
            hit = true;
          }

          if (newY < 110) {
            updated.push({ ...obs, y: newY });
          } else {
            // Passed successfully!
            scoreRef.current += 10;
            setScore(scoreRef.current);
            onScoreUpdate?.(scoreRef.current);
            sounds.playCoin();
          }
        }

        if (hit) {
          sounds.playGameOver();
          setIsGameOver(true);
          setIsPlaying(false);
          return [];
        }

        return updated;
      });

      animFrameRef.current = requestAnimationFrame(loop);
    };

    animFrameRef.current = requestAnimationFrame(loop);

    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, [isPlaying, isGameOver]);

  return (
    <div className="flex flex-col items-center justify-center p-2 sm:p-4 w-full max-w-lg mx-auto select-none">
      {/* Top Header */}
      <div className="flex items-center justify-between w-full mb-3 px-4 py-2 rounded-2xl bg-black/40 backdrop-blur-xl border border-white/10">
        <div className="flex items-center gap-2">
          <Car className="w-5 h-5 text-amber-400" />
          <span className="font-bold text-sm text-white">Highway Car Rush</span>
        </div>
        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="text-slate-300">
            Score: <span className="text-amber-400 font-bold text-base">{score}</span>
          </div>
          <div className="text-slate-400">
            Best: <span className="text-emerald-400 font-bold">{highScore}</span>
          </div>
        </div>
      </div>

      {/* Road Highway Canvas Container */}
      <div className="relative w-full h-[400px] rounded-3xl overflow-hidden bg-slate-900 border-4 border-slate-800 shadow-2xl">
        {/* Road Lane Lines with moving dash animation */}
        <div className="absolute inset-0 flex justify-between px-[33%] pointer-events-none">
          <div className="w-1.5 h-full border-r-2 border-dashed border-yellow-400/40 animate-pulse" />
          <div className="w-1.5 h-full border-r-2 border-dashed border-yellow-400/40 animate-pulse" />
        </div>

        {/* Road curb sides */}
        <div className="absolute top-0 bottom-0 left-0 w-3 bg-gradient-to-r from-red-600 to-white opacity-50" />
        <div className="absolute top-0 bottom-0 right-0 w-3 bg-gradient-to-l from-red-600 to-white opacity-50" />

        {/* Obstacle Cars */}
        {obstacles.map((obs) => (
          <div
            key={obs.id}
            className="absolute -translate-x-1/2 flex flex-col items-center transition-all duration-75"
            style={{
              left: `${obs.x}%`,
              top: `${obs.y}%`,
            }}
          >
            <div
              className="w-10 h-16 rounded-xl border-2 border-black/40 shadow-lg flex flex-col items-center justify-between p-1"
              style={{ backgroundColor: obs.color }}
            >
              <div className="w-7 h-2 bg-cyan-200/80 rounded-sm" />
              <div className="text-[9px] font-black text-black/50">CPU</div>
              <div className="w-7 h-2 bg-red-400/80 rounded-sm" />
            </div>
          </div>
        ))}

        {/* Player Car */}
        {isPlaying && (
          <div
            className="absolute bottom-[12%] -translate-x-1/2 transition-all duration-150 ease-out"
            style={{
              left: `${LANES[playerLane]}%`,
            }}
          >
            <div className="w-12 h-20 rounded-2xl bg-gradient-to-t from-indigo-700 via-indigo-500 to-cyan-400 border-2 border-cyan-300 shadow-2xl flex flex-col items-center justify-between p-1.5 ring-4 ring-cyan-500/30">
              <div className="w-8 h-3 bg-cyan-100 rounded-md shadow-sm" />
              <span className="text-[10px] font-black text-white tracking-widest">YOU</span>
              <div className="w-8 h-2 bg-red-500 rounded-sm" />
            </div>
          </div>
        )}

        {/* Start / Game Over Overlay */}
        {(!isPlaying || isGameOver) && (
          <div className="absolute inset-0 z-30 bg-black/85 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center">
            {isGameOver ? (
              <div className="space-y-4">
                <div className="w-16 h-16 mx-auto rounded-full bg-red-500/20 border border-red-500/50 flex items-center justify-center text-3xl">
                  💥
                </div>
                <h3 className="text-2xl font-black text-white">Crash! Game Over</h3>
                <p className="text-sm text-slate-300 font-mono">
                  Final Score: <span className="text-amber-400 font-bold text-lg">{score}</span>
                </p>
                <button
                  onClick={startGame}
                  className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 text-black font-black text-sm shadow-xl cursor-pointer active:scale-95 transition-all"
                >
                  Play Again 🚗
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="w-16 h-16 mx-auto rounded-3xl bg-indigo-600/30 border border-indigo-400/50 flex items-center justify-center text-3xl shadow-xl">
                  🏎️
                </div>
                <h3 className="text-2xl font-black text-white">Highway Car Rush</h3>
                <p className="text-xs text-slate-300 max-w-xs leading-relaxed">
                  Switch lanes swiftly with Arrow keys or A/D to dodge high-speed oncoming traffic!
                </p>
                <button
                  onClick={startGame}
                  className="px-8 py-3.5 rounded-2xl bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-black text-base shadow-xl shadow-cyan-400/30 cursor-pointer active:scale-95 transition-all"
                >
                  START RACE 🚀
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Mobile Touch Controls */}
      <div className="grid grid-cols-2 gap-4 w-full mt-4">
        <button
          onClick={moveLeft}
          className="py-4 rounded-2xl bg-white/10 hover:bg-white/20 active:bg-cyan-500/30 border border-white/10 text-white font-black text-base flex items-center justify-center gap-2 cursor-pointer shadow-lg active:scale-95 transition-all"
        >
          <span>⬅️ LEFT (A)</span>
        </button>
        <button
          onClick={moveRight}
          className="py-4 rounded-2xl bg-white/10 hover:bg-white/20 active:bg-cyan-500/30 border border-white/10 text-white font-black text-base flex items-center justify-center gap-2 cursor-pointer shadow-lg active:scale-95 transition-all"
        >
          <span>RIGHT (D) ➡️</span>
        </button>
      </div>
    </div>
  );
};
