import React, { useState, useEffect, useCallback } from 'react';
import { RotateCcw, Sparkles, Trophy, Clock, Zap } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sounds } from '../utils/audio';

interface MemoryMatchProps {
  onScoreUpdate: (score: number) => void;
  highScore: number;
}

interface Card {
  id: number;
  icon: string;
  isFlipped: boolean;
  isMatched: boolean;
}

const CARD_ICONS = ['🎮', '🕹️', '👾', '🚀', '⭐', '💎', '🔥', '🏆'];

export const MemoryMatchGame: React.FC<MemoryMatchProps> = ({ onScoreUpdate, highScore }) => {
  const [cards, setCards] = useState<Card[]>([]);
  const [flippedCards, setFlippedCards] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [matches, setMatches] = useState(0);
  const [score, setScore] = useState(0);
  const [seconds, setSeconds] = useState(0);
  const [isGameActive, setIsGameActive] = useState(false);
  const [isWon, setIsWon] = useState(false);
  const [combo, setCombo] = useState(1);

  const initGame = useCallback(() => {
    // Generate pairs of icons and shuffle
    const paired = [...CARD_ICONS, ...CARD_ICONS];
    const shuffled = paired
      .sort(() => Math.random() - 0.5)
      .map((icon, index) => ({
        id: index,
        icon,
        isFlipped: false,
        isMatched: false,
      }));

    setCards(shuffled);
    setFlippedCards([]);
    setMoves(0);
    setMatches(0);
    setScore(0);
    setSeconds(0);
    setIsWon(false);
    setIsGameActive(true);
    setCombo(1);
    sounds.playClick();
  }, []);

  useEffect(() => {
    initGame();
  }, [initGame]);

  // Timer
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (isGameActive && !isWon) {
      interval = setInterval(() => {
        setSeconds((prev) => prev + 1);
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isGameActive, isWon]);

  const handleCardClick = (cardId: number) => {
    if (!isGameActive || flippedCards.length === 2) return;

    const clickedCard = cards.find((c) => c.id === cardId);
    if (!clickedCard || clickedCard.isFlipped || clickedCard.isMatched) return;

    sounds.playCardFlip();

    const newCards = cards.map((c) => (c.id === cardId ? { ...c, isFlipped: true } : c));
    setCards(newCards);

    const newFlipped = [...flippedCards, cardId];
    setFlippedCards(newFlipped);

    if (newFlipped.length === 2) {
      setMoves((prev) => prev + 1);
      const [firstId, secondId] = newFlipped;
      const firstCard = cards.find((c) => c.id === firstId);
      const secondCard = cards.find((c) => c.id === secondId);

      if (firstCard && secondCard && firstCard.icon === secondCard.icon) {
        // Matched!
        setTimeout(() => {
          sounds.playWin();
          const matchPoints = 100 * combo;
          setScore((prev) => {
            const updated = prev + matchPoints;
            onScoreUpdate(updated);
            return updated;
          });
          setCombo((prev) => prev + 1);

          setCards((prev) =>
            prev.map((c) => (c.id === firstId || c.id === secondId ? { ...c, isMatched: true } : c))
          );
          setFlippedCards([]);
          setMatches((prev) => {
            const nextMatches = prev + 1;
            if (nextMatches === CARD_ICONS.length) {
              setIsWon(true);
              setIsGameActive(false);
              confetti({ particleCount: 90, spread: 70 });
            }
            return nextMatches;
          });
        }, 400);
      } else {
        // Not matched
        setCombo(1);
        setTimeout(() => {
          sounds.playHit();
          setCards((prev) =>
            prev.map((c) => (c.id === firstId || c.id === secondId ? { ...c, isFlipped: false } : c))
          );
          setFlippedCards([]);
        }, 900);
      }
    }
  };

  const formatTime = (secs: number) => {
    const m = Math.floor(secs / 60);
    const s = secs % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="flex flex-col items-center justify-center w-full max-w-md mx-auto select-none">
      {/* Stats bar */}
      <div className="grid grid-cols-4 gap-2 w-full mb-4 text-center">
        <div className="p-2.5 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="text-[10px] text-slate-400 font-bold uppercase">SCORE</div>
          <div className="text-lg font-black text-cyan-400">{score}</div>
        </div>
        <div className="p-2.5 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="text-[10px] text-slate-400 font-bold uppercase">MOVES</div>
          <div className="text-lg font-black text-white">{moves}</div>
        </div>
        <div className="p-2.5 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="text-[10px] text-slate-400 font-bold uppercase">TIME</div>
          <div className="text-lg font-black text-amber-400 flex items-center justify-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            {formatTime(seconds)}
          </div>
        </div>
        <div className="p-2.5 rounded-2xl bg-slate-900/80 border border-slate-800">
          <div className="text-[10px] text-slate-400 font-bold uppercase">COMBO</div>
          <div className="text-lg font-black text-emerald-400 flex items-center justify-center gap-0.5">
            <Zap className="w-3.5 h-3.5" />
            {combo}x
          </div>
        </div>
      </div>

      {/* 4x4 Grid */}
      <div className="relative grid grid-cols-4 gap-2.5 w-full aspect-square max-w-[360px] p-3 bg-slate-900/80 rounded-3xl border-2 border-slate-800 shadow-2xl backdrop-blur-md">
        {cards.map((card) => (
          <button
            key={card.id}
            onClick={() => handleCardClick(card.id)}
            disabled={card.isFlipped || card.isMatched || flippedCards.length === 2}
            className={`relative rounded-2xl font-bold text-3xl flex items-center justify-center transition-all duration-300 transform aspect-square cursor-pointer ${
              card.isMatched
                ? 'bg-emerald-950/60 border border-emerald-500/40 text-emerald-400 opacity-90 scale-95'
                : card.isFlipped
                ? 'bg-gradient-to-br from-cyan-600 to-blue-700 border border-cyan-400 text-white shadow-lg shadow-cyan-500/30 rotate-0'
                : 'bg-slate-800 hover:bg-slate-700 border border-slate-700/80 text-slate-500 active:scale-95 shadow-md'
            }`}
          >
            {card.isFlipped || card.isMatched ? (
              <span className="animate-scale-in">{card.icon}</span>
            ) : (
              <span className="text-slate-600 font-black text-xl select-none">?</span>
            )}
          </button>
        ))}

        {/* Win overlay */}
        {isWon && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md rounded-3xl flex flex-col items-center justify-center p-6 text-center z-10 animate-fade-in">
            <div className="w-16 h-16 rounded-3xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-3xl text-cyan-400 animate-bounce mb-3">
              🎉
            </div>
            <h3 className="text-2xl font-black text-white mb-1">Super Memory! You Won!</h3>
            <p className="text-slate-300 text-sm mb-4">
              Cleared in <span className="text-amber-400 font-bold">{formatTime(seconds)}</span> with{' '}
              <span className="text-cyan-400 font-bold">{moves}</span> moves.
            </p>
            <button
              onClick={initGame}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 text-white font-black shadow-lg shadow-cyan-500/25 flex items-center gap-2 transition-all active:scale-95 text-sm cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              Play Again
            </button>
          </div>
        )}
      </div>

      <div className="mt-4 flex items-center justify-between w-full px-2">
        <div className="flex items-center gap-1 text-xs text-slate-400 font-semibold">
          <Trophy className="w-3.5 h-3.5 text-amber-400" />
          <span>Best Score: {Math.max(score, highScore)}</span>
        </div>
        <button
          onClick={initGame}
          className="px-4 py-2 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 flex items-center gap-1.5 transition-all cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Reshuffle
        </button>
      </div>
    </div>
  );
};
