import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Play,
  RotateCcw,
  Zap,
  Gauge,
  Flame,
  Volume2,
  Trophy,
  ArrowLeft,
  ArrowRight,
  Sun,
  Sunset,
  Moon,
  Camera,
  Car,
  Settings,
  ShieldAlert,
  Sparkles,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { sounds } from '../utils/audio';

interface RacingLimitsProps {
  onScoreUpdate: (score: number) => void;
  highScore: number;
}

type EnvironmentMode = 'day' | 'sunset' | 'night';
type TrafficDensity = 'normal' | 'rush_hour' | 'two_way';

interface TrafficCar {
  id: number;
  lane: number; // 0, 1, 2, 3
  z: number; // distance from player (0 to 1000)
  speed: number;
  color: string;
  type: 'sedan' | 'suv' | 'truck' | 'taxi' | 'sports';
  width: number;
  length: number;
  isTwoWay?: boolean;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  alpha: number;
  life: number;
}

const CAR_SKINS = [
  { id: 'red', name: 'Rosso Speedster', color: '#ef4444', accent: '#991b1b', neon: '#f87171' },
  { id: 'cyan', name: 'Cyber Turbo GT', color: '#06b6d4', accent: '#0e7490', neon: '#38bdf8' },
  { id: 'gold', name: 'Apex Gold Edition', color: '#f59e0b', accent: '#b45309', neon: '#fbbf24' },
  { id: 'emerald', name: 'Phantom Emerald', color: '#10b981', accent: '#047857', neon: '#34d399' },
  { id: 'purple', name: 'Hyper Violet V12', color: '#a855f7', accent: '#6b21a8', neon: '#c084fc' },
];

export const RacingLimitsGame: React.FC<RacingLimitsProps> = ({ onScoreUpdate, highScore }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Game state
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [speedKmh, setSpeedKmh] = useState(0);
  const [nitro, setNitro] = useState(100);
  const [isNitroActive, setIsNitroActive] = useState(false);
  const [distanceKm, setDistanceKm] = useState(0);
  const [closeCalls, setCloseCalls] = useState(0);
  const [comboMultiplier, setComboMultiplier] = useState(1);
  const [envMode, setEnvMode] = useState<EnvironmentMode>('sunset');
  const [selectedCarIndex, setSelectedCarIndex] = useState(0);
  const [cameraMode, setCameraMode] = useState<'chase' | 'hood' | 'cinematic'>('chase');
  const [trafficMode, setTrafficMode] = useState<TrafficDensity>('normal');
  const [floatingText, setFloatingText] = useState<{ text: string; id: number; color: string }[]>([]);

  // Player state refs for physics loop
  const playerRef = useRef({
    x: 0, // -1 (left shoulder) to 1 (right shoulder)
    targetX: 0,
    speed: 0, // actual game speed units
    maxSpeed: 240,
    nitroMaxSpeed: 330,
    acceleration: 0.35,
    handling: 0.045,
    distance: 0,
    nitro: 100,
    steerAngle: 0,
    curveOffset: 0,
  });

  const keysRef = useRef<{ left: boolean; right: boolean; up: boolean; down: boolean; nitro: boolean }>({
    left: false,
    right: false,
    up: false,
    down: false,
    nitro: false,
  });

  const trafficRef = useRef<TrafficCar[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const curveRef = useRef(0);
  const nextCarId = useRef(1);
  const lastCloseCallTime = useRef(0);

  // Key listeners
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(e.key)) {
        e.preventDefault();
      }

      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') keysRef.current.left = true;
      if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') keysRef.current.right = true;
      if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') keysRef.current.up = true;
      if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') keysRef.current.down = true;
      if (e.key === ' ' || e.key === 'Shift') keysRef.current.nitro = true;
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') keysRef.current.left = false;
      if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') keysRef.current.right = false;
      if (e.key === 'ArrowUp' || e.key === 'w' || e.key === 'W') keysRef.current.up = false;
      if (e.key === 'ArrowDown' || e.key === 's' || e.key === 'S') keysRef.current.down = false;
      if (e.key === ' ' || e.key === 'Shift') keysRef.current.nitro = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const spawnTraffic = useCallback(() => {
    const lanes = [-0.65, -0.22, 0.22, 0.65];
    const availableLanes = lanes.filter((lane) => {
      return !trafficRef.current.some((car) => Math.abs(car.lane - lane) < 0.2 && car.z > 800);
    });

    if (availableLanes.length === 0) return;

    const chosenLane = availableLanes[Math.floor(Math.random() * availableLanes.length)];
    const types: TrafficCar['type'][] = ['sedan', 'suv', 'truck', 'taxi', 'sports'];
    const type = types[Math.floor(Math.random() * types.length)];
    const colors = ['#3b82f6', '#ef4444', '#10b981', '#f59e0b', '#e2e8f0', '#64748b', '#1e293b'];

    let speed = 90 + Math.random() * 40;
    let length = 45;
    let width = 26;

    if (type === 'truck') {
      length = 80;
      width = 30;
      speed = 70 + Math.random() * 20;
    } else if (type === 'sports') {
      speed = 130 + Math.random() * 30;
    } else if (type === 'taxi') {
      speed = 100;
    }

    const isTwoWay = trafficMode === 'two_way' && chosenLane < 0;

    trafficRef.current.push({
      id: nextCarId.current++,
      lane: chosenLane,
      z: 1000,
      speed: isTwoWay ? -speed : speed,
      color: type === 'taxi' ? '#eab308' : colors[Math.floor(Math.random() * colors.length)],
      type,
      width,
      length,
      isTwoWay,
    });
  }, [trafficMode]);

  const startGame = () => {
    playerRef.current = {
      x: 0,
      targetX: 0,
      speed: 80,
      maxSpeed: 250,
      nitroMaxSpeed: 330,
      acceleration: 0.45,
      handling: 0.05,
      distance: 0,
      nitro: 100,
      steerAngle: 0,
      curveOffset: 0,
    };
    trafficRef.current = [];
    particlesRef.current = [];
    setScore(0);
    setCloseCalls(0);
    setDistanceKm(0);
    setComboMultiplier(1);
    setNitro(100);
    setIsGameOver(false);
    setIsPlaying(true);
    setFloatingText([]);
    sounds.playClick();
  };

  const triggerCloseCall = (x: number, y: number) => {
    sounds.playOvertake();
    setCloseCalls((prev) => prev + 1);
    setComboMultiplier((prev) => Math.min(prev + 1, 8));
    const bonus = 150 * comboMultiplier;
    setScore((prev) => {
      const next = prev + bonus;
      onScoreUpdate(next);
      return next;
    });

    const newId = Date.now() + Math.random();
    setFloatingText((prev) => [
      ...prev.slice(-3),
      {
        text: `+${bonus} CLOSE PASS! ${comboMultiplier > 1 ? `x${comboMultiplier}` : ''}`,
        id: newId,
        color: '#38bdf8',
      },
    ]);

    setTimeout(() => {
      setFloatingText((prev) => prev.filter((t) => t.id !== newId));
    }, 1200);
  };

  // Main Canvas Render Loop
  useEffect(() => {
    if (!isPlaying) return;

    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let lastTime = performance.now();

    const loop = (currentTime: number) => {
      const dt = Math.min((currentTime - lastTime) / 1000, 0.1);
      lastTime = currentTime;

      const p = playerRef.current;
      const keys = keysRef.current;

      // Handle Inputs & Nitro
      const isNitro = keys.nitro && p.nitro > 5;
      setIsNitroActive(isNitro);

      if (isNitro) {
        p.nitro = Math.max(0, p.nitro - 22 * dt);
        if (Math.random() < 0.3) sounds.playNitro();
      } else {
        p.nitro = Math.min(100, p.nitro + 8 * dt);
      }
      setNitro(Math.round(p.nitro));

      // Acceleration / Braking
      const currentMax = isNitro ? p.nitroMaxSpeed : p.maxSpeed;
      if (keys.up) {
        p.speed = Math.min(currentMax, p.speed + (isNitro ? 75 : 35) * dt);
      } else if (keys.down) {
        p.speed = Math.max(30, p.speed - 90 * dt);
      } else {
        // Natural drag
        if (p.speed > 160) p.speed -= 15 * dt;
      }

      // Steering
      let targetSteer = 0;
      if (keys.left) {
        p.x = Math.max(-0.95, p.x - p.handling * (p.speed / 120) * dt * 60);
        targetSteer = -0.3;
      }
      if (keys.right) {
        p.x = Math.min(0.95, p.x + p.handling * (p.speed / 120) * dt * 60);
        targetSteer = 0.3;
      }
      p.steerAngle += (targetSteer - p.steerAngle) * 0.15;

      // Road distance
      p.distance += (p.speed * dt) / 3600; // km
      setDistanceKm(parseFloat(p.distance.toFixed(2)));
      setSpeedKmh(Math.round(p.speed));

      // Score accumulation based on speed
      const speedPoints = Math.round((p.speed / 20) * dt * 10 * comboMultiplier);
      if (speedPoints > 0) {
        setScore((prev) => {
          const next = prev + speedPoints;
          onScoreUpdate(next);
          return next;
        });
      }

      // Road curves simulation
      curveRef.current += (p.speed * dt * 0.0008);
      const currentCurve = Math.sin(curveRef.current) * 0.4;
      p.curveOffset += currentCurve * 0.5;

      // Traffic Spawning
      if (Math.random() < 0.035 * (trafficMode === 'rush_hour' ? 1.8 : 1.0)) {
        spawnTraffic();
      }

      // Update Traffic
      for (let i = trafficRef.current.length - 1; i >= 0; i--) {
        const car = trafficRef.current[i];
        // Relative speed to player
        const relSpeed = p.speed - car.speed;
        car.z -= relSpeed * dt * 12;

        // Check for collision or near miss
        if (car.z > -20 && car.z < 60) {
          const lateralDist = Math.abs(car.lane - p.x);

          // Collision Check
          if (lateralDist < 0.28 && car.z > -10 && car.z < 45) {
            sounds.playHit();
            sounds.playGameOver();
            setIsPlaying(false);
            setIsGameOver(true);
            if (score > highScore && score > 0) {
              confetti({ particleCount: 100, spread: 70, origin: { y: 0.6 } });
            }
            return;
          }

          // Near Miss / Close Call Check
          if (lateralDist >= 0.28 && lateralDist < 0.48 && currentTime - lastCloseCallTime.current > 600) {
            lastCloseCallTime.current = currentTime;
            triggerCloseCall(car.lane, car.z);
          }
        }

        // Remove off-screen traffic
        if (car.z < -100 || car.z > 1200) {
          trafficRef.current.splice(i, 1);
        }
      }

      // Render Canvas
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      // 1. SKY & HORIZON
      const isNight = envMode === 'night';
      const isSunset = envMode === 'sunset';

      let skyGrad = ctx.createLinearGradient(0, 0, 0, height * 0.5);
      if (isNight) {
        skyGrad.addColorStop(0, '#05070e');
        skyGrad.addColorStop(1, '#0f172a');
      } else if (isSunset) {
        skyGrad.addColorStop(0, '#4c0519');
        skyGrad.addColorStop(0.5, '#9a3412');
        skyGrad.addColorStop(1, '#fbbf24');
      } else {
        skyGrad.addColorStop(0, '#0284c7');
        skyGrad.addColorStop(0.7, '#38bdf8');
        skyGrad.addColorStop(1, '#bae6fd');
      }
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, width, height * 0.5);

      // Horizon City Skyline / Mountains
      ctx.fillStyle = isNight ? '#090d16' : isSunset ? '#291007' : '#0369a1';
      for (let i = 0; i < 15; i++) {
        const bx = i * (width / 12) + (p.curveOffset * 20) % (width / 12);
        const bw = width / 14;
        const bh = 20 + ((i * 37) % 55);
        ctx.fillRect(bx, height * 0.5 - bh, bw, bh);

        // Windows if night
        if (isNight) {
          ctx.fillStyle = '#fde047';
          for (let w = 0; w < 3; w++) {
            if ((i + w) % 2 === 0) {
              ctx.fillRect(bx + 4 + w * 6, height * 0.5 - bh + 6, 3, 4);
            }
          }
          ctx.fillStyle = '#090d16';
        }
      }

      // 2. 3D HIGHWAY ROAD
      const horizonY = height * 0.5;
      const roadBottomW = width * 0.92;
      const roadTopW = width * 0.12;

      // Grass/Shoulder
      ctx.fillStyle = isNight ? '#0b1120' : isSunset ? '#1c1917' : '#065f46';
      ctx.fillRect(0, horizonY, width, height * 0.5);

      // Asphalt Road Polygon
      const roadGrad = ctx.createLinearGradient(0, horizonY, 0, height);
      roadGrad.addColorStop(0, '#1e293b');
      roadGrad.addColorStop(1, '#0f172a');
      ctx.fillStyle = roadGrad;

      ctx.beginPath();
      ctx.moveTo(width * 0.5 - roadTopW * 0.5 + currentCurve * 40, horizonY);
      ctx.lineTo(width * 0.5 + roadTopW * 0.5 + currentCurve * 40, horizonY);
      ctx.lineTo(width * 0.5 + roadBottomW * 0.5, height);
      ctx.lineTo(width * 0.5 - roadBottomW * 0.5, height);
      ctx.closePath();
      ctx.fill();

      // Guardrails
      ctx.strokeStyle = isNight ? '#38bdf8' : '#e2e8f0';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.moveTo(width * 0.5 - roadTopW * 0.5 + currentCurve * 40, horizonY);
      ctx.lineTo(width * 0.5 - roadBottomW * 0.5, height);
      ctx.moveTo(width * 0.5 + roadTopW * 0.5 + currentCurve * 40, horizonY);
      ctx.lineTo(width * 0.5 + roadBottomW * 0.5, height);
      ctx.stroke();

      // Road Lane Dashed Markings
      const laneCount = 4;
      const speedOffset = (p.distance * 10000) % 80;

      ctx.strokeStyle = '#f8fafc';
      ctx.lineWidth = 2.5;

      for (let l = 1; l < laneCount; l++) {
        const laneRatio = (l / laneCount) - 0.5;

        for (let seg = 0; seg < 25; seg++) {
          const z1 = (seg * 40 - speedOffset + 1000) % 1000;
          const z2 = z1 + 20;

          if (z1 < 5) continue;

          const p1 = project3D(laneRatio * 2, z1, width, height, horizonY, roadTopW, roadBottomW, currentCurve);
          const p2 = project3D(laneRatio * 2, z2, width, height, horizonY, roadTopW, roadBottomW, currentCurve);

          ctx.beginPath();
          ctx.moveTo(p1.x, p1.y);
          ctx.lineTo(p2.x, p2.y);
          ctx.stroke();
        }
      }

      // 3. DRAW TRAFFIC CARS (Sorted by Z back-to-front)
      const sortedTraffic = [...trafficRef.current].sort((a, b) => b.z - a.z);

      sortedTraffic.forEach((car) => {
        if (car.z < 5 || car.z > 950) return;

        const proj = project3D(car.lane, car.z, width, height, horizonY, roadTopW, roadBottomW, currentCurve);
        const scale = proj.scale;
        const carW = car.width * scale * 2.8;
        const carH = car.length * scale * 1.8;

        // Shadow
        ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
        ctx.beginPath();
        ctx.ellipse(proj.x, proj.y + carH * 0.4, carW * 0.6, carH * 0.25, 0, 0, Math.PI * 2);
        ctx.fill();

        // Car Body
        ctx.fillStyle = car.color;
        ctx.beginPath();
        ctx.roundRect(proj.x - carW * 0.5, proj.y - carH * 0.5, carW, carH, 4 * scale);
        ctx.fill();

        // Roof / Windshield
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.roundRect(proj.x - carW * 0.38, proj.y - carH * 0.25, carW * 0.76, carH * 0.45, 3 * scale);
        ctx.fill();

        // Taillights
        ctx.fillStyle = '#ef4444';
        ctx.shadowColor = '#ef4444';
        ctx.shadowBlur = isNight ? 10 : 2;
        ctx.fillRect(proj.x - carW * 0.45, proj.y + carH * 0.38, carW * 0.25, carH * 0.1);
        ctx.fillRect(proj.x + carW * 0.2, proj.y + carH * 0.38, carW * 0.25, carH * 0.1);
        ctx.shadowBlur = 0;
      });

      // 4. DRAW PLAYER SUPERCAR
      const playerSkin = CAR_SKINS[selectedCarIndex];
      const playerScreenX = width * 0.5 + p.x * (roadBottomW * 0.42);
      const playerScreenY = height * 0.82;
      const pScale = 1.35;
      const pW = 54 * pScale;
      const pH = 85 * pScale;

      ctx.save();
      ctx.translate(playerScreenX, playerScreenY);
      ctx.rotate(p.steerAngle);

      // Nitro Flame Thruster
      if (isNitro) {
        ctx.fillStyle = '#38bdf8';
        ctx.shadowColor = '#38bdf8';
        ctx.shadowBlur = 20;
        ctx.beginPath();
        ctx.moveTo(-pW * 0.25, pH * 0.45);
        ctx.lineTo(-pW * 0.15, pH * 0.75 + Math.random() * 15);
        ctx.lineTo(-pW * 0.05, pH * 0.45);
        ctx.fill();

        ctx.beginPath();
        ctx.moveTo(pW * 0.05, pH * 0.45);
        ctx.lineTo(pW * 0.15, pH * 0.75 + Math.random() * 15);
        ctx.lineTo(pW * 0.25, pH * 0.45);
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      // Car Shadow
      ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
      ctx.beginPath();
      ctx.ellipse(0, pH * 0.4, pW * 0.65, pH * 0.22, 0, 0, Math.PI * 2);
      ctx.fill();

      // Main Chassis
      const bodyGrad = ctx.createLinearGradient(-pW * 0.5, 0, pW * 0.5, 0);
      bodyGrad.addColorStop(0, playerSkin.accent);
      bodyGrad.addColorStop(0.5, playerSkin.color);
      bodyGrad.addColorStop(1, playerSkin.accent);
      ctx.fillStyle = bodyGrad;

      ctx.beginPath();
      ctx.roundRect(-pW * 0.5, -pH * 0.5, pW, pH, 12);
      ctx.fill();

      // Roof Carbon & Windshield
      ctx.fillStyle = '#090d16';
      ctx.beginPath();
      ctx.roundRect(-pW * 0.38, -pH * 0.25, pW * 0.76, pH * 0.45, 8);
      ctx.fill();

      // Racing Stripes / Accents
      ctx.fillStyle = playerSkin.neon;
      ctx.fillRect(-2, -pH * 0.45, 4, pH * 0.85);

      // Rear Spoiler Wing
      ctx.fillStyle = '#020617';
      ctx.fillRect(-pW * 0.48, pH * 0.36, pW * 0.96, 7);

      // Bright LED Taillights
      ctx.fillStyle = '#f43f5e';
      ctx.shadowColor = '#f43f5e';
      ctx.shadowBlur = isNight || isNitro ? 16 : 6;
      ctx.fillRect(-pW * 0.45, pH * 0.42, pW * 0.32, 6);
      ctx.fillRect(pW * 0.13, pH * 0.42, pW * 0.32, 6);
      ctx.shadowBlur = 0;

      ctx.restore();

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, envMode, selectedCarIndex, trafficMode, comboMultiplier, score, highScore, onScoreUpdate, spawnTraffic]);

  // Helper 3D Projection
  const project3D = (
    laneRatio: number,
    z: number,
    width: number,
    height: number,
    horizonY: number,
    topW: number,
    botW: number,
    curve: number
  ) => {
    const scale = Math.max(0.05, (1000 - z) / 1000);
    const y = horizonY + (height - horizonY) * Math.pow(scale, 1.6);
    const currentRoadW = topW + (botW - topW) * scale;
    const curveOffset = (1 - scale) * curve * 50;
    const x = width * 0.5 + laneRatio * (currentRoadW * 0.45) + curveOffset;

    return { x, y, scale };
  };

  return (
    <div className="flex flex-col items-center justify-center w-full max-w-2xl mx-auto select-none font-sans">
      {/* Top HUD Controls & Modes */}
      <div className="flex flex-wrap items-center justify-between w-full mb-3 gap-2 px-2">
        <div className="flex items-center gap-2">
          {/* Time of day toggles */}
          <div className="flex bg-slate-900 border border-slate-800 rounded-2xl p-1 shadow-md">
            <button
              onClick={() => setEnvMode('day')}
              className={`p-1.5 rounded-xl transition-all ${
                envMode === 'day' ? 'bg-sky-500 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
              title="Day Mode"
            >
              <Sun className="w-4 h-4" />
            </button>
            <button
              onClick={() => setEnvMode('sunset')}
              className={`p-1.5 rounded-xl transition-all ${
                envMode === 'sunset' ? 'bg-amber-500 text-slate-950 font-bold shadow-md' : 'text-slate-400 hover:text-white'
              }`}
              title="Sunset Golden Hour"
            >
              <Sunset className="w-4 h-4" />
            </button>
            <button
              onClick={() => setEnvMode('night')}
              className={`p-1.5 rounded-xl transition-all ${
                envMode === 'night' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
              title="Neon Night Highway"
            >
              <Moon className="w-4 h-4" />
            </button>
          </div>

          {/* Traffic density mode */}
          <button
            onClick={() => {
              sounds.playClick();
              setTrafficMode((prev) => (prev === 'normal' ? 'rush_hour' : prev === 'rush_hour' ? 'two_way' : 'normal'));
            }}
            className="px-3 py-1.5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-cyan-400 text-xs font-black text-slate-200 flex items-center gap-1.5 transition-all shadow-md cursor-pointer"
          >
            <Car className="w-3.5 h-3.5 text-cyan-400" />
            <span>
              {trafficMode === 'normal' ? 'Traffic: Regular' : trafficMode === 'rush_hour' ? 'Rush Hour 🚗' : 'Two-Way ⚡'}
            </span>
          </button>
        </div>

        {/* High score pill */}
        <div className="flex items-center gap-2 px-4 py-1.5 rounded-2xl bg-slate-900 border border-slate-800 text-xs font-mono">
          <Trophy className="w-3.5 h-3.5 text-amber-400" />
          <span className="text-slate-400">BEST:</span>
          <span className="font-black text-amber-400">{Math.max(score, highScore)}</span>
        </div>
      </div>

      {/* Main Racing Canvas Stage */}
      <div className="relative w-full aspect-[16/10] max-w-[560px] rounded-3xl overflow-hidden border-2 border-slate-800 shadow-2xl bg-slate-950">
        <canvas
          ref={canvasRef}
          width={560}
          height={350}
          className="w-full h-full block"
        />

        {/* Live In-Game HUD Elements */}
        {isPlaying && !isGameOver && (
          <>
            {/* Top Left Speedometer & Distance */}
            <div className="absolute top-4 left-4 flex flex-col gap-1 p-3 rounded-2xl bg-slate-950/80 border border-slate-800/80 backdrop-blur-md font-mono shadow-xl">
              <div className="flex items-baseline gap-1.5">
                <span className="text-3xl font-black text-white">{speedKmh}</span>
                <span className="text-[11px] text-cyan-400 font-bold uppercase">KM/H</span>
              </div>
              <div className="text-[11px] text-slate-400">
                DIST: <span className="font-bold text-slate-200">{distanceKm} km</span>
              </div>
            </div>

            {/* Top Right Score & Close Passes */}
            <div className="absolute top-4 right-4 flex flex-col items-end gap-1 p-3 rounded-2xl bg-slate-950/80 border border-slate-800/80 backdrop-blur-md font-mono shadow-xl text-right">
              <div className="text-xl font-black text-emerald-400">{score}</div>
              <div className="flex items-center gap-1.5 text-xs text-amber-400 font-bold">
                <Zap className="w-3.5 h-3.5 fill-current" />
                <span>{closeCalls} Close Passes</span>
              </div>
            </div>

            {/* Floating Near-Miss Combos */}
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
              {floatingText.map((t) => (
                <div
                  key={t.id}
                  className="text-lg font-black text-cyan-300 drop-shadow-[0_0_12px_rgba(6,182,212,0.8)] animate-bounce"
                >
                  {t.text}
                </div>
              ))}
            </div>

            {/* Bottom Nitro Bar */}
            <div className="absolute bottom-4 left-4 right-4 max-w-xs mx-auto flex flex-col gap-1 p-2 rounded-2xl bg-slate-950/90 border border-slate-800 backdrop-blur-md">
              <div className="flex justify-between items-center text-[10px] font-black tracking-widest text-cyan-300 px-1 font-mono">
                <span className="flex items-center gap-1">
                  <Flame className="w-3.5 h-3.5 text-cyan-400 fill-cyan-400" />
                  NITRO N2O
                </span>
                <span>{nitro}%</span>
              </div>
              <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden border border-cyan-500/20">
                <div
                  className={`h-full transition-all duration-75 ${
                    isNitroActive
                      ? 'bg-gradient-to-r from-cyan-400 to-blue-400 shadow-lg shadow-cyan-400'
                      : 'bg-cyan-500'
                  }`}
                  style={{ width: `${nitro}%` }}
                />
              </div>
            </div>
          </>
        )}

        {/* Start / Game Over Overlay */}
        {(!isPlaying || isGameOver) && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center z-20">
            {isGameOver ? (
              <div className="space-y-4 max-w-sm">
                <div className="w-16 h-16 mx-auto rounded-3xl bg-rose-500/20 border border-rose-500/40 flex items-center justify-center text-3xl text-rose-400 animate-bounce">
                  💥
                </div>
                <div>
                  <h3 className="text-2xl font-black text-white">HIGHWAY CRASH!</h3>
                  <p className="text-xs text-slate-400 mt-1">
                    Score: <span className="font-bold text-emerald-400">{score}</span> | Distance:{' '}
                    <span className="font-bold text-cyan-400">{distanceKm} km</span> | Passes:{' '}
                    <span className="font-bold text-amber-400">{closeCalls}</span>
                  </p>
                </div>

                <button
                  onClick={startGame}
                  className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 text-white font-black shadow-xl shadow-cyan-500/30 flex items-center gap-2 mx-auto transition-all active:scale-95 cursor-pointer text-sm"
                >
                  <RotateCcw className="w-4 h-4" />
                  RACE AGAIN
                </button>
              </div>
            ) : (
              <div className="space-y-4 max-w-md">
                <div className="w-16 h-16 mx-auto rounded-3xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-4xl shadow-xl shadow-cyan-500/20">
                  🏎️
                </div>
                <div>
                  <h3 className="text-2xl sm:text-3xl font-black text-white tracking-tight">RACING LIMITS 3D</h3>
                  <p className="text-xs text-slate-300 mt-1">
                    High-speed highway racer with close-call overtake bonuses, nitro blasts, and dynamic traffic!
                  </p>
                </div>

                {/* Car Skin Selector */}
                <div className="flex items-center justify-center gap-2 py-2">
                  {CAR_SKINS.map((skin, idx) => (
                    <button
                      key={skin.id}
                      onClick={() => {
                        sounds.playClick();
                        setSelectedCarIndex(idx);
                      }}
                      className={`w-8 h-8 rounded-full border-2 transition-transform cursor-pointer ${
                        selectedCarIndex === idx ? 'scale-125 border-white shadow-lg shadow-cyan-500/50 ring-2 ring-cyan-400' : 'border-slate-700 opacity-60 hover:opacity-100'
                      }`}
                      style={{ backgroundColor: skin.color }}
                      title={skin.name}
                    />
                  ))}
                </div>
                <div className="text-[11px] font-bold text-cyan-400">
                  Selected: {CAR_SKINS[selectedCarIndex].name}
                </div>

                <button
                  onClick={startGame}
                  className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-cyan-400 via-blue-500 to-indigo-600 hover:from-cyan-300 text-slate-950 font-black shadow-xl shadow-cyan-400/30 flex items-center gap-2 mx-auto transition-all active:scale-95 cursor-pointer text-base"
                >
                  <Play className="w-5 h-5 fill-slate-950" />
                  START ENGINE & RACE
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* On-Screen Touch Controls for Mobile / Responsive */}
      <div className="grid grid-cols-4 gap-2 w-full max-w-[560px] mt-3">
        <button
          onMouseDown={() => (keysRef.current.left = true)}
          onMouseUp={() => (keysRef.current.left = false)}
          onTouchStart={() => (keysRef.current.left = true)}
          onTouchEnd={() => (keysRef.current.left = false)}
          className="py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 active:bg-cyan-500 active:text-slate-950 border border-slate-800 text-white font-black text-xs flex items-center justify-center gap-1 cursor-pointer transition-all active:scale-95 shadow-md"
        >
          <ArrowLeft className="w-4 h-4" />
          LEFT
        </button>

        <button
          onMouseDown={() => (keysRef.current.right = true)}
          onMouseUp={() => (keysRef.current.right = false)}
          onTouchStart={() => (keysRef.current.right = true)}
          onTouchEnd={() => (keysRef.current.right = false)}
          className="py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 active:bg-cyan-500 active:text-slate-950 border border-slate-800 text-white font-black text-xs flex items-center justify-center gap-1 cursor-pointer transition-all active:scale-95 shadow-md"
        >
          RIGHT
          <ArrowRight className="w-4 h-4" />
        </button>

        <button
          onMouseDown={() => (keysRef.current.down = true)}
          onMouseUp={() => (keysRef.current.down = false)}
          onTouchStart={() => (keysRef.current.down = true)}
          onTouchEnd={() => (keysRef.current.down = false)}
          className="py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 active:bg-rose-500 active:text-white border border-slate-800 text-slate-300 font-black text-xs flex items-center justify-center gap-1 cursor-pointer transition-all active:scale-95 shadow-md"
        >
          BRAKE
        </button>

        <button
          onMouseDown={() => (keysRef.current.nitro = true)}
          onMouseUp={() => (keysRef.current.nitro = false)}
          onTouchStart={() => (keysRef.current.nitro = true)}
          onTouchEnd={() => (keysRef.current.nitro = false)}
          className="py-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 active:from-cyan-300 text-slate-950 font-black text-xs flex items-center justify-center gap-1 cursor-pointer transition-all active:scale-95 shadow-lg shadow-cyan-500/20"
        >
          <Flame className="w-4 h-4 fill-slate-950" />
          NITRO N2O
        </button>
      </div>

      <div className="mt-3 text-xs text-slate-400 text-center font-medium">
        💡 Controls: <span className="text-slate-200">A / D or Arrow Keys</span> to steer |{' '}
        <span className="text-slate-200">W / Up</span> to gas | <span className="text-slate-200">S / Down</span> to brake |{' '}
        <span className="text-cyan-400 font-bold">Spacebar / Shift</span> for Nitro Boost
      </div>
    </div>
  );
};
