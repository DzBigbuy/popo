import React, { useState, useEffect, useCallback, useRef } from 'react';
import { RotateCcw, Undo2, Trophy, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sounds } from '../utils/audio';

interface Game2048Props {
  onScoreUpdate: (score: number) => void;
  highScore: number;
}

type Board = number[][];

export const Game2048: React.FC<Game2048Props> = ({ onScoreUpdate, highScore }) => {
  const [board, setBoard] = useState<Board>([
    [0, 0, 0, 0],
    [0, 0, 0, 0],
    [0, 0, 0, 0],
    [0, 0, 0, 0],
  ]);
  const [score, setScore] = useState(0);
  const [previousState, setPreviousState] = useState<{ board: Board; score: number } | null>(null);
  const [isGameOver, setIsGameOver] = useState(false);
  const [isWon, setIsWon] = useState(false);

  const touchStartRef = useRef<{ x: number; y: number } | null>(null);

  const getEmptyCells = (currentBoard: Board) => {
    const cells: { r: number; c: number }[] = [];
    for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 4; c++) {
        if (currentBoard[r][c] === 0) cells.push({ r, c });
      }
    }
    return cells;
  };

  const addRandomTile = (currentBoard: Board): Board => {
    const emptyCells = getEmptyCells(currentBoard);
    if (emptyCells.length === 0) return currentBoard;
    const { r, c } = emptyCells[Math.floor(Math.random() * emptyCells.length)];
    const val = Math.random() < 0.9 ? 2 : 4;
    const newBoard = currentBoard.map((row) => [...row]);
    newBoard[r][c] = val;
    return newBoard;
  };

  const initGame = useCallback(() => {
    let newBoard: Board = [
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
      [0, 0, 0, 0],
    ];
    newBoard = addRandomTile(newBoard);
    newBoard = addRandomTile(newBoard);
    setBoard(newBoard);
    setScore(0);
    setPreviousState(null);
    setIsGameOver(false);
    setIsWon(false);
    sounds.playClick();
  }, []);

  useEffect(() => {
    initGame();
  }, [initGame]);

  const slideAndMergeRow = (row: number[]): { newRow: number[]; gainedScore: number; merged: boolean } => {
    const filtered = row.filter((val) => val !== 0);
    const result: number[] = [];
    let gainedScore = 0;
    let merged = false;

    let i = 0;
    while (i < filtered.length) {
      if (i + 1 < filtered.length && filtered[i] === filtered[i + 1]) {
        const newVal = filtered[i] * 2;
        result.push(newVal);
        gainedScore += newVal;
        merged = true;
        i += 2;
      } else {
        result.push(filtered[i]);
        i += 1;
      }
    }

    while (result.length < 4) {
      result.push(0);
    }

    return { newRow: result, gainedScore, merged };
  };

  const checkGameOver = (currentBoard: Board): boolean => {
    // Check if any empty cell
    if (getEmptyCells(currentBoard).length > 0) return false;

    // Check horizontal/vertical merges
    for (let r = 0; r < 4; r++) {
      for (let c = 0; c < 4; c++) {
        const val = currentBoard[r][c];
        if (c + 1 < 4 && val === currentBoard[r][c + 1]) return false;
        if (r + 1 < 4 && val === currentBoard[r + 1][c]) return false;
      }
    }
    return true;
  };

  const move = useCallback(
    (direction: 'UP' | 'DOWN' | 'LEFT' | 'RIGHT') => {
      if (isGameOver) return;

      let changed = false;
      let newScore = score;
      let newBoard: Board = board.map((row) => [...row]);
      let anyMerged = false;

      // Save undo state
      setPreviousState({
        board: board.map((r) => [...r]),
        score,
      });

      if (direction === 'LEFT') {
        for (let r = 0; r < 4; r++) {
          const { newRow, gainedScore, merged } = slideAndMergeRow(newBoard[r]);
          if (newRow.some((val, idx) => val !== newBoard[r][idx])) changed = true;
          if (merged) anyMerged = true;
          newBoard[r] = newRow;
          newScore += gainedScore;
        }
      } else if (direction === 'RIGHT') {
        for (let r = 0; r < 4; r++) {
          const reversed = [...newBoard[r]].reverse();
          const { newRow, gainedScore, merged } = slideAndMergeRow(reversed);
          const finalRow = newRow.reverse();
          if (finalRow.some((val, idx) => val !== newBoard[r][idx])) changed = true;
          if (merged) anyMerged = true;
          newBoard[r] = finalRow;
          newScore += gainedScore;
        }
      } else if (direction === 'UP') {
        for (let c = 0; c < 4; c++) {
          const column = [newBoard[0][c], newBoard[1][c], newBoard[2][c], newBoard[3][c]];
          const { newRow, gainedScore, merged } = slideAndMergeRow(column);
          for (let r = 0; r < 4; r++) {
            if (newBoard[r][c] !== newRow[r]) changed = true;
            newBoard[r][c] = newRow[r];
          }
          if (merged) anyMerged = true;
          newScore += gainedScore;
        }
      } else if (direction === 'DOWN') {
        for (let c = 0; c < 4; c++) {
          const column = [newBoard[0][c], newBoard[1][c], newBoard[2][c], newBoard[3][c]].reverse();
          const { newRow, gainedScore, merged } = slideAndMergeRow(column);
          const finalCol = newRow.reverse();
          for (let r = 0; r < 4; r++) {
            if (newBoard[r][c] !== finalCol[r]) changed = true;
            newBoard[r][c] = finalCol[r];
          }
          if (merged) anyMerged = true;
          newScore += gainedScore;
        }
      }

      if (changed) {
        if (anyMerged) {
          sounds.playCoin();
        } else {
          sounds.playClick();
        }

        const boardWithNewTile = addRandomTile(newBoard);
        setBoard(boardWithNewTile);
        setScore(newScore);
        onScoreUpdate(newScore);

        // Check 2048 tile win
        if (!isWon && boardWithNewTile.some((row) => row.includes(2048))) {
          setIsWon(true);
          sounds.playWin();
          confetti({ particleCount: 100, spread: 80 });
        }

        if (checkGameOver(boardWithNewTile)) {
          setIsGameOver(true);
          sounds.playGameOver();
        }
      }
    },
    [board, score, isGameOver, isWon, onScoreUpdate]
  );

  // Undo move
  const undoMove = () => {
    if (previousState) {
      setBoard(previousState.board);
      setScore(previousState.score);
      setPreviousState(null);
      setIsGameOver(false);
      sounds.playClick();
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['ArrowLeft', 'KeyA'].includes(e.code)) {
        e.preventDefault();
        move('LEFT');
      } else if (['ArrowRight', 'KeyD'].includes(e.code)) {
        e.preventDefault();
        move('RIGHT');
      } else if (['ArrowUp', 'KeyW'].includes(e.code)) {
        e.preventDefault();
        move('UP');
      } else if (['ArrowDown', 'KeyS'].includes(e.code)) {
        e.preventDefault();
        move('DOWN');
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [move]);

  // Touch Swipe handlers
  const onTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length > 0) {
      touchStartRef.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    }
  };

  const onTouchEnd = (e: React.TouchEvent) => {
    if (!touchStartRef.current || e.changedTouches.length === 0) return;
    const dx = e.changedTouches[0].clientX - touchStartRef.current.x;
    const dy = e.changedTouches[0].clientY - touchStartRef.current.y;
    const absDx = Math.abs(dx);
    const absDy = Math.abs(dy);

    if (Math.max(absDx, absDy) > 25) {
      if (absDx > absDy) {
        move(dx > 0 ? 'RIGHT' : 'LEFT');
      } else {
        move(dy > 0 ? 'DOWN' : 'UP');
      }
    }
    touchStartRef.current = null;
  };

  // Tile styling map
  const getTileStyle = (val: number) => {
    switch (val) {
      case 2:
        return 'bg-slate-800 text-slate-100 border border-slate-700';
      case 4:
        return 'bg-amber-950/60 text-amber-200 border border-amber-800/60';
      case 8:
        return 'bg-orange-600 text-white shadow-md shadow-orange-500/20';
      case 16:
        return 'bg-orange-500 text-white shadow-md shadow-orange-500/30';
      case 32:
        return 'bg-rose-600 text-white shadow-md shadow-rose-500/30';
      case 64:
        return 'bg-rose-500 text-white shadow-md shadow-rose-500/40';
      case 128:
        return 'bg-amber-500 text-slate-950 font-black shadow-lg shadow-amber-500/40';
      case 256:
        return 'bg-yellow-400 text-slate-950 font-black shadow-lg shadow-yellow-400/50';
      case 512:
        return 'bg-emerald-500 text-slate-950 font-black shadow-lg shadow-emerald-500/50';
      case 1024:
        return 'bg-cyan-400 text-slate-950 font-black shadow-xl shadow-cyan-400/50';
      case 2048:
        return 'bg-gradient-to-tr from-amber-400 via-pink-500 to-purple-500 text-white font-black shadow-2xl shadow-purple-500/60 animate-pulse';
      default:
        return 'bg-gradient-to-tr from-indigo-500 to-purple-600 text-white font-black';
    }
  };

  return (
    <div
      onTouchStart={onTouchStart}
      onTouchEnd={onTouchEnd}
      className="flex flex-col items-center justify-center w-full max-w-md mx-auto select-none"
    >
      {/* Top bar with Score and Controls */}
      <div className="flex items-center justify-between w-full mb-3 gap-2">
        <div className="flex items-center gap-2">
          <div className="px-3.5 py-1.5 rounded-2xl bg-slate-900 border border-slate-800 text-center min-w-[80px]">
            <div className="text-[10px] text-slate-400 font-bold uppercase">SCORE</div>
            <div className="text-base font-black text-violet-400">{score}</div>
          </div>
          <div className="px-3.5 py-1.5 rounded-2xl bg-slate-900 border border-slate-800 text-center min-w-[80px]">
            <div className="text-[10px] text-slate-400 font-bold uppercase">BEST</div>
            <div className="text-base font-black text-white">{Math.max(score, highScore)}</div>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <button
            onClick={undoMove}
            disabled={!previousState}
            className="p-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-slate-200 border border-slate-700 transition-all active:scale-95 cursor-pointer"
            title="Undo Move"
          >
            <Undo2 className="w-4 h-4" />
          </button>
          <button
            onClick={initGame}
            className="p-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all active:scale-95 cursor-pointer"
            title="New Game"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* 4x4 Grid Container */}
      <div className="relative grid grid-cols-4 gap-2.5 w-full aspect-square max-w-[360px] p-3 bg-slate-900/90 rounded-3xl border-2 border-slate-800 shadow-2xl backdrop-blur-md">
        {board.map((row, r) =>
          row.map((cell, c) => (
            <div
              key={`${r}-${c}`}
              className={`relative rounded-2xl flex items-center justify-center font-black text-2xl transition-all duration-150 aspect-square ${
                cell === 0 ? 'bg-slate-800/40 border border-slate-800/50' : getTileStyle(cell)
              }`}
            >
              {cell !== 0 && <span className="animate-scale-in">{cell}</span>}
            </div>
          ))
        )}

        {/* Game Over / Win Overlay */}
        {isGameOver && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md rounded-3xl flex flex-col items-center justify-center p-6 text-center z-10 animate-fade-in">
            <h3 className="text-2xl font-black text-white mb-2">No Moves Left!</h3>
            <p className="text-slate-400 text-xs mb-4">Final Score: {score}</p>
            <button
              onClick={initGame}
              className="px-6 py-3 rounded-2xl bg-violet-600 hover:bg-violet-500 text-white font-black text-sm shadow-xl shadow-violet-600/30 flex items-center gap-2 cursor-pointer active:scale-95"
            >
              <RotateCcw className="w-4 h-4" />
              Try Again
            </button>
          </div>
        )}
      </div>

      {/* Touch virtual directional controls */}
      <div className="w-full max-w-[260px] mt-4 flex flex-col items-center gap-1.5 sm:hidden">
        <button
          onClick={() => move('UP')}
          className="w-12 h-10 rounded-xl bg-slate-800 active:bg-violet-600 active:text-white text-slate-200 border border-slate-700 flex items-center justify-center font-bold"
        >
          ▲
        </button>
        <div className="flex gap-4">
          <button
            onClick={() => move('LEFT')}
            className="w-12 h-10 rounded-xl bg-slate-800 active:bg-violet-600 active:text-white text-slate-200 border border-slate-700 flex items-center justify-center font-bold"
          >
            ◀
          </button>
          <button
            onClick={() => move('DOWN')}
            className="w-12 h-10 rounded-xl bg-slate-800 active:bg-violet-600 active:text-white text-slate-200 border border-slate-700 flex items-center justify-center font-bold"
          >
            ▼
          </button>
          <button
            onClick={() => move('RIGHT')}
            className="w-12 h-10 rounded-xl bg-slate-800 active:bg-violet-600 active:text-white text-slate-200 border border-slate-700 flex items-center justify-center font-bold"
          >
            ▶
          </button>
        </div>
      </div>
    </div>
  );
};
