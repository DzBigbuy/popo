import React, { useState, useEffect, useCallback } from 'react';
import { RotateCcw, Trophy, Sparkles, Flame } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sounds } from '../utils/audio';

interface BlockPuzzleGameProps {
  onScoreUpdate: (score: number) => void;
  highScore: number;
}

const GRID_SIZE = 8;

interface Shape {
  id: string;
  matrix: number[][];
  color: string;
  glow: string;
}

const SHAPES_POOL: Omit<Shape, 'id'>[] = [
  { matrix: [[1]], color: '#f59e0b', glow: 'rgba(245, 158, 11, 0.6)' }, // 1x1
  { matrix: [[1, 1]], color: '#3b82f6', glow: 'rgba(59, 130, 246, 0.6)' }, // 1x2
  { matrix: [[1], [1]], color: '#3b82f6', glow: 'rgba(59, 130, 246, 0.6)' }, // 2x1
  { matrix: [[1, 1, 1]], color: '#10b981', glow: 'rgba(16, 185, 129, 0.6)' }, // 1x3
  { matrix: [[1], [1], [1]], color: '#10b981', glow: 'rgba(16, 185, 129, 0.6)' }, // 3x1
  { matrix: [[1, 1, 1, 1]], color: '#06b6d4', glow: 'rgba(6, 182, 212, 0.6)' }, // 1x4
  { matrix: [[1], [1], [1], [1]], color: '#06b6d4', glow: 'rgba(6, 182, 212, 0.6)' }, // 4x1
  {
    matrix: [
      [1, 1],
      [1, 1],
    ],
    color: '#ec4899',
    glow: 'rgba(236, 72, 153, 0.6)',
  }, // 2x2
  {
    matrix: [
      [1, 1, 1],
      [1, 1, 1],
      [1, 1, 1],
    ],
    color: '#8b5cf6',
    glow: 'rgba(139, 92, 246, 0.6)',
  }, // 3x3
  {
    matrix: [
      [1, 0],
      [1, 1],
    ],
    color: '#f97316',
    glow: 'rgba(249, 115, 22, 0.6)',
  }, // L-shape
  {
    matrix: [
      [0, 1],
      [1, 1],
    ],
    color: '#f97316',
    glow: 'rgba(249, 115, 22, 0.6)',
  },
  {
    matrix: [
      [1, 1],
      [1, 0],
    ],
    color: '#f97316',
    glow: 'rgba(249, 115, 22, 0.6)',
  },
  {
    matrix: [
      [1, 1],
      [0, 1],
    ],
    color: '#f97316',
    glow: 'rgba(249, 115, 22, 0.6)',
  },
  {
    matrix: [
      [1, 1, 1],
      [0, 1, 0],
    ],
    color: '#a855f7',
    glow: 'rgba(168, 85, 247, 0.6)',
  }, // T-shape
];

export const BlockPuzzleGame: React.FC<BlockPuzzleGameProps> = ({ onScoreUpdate, highScore }) => {
  const [grid, setGrid] = useState<string[][]>(() =>
    Array(GRID_SIZE)
      .fill(null)
      .map(() => Array(GRID_SIZE).fill(''))
  );
  const [availableShapes, setAvailableShapes] = useState<Shape[]>([]);
  const [selectedShapeIndex, setSelectedShapeIndex] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [combo, setCombo] = useState(0);
  const [isGameOver, setIsGameOver] = useState(false);

  const spawnShapes = useCallback(() => {
    const newShapes: Shape[] = [];
    for (let i = 0; i < 3; i++) {
      const randomBase = SHAPES_POOL[Math.floor(Math.random() * SHAPES_POOL.length)];
      newShapes.push({
        ...randomBase,
        id: `shape-${Date.now()}-${i}-${Math.random()}`,
      });
    }
    setAvailableShapes(newShapes);
    setSelectedShapeIndex(null);
  }, []);

  const canPlaceShape = (shape: Shape, r: number, c: number, currentGrid: string[][]): boolean => {
    const rows = shape.matrix.length;
    const cols = shape.matrix[0].length;

    if (r + rows > GRID_SIZE || c + cols > GRID_SIZE) return false;

    for (let dr = 0; dr < rows; dr++) {
      for (let dc = 0; dc < cols; dc++) {
        if (shape.matrix[dr][dc] === 1) {
          if (currentGrid[r + dr][c + dc] !== '') return false;
        }
      }
    }
    return true;
  };

  const hasAnyValidMoves = (shapes: Shape[], currentGrid: string[][]): boolean => {
    for (const shape of shapes) {
      for (let r = 0; r < GRID_SIZE; r++) {
        for (let c = 0; c < GRID_SIZE; c++) {
          if (canPlaceShape(shape, r, c, currentGrid)) return true;
        }
      }
    }
    return false;
  };

  const initGame = useCallback(() => {
    const freshGrid = Array(GRID_SIZE)
      .fill(null)
      .map(() => Array(GRID_SIZE).fill(''));
    setGrid(freshGrid);
    setScore(0);
    setCombo(0);
    setIsGameOver(false);
    spawnShapes();
    sounds.playClick();
  }, [spawnShapes]);

  useEffect(() => {
    initGame();
  }, [initGame]);

  const handleCellClick = (r: number, c: number) => {
    if (isGameOver || selectedShapeIndex === null) return;
    const shape = availableShapes[selectedShapeIndex];
    if (!shape) return;

    if (!canPlaceShape(shape, r, c, grid)) {
      sounds.playHit();
      return;
    }

    // Place Shape
    sounds.playCoin();
    const newGrid = grid.map((row) => [...row]);
    let placedBlocksCount = 0;

    for (let dr = 0; dr < shape.matrix.length; dr++) {
      for (let dc = 0; dc < shape.matrix[0].length; dc++) {
        if (shape.matrix[dr][dc] === 1) {
          newGrid[r + dr][c + dc] = shape.color;
          placedBlocksCount++;
        }
      }
    }

    // Check rows and columns to clear
    const fullRows: number[] = [];
    const fullCols: number[] = [];

    for (let row = 0; row < GRID_SIZE; row++) {
      if (newGrid[row].every((cell) => cell !== '')) fullRows.push(row);
    }

    for (let col = 0; col < GRID_SIZE; col++) {
      let isFull = true;
      for (let row = 0; row < GRID_SIZE; row++) {
        if (newGrid[row][col] === '') {
          isFull = false;
          break;
        }
      }
      if (isFull) fullCols.push(col);
    }

    const totalLinesCleared = fullRows.length + fullCols.length;

    // Clear filled rows & cols
    if (totalLinesCleared > 0) {
      sounds.playBadgeEarned();
      fullRows.forEach((row) => {
        for (let col = 0; col < GRID_SIZE; col++) newGrid[row][col] = '';
      });
      fullCols.forEach((col) => {
        for (let row = 0; row < GRID_SIZE; row++) newGrid[row][col] = '';
      });

      confetti({
        particleCount: 40 * totalLinesCleared,
        spread: 60,
        origin: { y: 0.6 },
      });
    }

    // Calculate score
    const newCombo = totalLinesCleared > 0 ? combo + 1 : 0;
    setCombo(newCombo);

    const linesScore = totalLinesCleared * 100 * (totalLinesCleared + newCombo);
    const addedScore = placedBlocksCount * 10 + linesScore;
    const updatedScore = score + addedScore;
    setScore(updatedScore);
    onScoreUpdate(updatedScore);

    // Remove used shape
    const remainingShapes = availableShapes.filter((_, idx) => idx !== selectedShapeIndex);
    setSelectedShapeIndex(null);
    setGrid(newGrid);

    // If all 3 used, spawn 3 new
    let nextShapes = remainingShapes;
    if (remainingShapes.length === 0) {
      const newSpawned: Shape[] = [];
      for (let i = 0; i < 3; i++) {
        const randomBase = SHAPES_POOL[Math.floor(Math.random() * SHAPES_POOL.length)];
        newSpawned.push({
          ...randomBase,
          id: `shape-${Date.now()}-${i}-${Math.random()}`,
        });
      }
      nextShapes = newSpawned;
      setAvailableShapes(nextShapes);
    } else {
      setAvailableShapes(remainingShapes);
    }

    // Check game over
    if (!hasAnyValidMoves(nextShapes, newGrid)) {
      setIsGameOver(true);
      sounds.playGameOver();
    }
  };

  return (
    <div className="flex flex-col items-center justify-between w-full max-w-xl mx-auto p-4 sm:p-6 bg-slate-950 text-white select-none">
      {/* Header bar */}
      <div className="w-full flex items-center justify-between gap-2 mb-4">
        <div className="flex items-center gap-2">
          <div className="px-3 py-1.5 rounded-xl bg-blue-900/60 border border-blue-500/40 text-blue-200 font-black text-sm flex items-center gap-1">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span>بلوك بازل</span>
          </div>
          {combo > 1 && (
            <div className="px-2.5 py-1 rounded-xl bg-amber-500/20 border border-amber-500/50 text-amber-300 font-extrabold text-xs flex items-center gap-1 animate-pulse">
              <Flame className="w-3.5 h-3.5 text-orange-400" />
              <span>كومبو x{combo}!</span>
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          <div className="px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 font-black text-sm flex items-center gap-1.5">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>{score}</span>
          </div>
          {highScore > 0 && (
            <div className="text-[11px] text-slate-400 font-semibold hidden sm:block">
              أفضل: {highScore}
            </div>
          )}
        </div>
      </div>

      {/* 8x8 Grid Area */}
      <div className="relative p-2 sm:p-3 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-2xl backdrop-blur-xs">
        <div
          className="grid gap-1 sm:gap-1.5"
          style={{ gridTemplateColumns: `repeat(${GRID_SIZE}, minmax(0, 1fr))` }}
        >
          {grid.map((row, r) =>
            row.map((cellColor, c) => {
              const isFilled = cellColor !== '';
              return (
                <button
                  key={`${r}-${c}`}
                  onClick={() => handleCellClick(r, c)}
                  className={`w-9 h-9 sm:w-11 sm:h-11 rounded-lg transition-all duration-150 relative cursor-pointer border ${
                    isFilled
                      ? 'border-white/20 shadow-md'
                      : 'bg-slate-800/80 hover:bg-slate-700/60 border-slate-700/50'
                  }`}
                  style={{
                    backgroundColor: isFilled ? cellColor : undefined,
                    boxShadow: isFilled ? `0 0 10px ${cellColor}80` : undefined,
                  }}
                >
                  {isFilled && (
                    <div className="absolute inset-0.5 rounded-md bg-gradient-to-br from-white/30 to-transparent pointer-events-none" />
                  )}
                </button>
              );
            })
          )}
        </div>

        {/* Game Over Overlay */}
        {isGameOver && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-xs rounded-2xl flex flex-col items-center justify-center p-6 text-center z-20">
            <h3 className="text-xl sm:text-2xl font-black text-rose-400 mb-2">
              لا توجد حركات متاحة! 🧩
            </h3>
            <p className="text-sm text-slate-300 mb-4">
              النتيجة النهائية: <span className="text-amber-400 font-black">{score}</span>
            </p>
            <button
              onClick={initGame}
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-black text-sm shadow-lg shadow-blue-500/30 active:scale-95 transition-all cursor-pointer"
            >
              <RotateCcw className="w-4 h-4" />
              <span>العب مرة أخرى</span>
            </button>
          </div>
        )}
      </div>

      {/* Available Shapes Tray */}
      <div className="w-full mt-5">
        <p className="text-xs text-center text-slate-400 mb-2">
          {selectedShapeIndex === null
            ? '👈 انقر لاختيار قالب ثم ضعه في الشبكة'
            : '✅ حدد الموضع في الشبكة لإسقاط القالب'}
        </p>

        <div className="flex items-center justify-center gap-3 sm:gap-6 min-h-[90px] p-3 rounded-2xl bg-slate-900/60 border border-slate-800">
          {availableShapes.map((shape, idx) => {
            const isSelected = selectedShapeIndex === idx;

            return (
              <div
                key={shape.id}
                onClick={() => {
                  sounds.playClick();
                  setSelectedShapeIndex(isSelected ? null : idx);
                }}
                className={`p-2 sm:p-3 rounded-xl cursor-pointer transition-all duration-200 border flex items-center justify-center ${
                  isSelected
                    ? 'bg-blue-950/80 border-cyan-400 ring-2 ring-cyan-400/50 scale-110 shadow-lg shadow-cyan-500/30'
                    : 'bg-slate-800/60 hover:bg-slate-800 border-slate-700'
                }`}
              >
                <div
                  className="grid gap-0.5 sm:gap-1"
                  style={{
                    gridTemplateColumns: `repeat(${shape.matrix[0].length}, minmax(0, 1fr))`,
                  }}
                >
                  {shape.matrix.map((row, r) =>
                    row.map((val, c) => (
                      <div
                        key={`${r}-${c}`}
                        className="w-4 h-4 sm:w-5 sm:h-5 rounded-xs"
                        style={{
                          backgroundColor: val === 1 ? shape.color : 'transparent',
                          boxShadow: val === 1 ? `0 0 6px ${shape.glow}` : undefined,
                        }}
                      />
                    ))
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
