import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Play, RotateCcw, Volume2, VolumeX, Sparkles, Trophy } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sounds } from '../utils/audio';

interface SnakeGameProps {
  onScoreUpdate: (score: number) => void;
  highScore: number;
}

type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';

interface Position {
  x: number;
  y: number;
}

const GRID_SIZE = 20;

export const SnakeGame: React.FC<SnakeGameProps> = ({ onScoreUpdate, highScore }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [speedLevel, setSpeedLevel] = useState<'normal' | 'fast' | 'extreme'>('normal');
  const [isMuted, setIsMuted] = useState(false);
  const [bonusFruit, setBonusFruit] = useState<Position | null>(null);

  const snakeRef = useRef<Position[]>([
    { x: 10, y: 10 },
    { x: 10, y: 11 },
    { x: 10, y: 12 },
  ]);
  const directionRef = useRef<Direction>('UP');
  const nextDirectionRef = useRef<Direction>('UP');
  const foodRef = useRef<Position>({ x: 5, y: 5 });
  const gameLoopRef = useRef<number | null>(null);
  const lastUpdateRef = useRef<number>(0);

  const getSpeedMs = () => {
    switch (speedLevel) {
      case 'fast':
        return 90;
      case 'extreme':
        return 65;
      default:
        return 120;
    }
  };

  const spawnFood = useCallback(() => {
    const snake = snakeRef.current;
    let newFood: Position;
    let collision: boolean;
    do {
      newFood = {
        x: Math.floor(Math.random() * GRID_SIZE),
        y: Math.floor(Math.random() * GRID_SIZE),
      };
      // eslint-disable-next-line @typescript-eslint/no-loop-func
      collision = snake.some((seg) => seg.x === newFood.x && seg.y === newFood.y);
    } while (collision);
    foodRef.current = newFood;
  }, []);

  const spawnBonusFruit = useCallback(() => {
    if (Math.random() < 0.35) {
      const snake = snakeRef.current;
      let newBonus: Position;
      let collision: boolean;
      do {
        newBonus = {
          x: Math.floor(Math.random() * GRID_SIZE),
          y: Math.floor(Math.random() * GRID_SIZE),
        };
        // eslint-disable-next-line @typescript-eslint/no-loop-func
        collision =
          snake.some((seg) => seg.x === newBonus.x && seg.y === newBonus.y) ||
          (foodRef.current.x === newBonus.x && foodRef.current.y === newBonus.y);
      } while (collision);
      setBonusFruit(newBonus);
    }
  }, []);

  const startGame = () => {
    snakeRef.current = [
      { x: 10, y: 10 },
      { x: 10, y: 11 },
      { x: 10, y: 12 },
    ];
    directionRef.current = 'UP';
    nextDirectionRef.current = 'UP';
    setScore(0);
    setIsGameOver(false);
    setIsPlaying(true);
    setBonusFruit(null);
    spawnFood();
    sounds.playClick();
  };

  const handleGameOver = () => {
    setIsPlaying(false);
    setIsGameOver(true);
    sounds.playGameOver();
    if (score > highScore && score > 0) {
      confetti({ particleCount: 80, spread: 70, origin: { y: 0.6 } });
    }
  };

  const changeDirection = (dir: Direction) => {
    const current = directionRef.current;
    if (
      (dir === 'UP' && current !== 'DOWN') ||
      (dir === 'DOWN' && current !== 'UP') ||
      (dir === 'LEFT' && current !== 'RIGHT') ||
      (dir === 'RIGHT' && current !== 'LEFT')
    ) {
      nextDirectionRef.current = dir;
    }
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (['ArrowUp', 'KeyW'].includes(e.code)) {
        e.preventDefault();
        changeDirection('UP');
      } else if (['ArrowDown', 'KeyS'].includes(e.code)) {
        e.preventDefault();
        changeDirection('DOWN');
      } else if (['ArrowLeft', 'KeyA'].includes(e.code)) {
        e.preventDefault();
        changeDirection('LEFT');
      } else if (['ArrowRight', 'KeyD'].includes(e.code)) {
        e.preventDefault();
        changeDirection('RIGHT');
      } else if (e.code === 'Space') {
        e.preventDefault();
        if (!isPlaying && !isGameOver) {
          startGame();
        } else if (isGameOver) {
          startGame();
        } else {
          setIsPlaying((prev) => !prev);
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, isGameOver]);

  // Main canvas render & tick loop
  useEffect(() => {
    if (!isPlaying) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const loop = (timestamp: number) => {
      if (!lastUpdateRef.current) lastUpdateRef.current = timestamp;
      const progress = timestamp - lastUpdateRef.current;

      if (progress >= getSpeedMs()) {
        lastUpdateRef.current = timestamp;

        // Update direction
        directionRef.current = nextDirectionRef.current;
        const dir = directionRef.current;
        const head = { ...snakeRef.current[0] };

        if (dir === 'UP') head.y -= 1;
        if (dir === 'DOWN') head.y += 1;
        if (dir === 'LEFT') head.x -= 1;
        if (dir === 'RIGHT') head.x += 1;

        // Check wall collision
        if (head.x < 0 || head.x >= GRID_SIZE || head.y < 0 || head.y >= GRID_SIZE) {
          handleGameOver();
          return;
        }

        // Check self collision
        if (snakeRef.current.some((seg) => seg.x === head.x && seg.y === head.y)) {
          handleGameOver();
          return;
        }

        const newSnake = [head, ...snakeRef.current];

        // Food collision
        if (head.x === foodRef.current.x && head.y === foodRef.current.y) {
          sounds.playCoin();
          const newScore = score + 10;
          setScore(newScore);
          onScoreUpdate(newScore);
          spawnFood();
          spawnBonusFruit();
        } else if (bonusFruit && head.x === bonusFruit.x && head.y === bonusFruit.y) {
          sounds.playWin();
          const newScore = score + 50;
          setScore(newScore);
          onScoreUpdate(newScore);
          setBonusFruit(null);
        } else {
          newSnake.pop();
        }

        snakeRef.current = newSnake;
      }

      // Drawing
      const cellSize = canvas.width / GRID_SIZE;
      ctx.fillStyle = '#090d16';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Subtle grid
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.04)';
      ctx.lineWidth = 1;
      for (let i = 0; i <= GRID_SIZE; i++) {
        ctx.beginPath();
        ctx.moveTo(i * cellSize, 0);
        ctx.lineTo(i * cellSize, canvas.height);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(0, i * cellSize);
        ctx.lineTo(canvas.width, i * cellSize);
        ctx.stroke();
      }

      // Draw standard food
      ctx.save();
      ctx.fillStyle = '#ef4444';
      ctx.shadowColor = '#ef4444';
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.arc(
        foodRef.current.x * cellSize + cellSize / 2,
        foodRef.current.y * cellSize + cellSize / 2,
        cellSize * 0.4,
        0,
        Math.PI * 2
      );
      ctx.fill();
      ctx.restore();

      // Draw bonus golden fruit if present
      if (bonusFruit) {
        ctx.save();
        ctx.fillStyle = '#fbbf24';
        ctx.shadowColor = '#fbbf24';
        ctx.shadowBlur = 18;
        ctx.beginPath();
        ctx.arc(
          bonusFruit.x * cellSize + cellSize / 2,
          bonusFruit.y * cellSize + cellSize / 2,
          cellSize * 0.45,
          0,
          Math.PI * 2
        );
        ctx.fill();
        ctx.restore();
      }

      // Draw snake
      snakeRef.current.forEach((segment, index) => {
        const isHead = index === 0;
        ctx.save();
        if (isHead) {
          ctx.fillStyle = '#34d399';
          ctx.shadowColor = '#10b981';
          ctx.shadowBlur = 14;
        } else {
          const greenTone = Math.max(80, 200 - index * 6);
          ctx.fillStyle = `rgb(16, ${greenTone}, 129)`;
          ctx.shadowBlur = 0;
        }

        const margin = 1.5;
        const x = segment.x * cellSize + margin;
        const y = segment.y * cellSize + margin;
        const size = cellSize - margin * 2;
        const radius = isHead ? 6 : 3;

        ctx.beginPath();
        ctx.roundRect(x, y, size, size, radius);
        ctx.fill();

        // Draw eyes on head
        if (isHead) {
          ctx.fillStyle = '#0f172a';
          const eyeSize = cellSize * 0.16;
          let eye1X = x + size * 0.3;
          let eye1Y = y + size * 0.3;
          let eye2X = x + size * 0.7;
          let eye2Y = y + size * 0.3;

          if (directionRef.current === 'DOWN') {
            eye1Y = y + size * 0.7;
            eye2Y = y + size * 0.7;
          } else if (directionRef.current === 'LEFT') {
            eye1X = x + size * 0.3;
            eye2X = x + size * 0.3;
            eye1Y = y + size * 0.3;
            eye2Y = y + size * 0.7;
          } else if (directionRef.current === 'RIGHT') {
            eye1X = x + size * 0.7;
            eye2X = x + size * 0.7;
            eye1Y = y + size * 0.3;
            eye2Y = y + size * 0.7;
          }

          ctx.beginPath();
          ctx.arc(eye1X, eye1Y, eyeSize, 0, Math.PI * 2);
          ctx.arc(eye2X, eye2Y, eyeSize, 0, Math.PI * 2);
          ctx.fill();
        }

        ctx.restore();
      });

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, score, bonusFruit, speedLevel, spawnFood, spawnBonusFruit, onScoreUpdate]);

  return (
    <div className="flex flex-col items-center justify-center w-full max-w-lg mx-auto select-none">
      {/* Header bar with live score and high score */}
      <div className="flex items-center justify-between w-full mb-3 px-4 py-2.5 rounded-2xl bg-slate-900/90 border border-slate-800 backdrop-blur-md">
        <div className="flex items-center gap-2">
          <span className="text-emerald-400 font-bold text-lg">Score: {score}</span>
          {bonusFruit && (
            <span className="flex items-center gap-1 text-amber-400 text-xs px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/30 animate-pulse">
              <Sparkles className="w-3 h-3" /> Gold Fruit +50!
            </span>
          )}
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-slate-400 text-sm">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>Best:</span>
            <span className="font-bold text-white">{Math.max(score, highScore)}</span>
          </div>
          <button
            onClick={() => {
              const muted = sounds.toggleMute();
              setIsMuted(muted);
            }}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
            title="Mute / Unmute"
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Main Canvas Area */}
      <div className="relative w-full aspect-square max-w-[420px] rounded-3xl overflow-hidden border-2 border-slate-800 shadow-2xl shadow-emerald-950/30 bg-slate-950">
        <canvas
          ref={canvasRef}
          width={400}
          height={400}
          className="w-full h-full block"
        />

        {/* Start / Game Over Overlay */}
        {(!isPlaying || isGameOver) && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-10 animate-fade-in">
            {isGameOver ? (
              <div className="space-y-4">
                <div className="w-16 h-16 mx-auto rounded-3xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-3xl text-red-400">
                  💀
                </div>
                <h3 className="text-2xl font-black text-white">Game Over!</h3>
                <p className="text-slate-300 text-sm">
                  Final Score: <span className="font-black text-emerald-400 text-base">{score}</span>
                </p>
                <button
                  id="snake-restart-btn"
                  onClick={startGame}
                  className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black shadow-lg shadow-emerald-500/30 flex items-center gap-2 mx-auto transition-all active:scale-95 cursor-pointer text-sm"
                >
                  <RotateCcw className="w-4 h-4" />
                  Play Again
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="w-16 h-16 mx-auto rounded-3xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-3xl text-emerald-400 animate-bounce">
                  🐍
                </div>
                <div>
                  <h3 className="text-2xl font-black text-white mb-1">Retro Neon Snake</h3>
                  <p className="text-xs text-slate-400">Eat glow fruits, grow longer, avoid crashing</p>
                </div>

                {/* Speed selector */}
                <div className="flex items-center justify-center gap-2 pt-2">
                  {(['normal', 'fast', 'extreme'] as const).map((spd) => (
                    <button
                      key={spd}
                      onClick={() => setSpeedLevel(spd)}
                      className={`px-3.5 py-1.5 text-xs rounded-xl font-bold transition-all cursor-pointer ${
                        speedLevel === spd
                          ? 'bg-emerald-500 text-slate-950 font-black shadow-md'
                          : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                      }`}
                    >
                      {spd.toUpperCase()}
                    </button>
                  ))}
                </div>

                <button
                  id="snake-start-btn"
                  onClick={startGame}
                  className="px-8 py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black shadow-xl shadow-emerald-500/30 flex items-center gap-2 mx-auto transition-all active:scale-95 text-base cursor-pointer"
                >
                  <Play className="w-5 h-5 fill-current" />
                  START GAME
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Touch / Virtual D-pad for mobile and tablets */}
      <div className="w-full max-w-[280px] mt-4 flex flex-col items-center gap-2 sm:hidden">
        <button
          onClick={() => changeDirection('UP')}
          className="w-14 h-12 rounded-2xl bg-slate-800 active:bg-emerald-600 active:text-white text-slate-200 border border-slate-700 flex items-center justify-center font-bold text-lg shadow-md"
        >
          ▲
        </button>
        <div className="flex gap-4">
          <button
            onClick={() => changeDirection('LEFT')}
            className="w-14 h-12 rounded-2xl bg-slate-800 active:bg-emerald-600 active:text-white text-slate-200 border border-slate-700 flex items-center justify-center font-bold text-lg shadow-md"
          >
            ◀
          </button>
          <button
            onClick={() => changeDirection('DOWN')}
            className="w-14 h-12 rounded-2xl bg-slate-800 active:bg-emerald-600 active:text-white text-slate-200 border border-slate-700 flex items-center justify-center font-bold text-lg shadow-md"
          >
            ▼
          </button>
          <button
            onClick={() => changeDirection('RIGHT')}
            className="w-14 h-12 rounded-2xl bg-slate-800 active:bg-emerald-600 active:text-white text-slate-200 border border-slate-700 flex items-center justify-center font-bold text-lg shadow-md"
          >
            ▶
          </button>
        </div>
      </div>
    </div>
  );
};
