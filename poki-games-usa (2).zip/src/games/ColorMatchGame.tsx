import React, { useState, useEffect, useRef } from 'react';
import { Play, RotateCcw, Trophy, Sparkles, Check, X } from 'lucide-react';
import { sounds } from '../utils/audio';

interface ColorMatchGameProps {
  onScoreUpdate?: (score: number) => void;
  highScore?: number;
}

const COLORS = [
  { name: 'RED', hex: '#ef4444' },
  { name: 'BLUE', hex: '#3b82f6' },
  { name: 'GREEN', hex: '#10b981' },
  { name: 'YELLOW', hex: '#eab308' },
  { name: 'PURPLE', hex: '#a855f7' },
  { name: 'ORANGE', hex: '#f97316' },
];

export const ColorMatchGame: React.FC<ColorMatchGameProps> = ({
  onScoreUpdate,
  highScore = 0,
}) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [timeLeft, setTimeLeft] = useState(4);

  // Current problem
  const [textColorName, setTextColorName] = useState(COLORS[0].name);
  const [textDisplayColor, setTextDisplayColor] = useState(COLORS[0].hex);
  const [doesMatch, setDoesMatch] = useState(true);

  const timerRef = useRef<number | null>(null);

  const generateNextRound = () => {
    const isMatching = Math.random() > 0.5;
    const colorObj = COLORS[Math.floor(Math.random() * COLORS.length)];

    setTextColorName(colorObj.name);

    if (isMatching) {
      setTextDisplayColor(colorObj.hex);
      setDoesMatch(true);
    } else {
      const otherColors = COLORS.filter((c) => c.name !== colorObj.name);
      const wrongColor = otherColors[Math.floor(Math.random() * otherColors.length)];
      setTextDisplayColor(wrongColor.hex);
      setDoesMatch(false);
    }

    setTimeLeft(Math.max(1.5, 3.8 - score * 0.08));
  };

  const startGame = () => {
    sounds.playCoin();
    setScore(0);
    setStreak(0);
    setIsGameOver(false);
    setIsPlaying(true);
    generateNextRound();
  };

  const handleAnswer = (answeredMatch: boolean) => {
    if (!isPlaying || isGameOver) return;

    if (answeredMatch === doesMatch) {
      sounds.playCoin();
      const newScore = score + 1;
      setScore(newScore);
      setStreak((prev) => prev + 1);
      onScoreUpdate?.(newScore);
      generateNextRound();
    } else {
      sounds.playHit();
      sounds.playGameOver();
      setIsGameOver(true);
      setIsPlaying(false);
    }
  };

  useEffect(() => {
    if (!isPlaying || isGameOver) return;

    timerRef.current = window.setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 0.1) {
          sounds.playGameOver();
          setIsGameOver(true);
          setIsPlaying(false);
          return 0;
        }
        return prev - 0.1;
      });
    }, 100);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPlaying, isGameOver]);

  return (
    <div className="flex flex-col items-center justify-center p-2 sm:p-4 w-full max-w-md mx-auto select-none">
      {/* Top bar */}
      <div className="flex items-center justify-between w-full mb-3 px-4 py-2.5 rounded-2xl bg-black/40 backdrop-blur-xl border border-white/10">
        <div className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-pink-400" />
          <span className="font-bold text-sm text-white">Color Match Blitz</span>
        </div>
        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="text-slate-300">
            Score: <span className="text-pink-400 font-black text-base">{score}</span>
          </div>
          <div className="text-slate-400">
            Best: <span className="text-emerald-400 font-bold">{highScore}</span>
          </div>
        </div>
      </div>

      {/* Main card */}
      <div className="relative w-full h-[360px] rounded-3xl bg-slate-900 border-4 border-slate-800 flex flex-col items-center justify-center p-6 text-center shadow-2xl overflow-hidden">
        {isPlaying && !isGameOver ? (
          <div className="w-full space-y-6">
            {/* Timer bar */}
            <div className="w-full h-3 rounded-full bg-white/10 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-pink-500 to-amber-400 transition-all duration-100"
                style={{ width: `${Math.min(100, (timeLeft / 4) * 100)}%` }}
              />
            </div>

            <div className="space-y-2">
              <p className="text-xs text-slate-400 font-semibold">Does the word match the font color?</p>
              <div
                className="text-5xl font-black transition-transform duration-150 tracking-wider"
                style={{ color: textDisplayColor }}
              >
                {textColorName}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-4">
              <button
                onClick={() => handleAnswer(true)}
                className="py-4 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-lg flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20 active:scale-95 cursor-pointer"
              >
                <Check className="w-6 h-6 stroke-[3]" />
                <span>MATCH</span>
              </button>

              <button
                onClick={() => handleAnswer(false)}
                className="py-4 rounded-2xl bg-rose-500 hover:bg-rose-400 text-white font-black text-lg flex items-center justify-center gap-2 shadow-lg shadow-rose-500/20 active:scale-95 cursor-pointer"
              >
                <X className="w-6 h-6 stroke-[3]" />
                <span>NO MATCH</span>
              </button>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="w-16 h-16 mx-auto rounded-3xl bg-pink-500/20 border border-pink-400/50 flex items-center justify-center text-3xl">
              🎨
            </div>
            <h3 className="text-2xl font-black text-white">
              {isGameOver ? 'Game Over!' : 'Color Match Blitz'}
            </h3>
            {isGameOver && (
              <p className="text-sm font-mono text-amber-400">Final Score: {score} pts</p>
            )}
            <p className="text-xs text-slate-300 max-w-xs leading-relaxed">
              Test your Stroop reflex! Rapidly determine whether the written color name matches the actual display color.
            </p>
            <button
              onClick={startGame}
              className="px-8 py-3.5 rounded-2xl bg-pink-500 hover:bg-pink-400 text-slate-950 font-black text-base shadow-xl shadow-pink-500/30 cursor-pointer active:scale-95 transition-all"
            >
              {isGameOver ? 'PLAY AGAIN 🔄' : 'START CHALLENGE ⚡'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
