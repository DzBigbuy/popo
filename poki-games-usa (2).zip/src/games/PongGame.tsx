import React, { useEffect, useRef, useState } from 'react';
import { Play, RotateCcw, Bot, Users, Trophy } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sounds } from '../utils/audio';

interface PongGameProps {
  onScoreUpdate: (score: number) => void;
  highScore: number;
}

export const PongGame: React.FC<PongGameProps> = ({ onScoreUpdate, highScore }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [winner, setWinner] = useState<'player' | 'ai' | 'p1' | 'p2' | null>(null);
  const [mode, setMode] = useState<'ai' | 'pvp'>('ai');
  const [score1, setScore1] = useState(0);
  const [score2, setScore2] = useState(0);

  const WIN_SCORE = 5;

  const p1Ref = useRef({ y: 150, height: 70, speed: 6 });
  const p2Ref = useRef({ y: 150, height: 70, speed: 4.8 });
  const ballRef = useRef({ x: 200, y: 150, vx: 4, vy: 3, radius: 6 });
  const keysRef = useRef<{ w: boolean; s: boolean; up: boolean; down: boolean }>({
    w: false,
    s: false,
    up: false,
    down: false,
  });

  const resetBall = (direction: 'left' | 'right') => {
    ballRef.current = {
      x: 200,
      y: 150,
      vx: (direction === 'left' ? -1 : 1) * (3.8 + Math.random()),
      vy: (Math.random() * 4 - 2),
      radius: 6,
    };
  };

  const startGame = () => {
    p1Ref.current.y = 150;
    p2Ref.current.y = 150;
    setScore1(0);
    setScore2(0);
    setWinner(null);
    setIsGameOver(false);
    resetBall(Math.random() < 0.5 ? 'left' : 'right');
    setIsPlaying(true);
    sounds.playClick();
  };

  // Keyboard controls
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'KeyW') keysRef.current.w = true;
      if (e.code === 'KeyS') keysRef.current.s = true;
      if (e.code === 'ArrowUp') keysRef.current.up = true;
      if (e.code === 'ArrowDown') keysRef.current.down = true;
    };
    const onKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'KeyW') keysRef.current.w = false;
      if (e.code === 'KeyS') keysRef.current.s = false;
      if (e.code === 'ArrowUp') keysRef.current.up = false;
      if (e.code === 'ArrowDown') keysRef.current.down = false;
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, []);

  // Mouse / Touch paddle for P1
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const relativeY = (e.clientY - rect.top) * (canvas.height / rect.height);
    p1Ref.current.y = Math.max(0, Math.min(canvas.height - p1Ref.current.height, relativeY - p1Ref.current.height / 2));
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas || !e.touches[0]) return;
    const rect = canvas.getBoundingClientRect();
    const relativeY = (e.touches[0].clientX - rect.top) * (canvas.height / rect.height);
    p1Ref.current.y = Math.max(0, Math.min(canvas.height - p1Ref.current.height, relativeY - p1Ref.current.height / 2));
  };

  // Game Loop
  useEffect(() => {
    if (!isPlaying) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const loop = () => {
      const p1 = p1Ref.current;
      const p2 = p2Ref.current;
      const ball = ballRef.current;

      // P1 movement
      if (keysRef.current.w && p1.y > 0) p1.y -= p1.speed;
      if (keysRef.current.s && p1.y < canvas.height - p1.height) p1.y += p1.speed;

      // P2 movement (AI or Player 2)
      if (mode === 'ai') {
        const targetY = ball.y - p2.height / 2;
        if (p2.y < targetY) p2.y += p2.speed;
        if (p2.y > targetY) p2.y -= p2.speed;
      } else {
        if (keysRef.current.up && p2.y > 0) p2.y -= p2.speed;
        if (keysRef.current.down && p2.y < canvas.height - p2.height) p2.y += p2.speed;
      }

      // Constrain paddles
      p1.y = Math.max(0, Math.min(canvas.height - p1.height, p1.y));
      p2.y = Math.max(0, Math.min(canvas.height - p2.height, p2.y));

      // Move Ball
      ball.x += ball.vx;
      ball.y += ball.vy;

      // Ceiling and floor bounce
      if (ball.y - ball.radius < 0 || ball.y + ball.radius > canvas.height) {
        ball.vy = -ball.vy;
        sounds.playHit();
      }

      // Left paddle collision (P1)
      const paddleWidth = 10;
      if (
        ball.x - ball.radius <= 20 + paddleWidth &&
        ball.x + ball.radius >= 20 &&
        ball.y >= p1.y &&
        ball.y <= p1.y + p1.height &&
        ball.vx < 0
      ) {
        const hitOffset = (ball.y - (p1.y + p1.height / 2)) / (p1.height / 2);
        ball.vx = Math.abs(ball.vx) * 1.05;
        ball.vy = hitOffset * 5;
        sounds.playLaser();
      }

      // Right paddle collision (P2)
      const p2X = canvas.width - 20 - paddleWidth;
      if (
        ball.x + ball.radius >= p2X &&
        ball.x - ball.radius <= p2X + paddleWidth &&
        ball.y >= p2.y &&
        ball.y <= p2.y + p2.height &&
        ball.vx > 0
      ) {
        const hitOffset = (ball.y - (p2.y + p2.height / 2)) / (p2.height / 2);
        ball.vx = -Math.abs(ball.vx) * 1.05;
        ball.vy = hitOffset * 5;
        sounds.playLaser();
      }

      // Scoring
      if (ball.x < 0) {
        // P2 scores
        sounds.playGameOver();
        setScore2((prev) => {
          const next = prev + 1;
          if (next >= WIN_SCORE) {
            setIsPlaying(false);
            setIsGameOver(true);
            setWinner(mode === 'ai' ? 'ai' : 'p2');
          } else {
            resetBall('right');
          }
          return next;
        });
      } else if (ball.x > canvas.width) {
        // P1 scores
        sounds.playCoin();
        setScore1((prev) => {
          const next = prev + 1;
          onScoreUpdate(next * 50);
          if (next >= WIN_SCORE) {
            setIsPlaying(false);
            setIsGameOver(true);
            setWinner(mode === 'ai' ? 'player' : 'p1');
            sounds.playWin();
            confetti({ particleCount: 80, spread: 70 });
          } else {
            resetBall('left');
          }
          return next;
        });
      }

      // DRAWING
      ctx.fillStyle = '#060914';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Center dashed line
      ctx.strokeStyle = 'rgba(255,255,255,0.1)';
      ctx.lineWidth = 3;
      ctx.setLineDash([8, 8]);
      ctx.beginPath();
      ctx.moveTo(canvas.width / 2, 0);
      ctx.lineTo(canvas.width / 2, canvas.height);
      ctx.stroke();
      ctx.setLineDash([]);

      // P1 Paddle
      ctx.save();
      ctx.fillStyle = '#3b82f6';
      ctx.shadowColor = '#3b82f6';
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.roundRect(20, p1.y, paddleWidth, p1.height, 4);
      ctx.fill();
      ctx.restore();

      // P2 Paddle
      ctx.save();
      ctx.fillStyle = '#ec4899';
      ctx.shadowColor = '#ec4899';
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.roundRect(p2X, p2.y, paddleWidth, p2.height, 4);
      ctx.fill();
      ctx.restore();

      // Ball
      ctx.save();
      ctx.fillStyle = '#ffffff';
      ctx.shadowColor = '#38bdf8';
      ctx.shadowBlur = 10;
      ctx.beginPath();
      ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, mode, onScoreUpdate]);

  return (
    <div className="flex flex-col items-center justify-center w-full max-w-lg mx-auto select-none">
      {/* Mode Bar */}
      <div className="flex items-center justify-between w-full mb-3 gap-2">
        <div className="flex bg-slate-900 border border-slate-800 rounded-2xl p-1">
          <button
            onClick={() => {
              setMode('ai');
              startGame();
            }}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
              mode === 'ai' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Bot className="w-4 h-4" />
            vs AI Bot
          </button>
          <button
            onClick={() => {
              setMode('pvp');
              startGame();
            }}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
              mode === 'pvp' ? 'bg-blue-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Users className="w-4 h-4" />
            2 Players
          </button>
        </div>

        <div className="text-xs text-slate-400 font-semibold">First to 5 points wins</div>
      </div>

      {/* Score Header */}
      <div className="flex items-center justify-around w-full mb-2 px-6 py-2.5 bg-slate-900/80 rounded-2xl border border-slate-800 font-mono">
        <div className="text-center">
          <div className="text-xs text-blue-400 font-sans font-bold uppercase">Player 1</div>
          <div className="text-2xl font-black text-white">{score1}</div>
        </div>
        <div className="text-slate-600 text-xl font-bold">:</div>
        <div className="text-center">
          <div className="text-xs text-pink-400 font-sans font-bold uppercase">{mode === 'ai' ? 'AI Bot' : 'Player 2'}</div>
          <div className="text-2xl font-black text-white">{score2}</div>
        </div>
      </div>

      {/* Canvas */}
      <div className="relative w-full aspect-[4/3] max-w-[400px] rounded-3xl overflow-hidden border-2 border-slate-800 shadow-2xl shadow-blue-950/30 bg-slate-950">
        <canvas
          ref={canvasRef}
          width={400}
          height={300}
          onMouseMove={handleMouseMove}
          onTouchMove={handleTouchMove}
          className="w-full h-full block cursor-ns-resize"
        />

        {/* Start / End Overlay */}
        {(!isPlaying || isGameOver) && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-10">
            {isGameOver ? (
              <div className="space-y-4">
                <div className="w-16 h-16 mx-auto rounded-3xl bg-blue-500/20 border border-blue-500/40 flex items-center justify-center text-3xl text-blue-400 animate-bounce">
                  🏆
                </div>
                <h3 className="text-2xl font-black text-white">
                  {winner === 'player' || winner === 'p1' ? 'Player 1 Wins!' : 'AI Bot / Player 2 Wins!'}
                </h3>
                <button
                  onClick={startGame}
                  className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-400 text-white font-black shadow-xl shadow-blue-500/30 flex items-center gap-2 mx-auto transition-all active:scale-95 cursor-pointer text-sm"
                >
                  <RotateCcw className="w-4 h-4" />
                  New Match
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="w-16 h-16 mx-auto rounded-3xl bg-blue-500/20 border border-blue-500/40 flex items-center justify-center text-3xl text-blue-400">
                  🏓
                </div>
                <div>
                  <h3 className="text-2xl font-black text-white mb-1">Classic Neon Pong</h3>
                  <p className="text-xs text-slate-400">Move your paddle vertically to return the ball and score</p>
                </div>
                <button
                  onClick={startGame}
                  className="px-8 py-3.5 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-black shadow-xl shadow-blue-500/30 flex items-center gap-2 mx-auto transition-all active:scale-95 cursor-pointer text-base"
                >
                  <Play className="w-5 h-5 fill-current" />
                  SERVE & PLAY
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="mt-3 text-xs text-slate-400 text-center">
        💡 P1: Mouse or W/S keys | P2: Arrow Up / Down keys
      </div>
    </div>
  );
};
