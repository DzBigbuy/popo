import React, { useState, useEffect, useCallback } from 'react';
import { RotateCcw, Users, Bot, Sparkles, Trophy } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sounds } from '../utils/audio';

interface TicTacToeProps {
  onScoreUpdate: (score: number) => void;
  highScore: number;
}

type CellValue = 'X' | 'O' | null;
type GameMode = 'ai' | 'pvp';
type AiDifficulty = 'easy' | 'medium' | 'unbeatable';

export const TicTacToeGame: React.FC<TicTacToeProps> = ({ onScoreUpdate, highScore }) => {
  const [board, setBoard] = useState<CellValue[]>(Array(9).fill(null));
  const [isXNext, setIsXNext] = useState(true);
  const [gameMode, setGameMode] = useState<GameMode>('ai');
  const [aiDifficulty, setAiDifficulty] = useState<AiDifficulty>('medium');
  const [winner, setWinner] = useState<CellValue | 'Draw' | null>(null);
  const [winningLine, setWinningLine] = useState<number[] | null>(null);
  const [stats, setStats] = useState({ xWins: 0, oWins: 0, draws: 0 });

  const winningCombinations = [
    [0, 1, 2],
    [3, 4, 5],
    [6, 7, 8],
    [0, 3, 6],
    [1, 4, 7],
    [2, 5, 8],
    [0, 4, 8],
    [2, 4, 6],
  ];

  const checkWinner = useCallback((currentBoard: CellValue[]): { winner: CellValue | 'Draw' | null; line: number[] | null } => {
    for (const combo of winningCombinations) {
      const [a, b, c] = combo;
      if (currentBoard[a] && currentBoard[a] === currentBoard[b] && currentBoard[a] === currentBoard[c]) {
        return { winner: currentBoard[a], line: combo };
      }
    }
    if (currentBoard.every((cell) => cell !== null)) {
      return { winner: 'Draw', line: null };
    }
    return { winner: null, line: null };
  }, []);

  const resetGame = () => {
    setBoard(Array(9).fill(null));
    setIsXNext(true);
    setWinner(null);
    setWinningLine(null);
    sounds.playClick();
  };

  const getBestMoveMinimax = (currentBoard: CellValue[]): number => {
    // Minimax algorithm for unbeatable AI
    const minimax = (newBoard: CellValue[], depth: number, isMaximizing: boolean): number => {
      const result = checkWinner(newBoard);
      if (result.winner === 'O') return 10 - depth;
      if (result.winner === 'X') return depth - 10;
      if (result.winner === 'Draw') return 0;

      if (isMaximizing) {
        let bestScore = -Infinity;
        for (let i = 0; i < 9; i++) {
          if (!newBoard[i]) {
            newBoard[i] = 'O';
            const score = minimax(newBoard, depth + 1, false);
            newBoard[i] = null;
            bestScore = Math.max(score, bestScore);
          }
        }
        return bestScore;
      } else {
        let bestScore = Infinity;
        for (let i = 0; i < 9; i++) {
          if (!newBoard[i]) {
            newBoard[i] = 'X';
            const score = minimax(newBoard, depth + 1, true);
            newBoard[i] = null;
            bestScore = Math.min(score, bestScore);
          }
        }
        return bestScore;
      }
    };

    let bestMove = -1;
    let bestScore = -Infinity;

    for (let i = 0; i < 9; i++) {
      if (!currentBoard[i]) {
        currentBoard[i] = 'O';
        const score = minimax(currentBoard, 0, false);
        currentBoard[i] = null;
        if (score > bestScore) {
          bestScore = score;
          bestMove = i;
        }
      }
    }
    return bestMove;
  };

  const handleCellClick = (index: number) => {
    if (board[index] || winner) return;

    sounds.playClick();

    const newBoard = [...board];
    newBoard[index] = isXNext ? 'X' : 'O';
    setBoard(newBoard);

    const check = checkWinner(newBoard);
    if (check.winner) {
      handleGameEnd(check.winner, check.line);
      return;
    }

    setIsXNext(!isXNext);
  };

  const handleGameEnd = (endWinner: CellValue | 'Draw', line: number[] | null) => {
    setWinner(endWinner);
    setWinningLine(line);

    if (endWinner === 'X') {
      sounds.playWin();
      confetti({ particleCount: 70, spread: 60 });
      setStats((prev) => {
        const next = { ...prev, xWins: prev.xWins + 1 };
        onScoreUpdate(next.xWins * 100);
        return next;
      });
    } else if (endWinner === 'O') {
      sounds.playGameOver();
      setStats((prev) => ({ ...prev, oWins: prev.oWins + 1 }));
    } else {
      sounds.playHit();
      setStats((prev) => ({ ...prev, draws: prev.draws + 1 }));
    }
  };

  // AI turn trigger
  useEffect(() => {
    if (gameMode === 'ai' && !isXNext && !winner) {
      const timer = setTimeout(() => {
        const emptyIndices = board.map((v, i) => (v === null ? i : null)).filter((v) => v !== null) as number[];
        if (emptyIndices.length === 0) return;

        let moveIndex = emptyIndices[0];

        if (aiDifficulty === 'easy') {
          // Random
          moveIndex = emptyIndices[Math.floor(Math.random() * emptyIndices.length)];
        } else if (aiDifficulty === 'medium') {
          // 60% optimal, 40% random
          if (Math.random() < 0.6) {
            moveIndex = getBestMoveMinimax([...board]);
          } else {
            moveIndex = emptyIndices[Math.floor(Math.random() * emptyIndices.length)];
          }
        } else {
          // Unbeatable Minimax
          moveIndex = getBestMoveMinimax([...board]);
        }

        if (moveIndex !== -1 && board[moveIndex] === null) {
          const newBoard = [...board];
          newBoard[moveIndex] = 'O';
          setBoard(newBoard);
          sounds.playLaser();

          const check = checkWinner(newBoard);
          if (check.winner) {
            handleGameEnd(check.winner, check.line);
          } else {
            setIsXNext(true);
          }
        }
      }, 400);

      return () => clearTimeout(timer);
    }
  }, [isXNext, gameMode, winner, board, aiDifficulty, checkWinner]);

  return (
    <div className="flex flex-col items-center justify-center w-full max-w-md mx-auto select-none">
      {/* Mode & Difficulty Selector */}
      <div className="flex items-center justify-between w-full mb-3 gap-2">
        <div className="flex bg-slate-900 border border-slate-800 rounded-2xl p-1">
          <button
            onClick={() => {
              setGameMode('ai');
              resetGame();
            }}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
              gameMode === 'ai' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Bot className="w-4 h-4" />
            vs AI Bot
          </button>
          <button
            onClick={() => {
              setGameMode('pvp');
              resetGame();
            }}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-black transition-all cursor-pointer ${
              gameMode === 'pvp' ? 'bg-amber-500 text-slate-950 shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Users className="w-4 h-4" />
            2 Players
          </button>
        </div>

        {gameMode === 'ai' && (
          <div className="flex bg-slate-900 border border-slate-800 rounded-2xl p-1 gap-1">
            {(['easy', 'medium', 'unbeatable'] as const).map((lvl) => (
              <button
                key={lvl}
                onClick={() => {
                  setAiDifficulty(lvl);
                  resetGame();
                }}
                className={`px-2.5 py-1 text-xs rounded-xl transition-all font-bold cursor-pointer ${
                  aiDifficulty === lvl ? 'bg-slate-700 text-white font-black' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {lvl === 'easy' ? 'Easy' : lvl === 'medium' ? 'Med' : 'Hard'}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Scoreboard */}
      <div className="grid grid-cols-3 gap-2 w-full mb-4 text-center">
        <div className={`p-2.5 rounded-2xl border transition-all ${isXNext && !winner ? 'bg-amber-500/10 border-amber-500/50 shadow-md shadow-amber-500/10' : 'bg-slate-900/60 border-slate-800'}`}>
          <div className="text-xs text-slate-400 font-bold">Player X</div>
          <div className="text-xl font-black text-amber-400">{stats.xWins}</div>
        </div>
        <div className="p-2.5 rounded-2xl border bg-slate-900/60 border-slate-800">
          <div className="text-xs text-slate-400 font-bold">Draws</div>
          <div className="text-xl font-black text-slate-300">{stats.draws}</div>
        </div>
        <div className={`p-2.5 rounded-2xl border transition-all ${!isXNext && !winner ? 'bg-cyan-500/10 border-cyan-500/50 shadow-md shadow-cyan-500/10' : 'bg-slate-900/60 border-slate-800'}`}>
          <div className="text-xs text-slate-400 font-bold">{gameMode === 'ai' ? 'AI Bot (O)' : 'Player O'}</div>
          <div className="text-xl font-black text-cyan-400">{stats.oWins}</div>
        </div>
      </div>

      {/* 3x3 Game Board Grid */}
      <div className="grid grid-cols-3 gap-3 w-full max-w-[340px] aspect-square p-3 bg-slate-900/80 rounded-3xl border-2 border-slate-800 shadow-2xl backdrop-blur-md">
        {board.map((cell, index) => {
          const isWinningCell = winningLine?.includes(index);
          return (
            <button
              key={index}
              onClick={() => handleCellClick(index)}
              disabled={!!cell || !!winner || (gameMode === 'ai' && !isXNext)}
              className={`relative rounded-2xl font-black text-4xl flex items-center justify-center transition-all duration-200 aspect-square cursor-pointer ${
                isWinningCell
                  ? 'bg-gradient-to-br from-amber-500 to-orange-600 text-slate-950 scale-105 shadow-lg shadow-amber-500/30'
                  : cell
                  ? 'bg-slate-800 border border-slate-700/80 cursor-default'
                  : 'bg-slate-800/60 hover:bg-slate-800 border border-slate-700/40 active:scale-95'
              }`}
            >
              {cell === 'X' && (
                <span className={isWinningCell ? 'text-slate-950 font-black' : 'text-amber-400 animate-scale-in drop-shadow-[0_0_12px_rgba(245,158,11,0.5)]'}>
                  ✕
                </span>
              )}
              {cell === 'O' && (
                <span className={isWinningCell ? 'text-slate-950 font-black' : 'text-cyan-400 animate-scale-in drop-shadow-[0_0_12px_rgba(6,182,212,0.5)]'}>
                  ◯
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Status & Restart Banner */}
      <div className="mt-4 flex items-center justify-between w-full px-2">
        <div className="text-sm font-bold">
          {winner ? (
            winner === 'Draw' ? (
              <span className="text-slate-300">It's a Draw! 🤝</span>
            ) : (
              <span className="text-emerald-400 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4" /> Winner: Player {winner}! 🎉
              </span>
            )
          ) : (
            <span className="text-slate-400">
              Turn:{' '}
              <span className={isXNext ? 'text-amber-400 font-black' : 'text-cyan-400 font-black'}>
                {isXNext ? 'X' : 'O'}
              </span>
            </span>
          )}
        </div>

        <button
          onClick={resetGame}
          className="px-4 py-2 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold border border-slate-700 flex items-center gap-1.5 transition-all active:scale-95 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          New Round
        </button>
      </div>
    </div>
  );
};
