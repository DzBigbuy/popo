import React, { useState, useEffect, useCallback } from 'react';
import { RotateCcw, Undo2, Trophy, Sparkles, Plus, CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sounds } from '../utils/audio';

interface WaterSortGameProps {
  onScoreUpdate: (score: number) => void;
  highScore: number;
}

const COLORS = [
  { name: 'Red', hex: '#ef4444', glow: 'rgba(239, 68, 68, 0.6)' },
  { name: 'Blue', hex: '#3b82f6', glow: 'rgba(59, 130, 246, 0.6)' },
  { name: 'Green', hex: '#10b981', glow: 'rgba(16, 185, 129, 0.6)' },
  { name: 'Yellow', hex: '#eab308', glow: 'rgba(234, 179, 8, 0.6)' },
  { name: 'Purple', hex: '#a855f7', glow: 'rgba(168, 85, 247, 0.6)' },
  { name: 'Cyan', hex: '#06b6d4', glow: 'rgba(6, 182, 212, 0.6)' },
  { name: 'Orange', hex: '#f97316', glow: 'rgba(249, 115, 22, 0.6)' },
  { name: 'Pink', hex: '#ec4899', glow: 'rgba(236, 72, 153, 0.6)' },
];

const TUBE_CAPACITY = 4;

type Tube = number[]; // indices to COLORS

export const WaterSortGame: React.FC<WaterSortGameProps> = ({ onScoreUpdate, highScore }) => {
  const [level, setLevel] = useState(1);
  const [tubes, setTubes] = useState<Tube[]>([]);
  const [selectedTube, setSelectedTube] = useState<number | null>(null);
  const [history, setHistory] = useState<Tube[][]>([]);
  const [score, setScore] = useState(0);
  const [moves, setMoves] = useState(0);
  const [isLevelCompleted, setIsLevelCompleted] = useState(false);

  // Generate solvable puzzle
  const generateLevel = useCallback((lvl: number) => {
    const numColors = Math.min(3 + Math.floor((lvl - 1) / 2), COLORS.length);
    const numEmptyTubes = 2;
    const totalTubes = numColors + numEmptyTubes;

    // Create pools of colors (each color appears 4 times)
    const colorPool: number[] = [];
    for (let c = 0; c < numColors; c++) {
      for (let i = 0; i < TUBE_CAPACITY; i++) {
        colorPool.push(c);
      }
    }

    // Shuffle colors
    for (let i = colorPool.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [colorPool[i], colorPool[j]] = [colorPool[j], colorPool[i]];
    }

    // Distribute into tubes
    const newTubes: Tube[] = [];
    for (let t = 0; t < numColors; t++) {
      newTubes.push(colorPool.slice(t * TUBE_CAPACITY, (t + 1) * TUBE_CAPACITY));
    }
    for (let e = 0; e < numEmptyTubes; e++) {
      newTubes.push([]);
    }

    setTubes(newTubes);
    setSelectedTube(null);
    setHistory([]);
    setIsLevelCompleted(false);
  }, []);

  useEffect(() => {
    generateLevel(level);
  }, [level, generateLevel]);

  // Check if level is solved
  const checkWinCondition = (currentTubes: Tube[]) => {
    for (const tube of currentTubes) {
      if (tube.length === 0) continue;
      if (tube.length !== TUBE_CAPACITY) return false;
      const first = tube[0];
      if (!tube.every((c) => c === first)) return false;
    }
    return true;
  };

  const handleTubeClick = (targetIndex: number) => {
    if (isLevelCompleted) return;

    if (selectedTube === null) {
      // Select source tube if not empty
      if (tubes[targetIndex].length > 0) {
        sounds.playClick();
        setSelectedTube(targetIndex);
      }
      return;
    }

    // If clicked the same tube, deselect
    if (selectedTube === targetIndex) {
      sounds.playClick();
      setSelectedTube(null);
      return;
    }

    // Attempt to pour from selectedTube -> targetIndex
    const sourceTube = [...tubes[selectedTube]];
    const targetTube = [...tubes[targetIndex]];

    if (sourceTube.length === 0) {
      setSelectedTube(null);
      return;
    }

    if (targetTube.length >= TUBE_CAPACITY) {
      // Target is full, switch selection to this tube if it has liquid
      sounds.playClick();
      setSelectedTube(targetIndex);
      return;
    }

    const topColor = sourceTube[sourceTube.length - 1];

    if (targetTube.length > 0 && targetTube[targetTube.length - 1] !== topColor) {
      // Cannot pour different color on top, switch selection
      sounds.playClick();
      setSelectedTube(targetIndex);
      return;
    }

    // Count how many consecutive top colors we can pour
    let countToPour = 0;
    for (let i = sourceTube.length - 1; i >= 0; i--) {
      if (sourceTube[i] === topColor) countToPour++;
      else break;
    }

    const availableSpace = TUBE_CAPACITY - targetTube.length;
    const actualPour = Math.min(countToPour, availableSpace);

    if (actualPour <= 0) {
      setSelectedTube(targetIndex);
      return;
    }

    // Save history for Undo
    setHistory((prev) => [...prev, tubes.map((t) => [...t])]);

    // Execute Pour
    for (let p = 0; p < actualPour; p++) {
      sourceTube.pop();
      targetTube.push(topColor);
    }

    const nextTubes = tubes.map((t, idx) => {
      if (idx === selectedTube) return sourceTube;
      if (idx === targetIndex) return targetTube;
      return t;
    });

    setTubes(nextTubes);
    setSelectedTube(null);
    setMoves((m) => m + 1);
    sounds.playCoin();

    // Check Win
    if (checkWinCondition(nextTubes)) {
      setIsLevelCompleted(true);
      const gained = level * 100 + Math.max(0, 50 - moves * 2);
      const newScore = score + gained;
      setScore(newScore);
      onScoreUpdate(newScore);
      sounds.playWin();
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    }
  };

  const handleUndo = () => {
    if (history.length === 0 || isLevelCompleted) return;
    sounds.playClick();
    const previous = history[history.length - 1];
    setTubes(previous);
    setHistory((prev) => prev.slice(0, -1));
    setSelectedTube(null);
  };

  const handleAddTube = () => {
    if (tubes.length >= 10 || isLevelCompleted) return;
    sounds.playBadgeEarned();
    setHistory((prev) => [...prev, tubes.map((t) => [...t])]);
    setTubes((prev) => [...prev, []]);
  };

  const handleRestart = () => {
    sounds.playClick();
    generateLevel(level);
  };

  const handleNextLevel = () => {
    sounds.playClick();
    setLevel((l) => l + 1);
  };

  return (
    <div className="flex flex-col items-center justify-between w-full max-w-2xl mx-auto p-4 sm:p-6 bg-slate-950 text-white select-none">
      {/* Header bar */}
      <div className="w-full flex items-center justify-between gap-2 mb-6">
        <div className="flex items-center gap-2">
          <div className="px-3 py-1.5 rounded-xl bg-purple-900/60 border border-purple-500/40 text-purple-200 font-black text-sm">
            المستوى {level}
          </div>
          <div className="px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-300 font-bold text-xs">
            الحركات: {moves}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="px-3 py-1.5 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-400 font-black text-sm flex items-center gap-1.5">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>{score}</span>
          </div>
          {highScore > 0 && (
            <div className="text-[11px] text-slate-400 font-semibold hidden sm:block">
              أفضل: {highScore}
            </div>
          )}
        </div>
      </div>

      {/* Tubes Area */}
      <div className="w-full min-h-[300px] flex flex-wrap items-center justify-center gap-4 sm:gap-6 py-6 px-2">
        {tubes.map((tube, idx) => {
          const isSelected = selectedTube === idx;
          const isComplete =
            tube.length === TUBE_CAPACITY && tube.every((c) => c === tube[0]);

          return (
            <div
              key={idx}
              onClick={() => handleTubeClick(idx)}
              className={`relative flex flex-col-reverse items-center justify-start w-14 sm:w-16 h-48 sm:h-52 rounded-b-3xl border-2 cursor-pointer transition-all duration-200 p-1 bg-slate-900/70 backdrop-blur-xs ${
                isSelected
                  ? 'border-cyan-400 shadow-lg shadow-cyan-500/40 -translate-y-3 ring-2 ring-cyan-400/50'
                  : isComplete
                  ? 'border-emerald-500 shadow-md shadow-emerald-500/30'
                  : 'border-slate-700 hover:border-slate-500'
              }`}
            >
              {/* Rim top */}
              <div
                className={`absolute -top-2 left-1/2 -translate-x-1/2 w-16 sm:w-18 h-3 rounded-full border border-slate-600 transition-colors ${
                  isSelected
                    ? 'border-cyan-400 bg-cyan-950/60'
                    : isComplete
                    ? 'border-emerald-400 bg-emerald-950/60'
                    : 'bg-slate-800'
                }`}
              />

              {/* Water segments inside tube */}
              {tube.map((colorIdx, segIdx) => {
                const color = COLORS[colorIdx];
                return (
                  <div
                    key={segIdx}
                    style={{
                      backgroundColor: color.hex,
                      boxShadow: `0 0 12px ${color.glow}`,
                    }}
                    className={`w-full h-10 sm:h-11 transition-all duration-300 relative ${
                      segIdx === 0 ? 'rounded-b-2xl' : ''
                    } ${segIdx === tube.length - 1 ? 'rounded-t-sm' : ''}`}
                  >
                    {/* Water shine wave */}
                    <div className="absolute inset-0 bg-gradient-to-r from-white/30 via-transparent to-black/20" />
                  </div>
                );
              })}

              {/* Empty placeholder spaces */}
              {Array.from({ length: TUBE_CAPACITY - tube.length }).map((_, emptyIdx) => (
                <div key={`empty-${emptyIdx}`} className="w-full h-10 sm:h-11 opacity-0" />
              ))}

              {isComplete && (
                <div className="absolute -bottom-2 bg-emerald-500 text-slate-950 rounded-full p-0.5 shadow-sm">
                  <CheckCircle2 className="w-4 h-4" />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Win Banner */}
      {isLevelCompleted && (
        <div className="w-full my-4 p-4 rounded-2xl bg-gradient-to-r from-emerald-900/80 via-teal-900/80 to-emerald-900/80 border border-emerald-500/50 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-right animate-bounce-short">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400">
              <Sparkles className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h4 className="font-black text-emerald-300 text-base sm:text-lg">
                رائع! تم حل اللغز بنجاح 🎉
              </h4>
              <p className="text-xs text-emerald-200/80">
                أحسنت الترتيب والفرز المنطقي للألوان!
              </p>
            </div>
          </div>
          <button
            onClick={handleNextLevel}
            className="px-6 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm cursor-pointer shadow-lg shadow-emerald-500/30 active:scale-95 transition-all"
          >
            المستوى التالي ➔
          </button>
        </div>
      )}

      {/* Control Buttons */}
      <div className="w-full flex items-center justify-center gap-3 mt-4 pt-4 border-t border-slate-800">
        <button
          onClick={handleUndo}
          disabled={history.length === 0 || isLevelCompleted}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-40 disabled:pointer-events-none border border-slate-700 text-slate-200 font-bold text-xs transition-all active:scale-95 cursor-pointer"
        >
          <Undo2 className="w-4 h-4" />
          <span>تراجع ({history.length})</span>
        </button>

        <button
          onClick={handleRestart}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 font-bold text-xs transition-all active:scale-95 cursor-pointer"
        >
          <RotateCcw className="w-4 h-4" />
          <span>إعادة المحاولة</span>
        </button>

        <button
          onClick={handleAddTube}
          disabled={tubes.length >= 10 || isLevelCompleted}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-purple-900/60 hover:bg-purple-800/80 border border-purple-500/40 text-purple-200 font-bold text-xs transition-all active:scale-95 cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>أنبوب إضافي</span>
        </button>
      </div>
    </div>
  );
};
