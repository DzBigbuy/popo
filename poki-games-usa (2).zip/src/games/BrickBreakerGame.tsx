import React, { useEffect, useRef, useState, useCallback } from 'react';
import { Play, RotateCcw, Heart, Sparkles, Trophy } from 'lucide-react';
import confetti from 'canvas-confetti';
import { sounds } from '../utils/audio';

interface BrickBreakerProps {
  onScoreUpdate: (score: number) => void;
  highScore: number;
}

interface Brick {
  x: number;
  y: number;
  width: number;
  height: number;
  color: string;
  points: number;
  intact: boolean;
}

interface Ball {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  alpha: number;
  size: number;
}

export const BrickBreakerGame: React.FC<BrickBreakerProps> = ({ onScoreUpdate, highScore }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGameOver, setIsGameOver] = useState(false);
  const [isWin, setIsWin] = useState(false);
  const [score, setScore] = useState(0);
  const [lives, setLives] = useState(3);
  const [level, setLevel] = useState(1);

  const paddleRef = useRef({ x: 160, width: 80, height: 12, speed: 7 });
  const ballsRef = useRef<Ball[]>([{ x: 200, y: 320, vx: 3.5, vy: -3.5, radius: 6 }]);
  const bricksRef = useRef<Brick[]>([]);
  const particlesRef = useRef<Particle[]>([]);
  const keysRef = useRef<{ left: boolean; right: boolean }>({ left: false, right: false });

  const BRICK_ROWS = 5;
  const BRICK_COLS = 8;
  const BRICK_COLORS = ['#ef4444', '#f97316', '#eab308', '#10b981', '#06b6d4'];

  const initBricks = useCallback(() => {
    const bricks: Brick[] = [];
    const brickWidth = 44;
    const brickHeight = 16;
    const padding = 5;
    const offsetTop = 40;
    const offsetLeft = 6;

    for (let r = 0; r < BRICK_ROWS; r++) {
      for (let c = 0; c < BRICK_COLS; c++) {
        bricks.push({
          x: c * (brickWidth + padding) + offsetLeft,
          y: r * (brickHeight + padding) + offsetTop,
          width: brickWidth,
          height: brickHeight,
          color: BRICK_COLORS[r % BRICK_COLORS.length],
          points: (BRICK_ROWS - r) * 10,
          intact: true,
        });
      }
    }
    bricksRef.current = bricks;
  }, []);

  const createParticles = (x: number, y: number, color: string) => {
    for (let i = 0; i < 8; i++) {
      particlesRef.current.push({
        x,
        y,
        vx: (Math.random() - 0.5) * 6,
        vy: (Math.random() - 0.5) * 6,
        color,
        alpha: 1,
        size: Math.random() * 3 + 1,
      });
    }
  };

  const startGame = () => {
    paddleRef.current = { x: 160, width: 80, height: 12, speed: 7 };
    ballsRef.current = [{ x: 200, y: 320, vx: 3.5, vy: -3.5, radius: 6 }];
    particlesRef.current = [];
    setScore(0);
    setLives(3);
    setIsGameOver(false);
    setIsWin(false);
    initBricks();
    setIsPlaying(true);
    sounds.playClick();
  };

  // Paddle control by mouse / touch
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const relativeX = e.clientX - rect.left;
    const scale = canvas.width / rect.width;
    const paddleX = relativeX * scale - paddleRef.current.width / 2;
    paddleRef.current.x = Math.max(0, Math.min(canvas.width - paddleRef.current.width, paddleX));
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas || !e.touches[0]) return;
    const rect = canvas.getBoundingClientRect();
    const relativeX = e.touches[0].clientX - rect.left;
    const scale = canvas.width / rect.width;
    const paddleX = relativeX * scale - paddleRef.current.width / 2;
    paddleRef.current.x = Math.max(0, Math.min(canvas.width - paddleRef.current.width, paddleX));
  };

  // Keyboard controls
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (['ArrowLeft', 'KeyA'].includes(e.code)) keysRef.current.left = true;
      if (['ArrowRight', 'KeyD'].includes(e.code)) keysRef.current.right = true;
      if (e.code === 'Space' && !isPlaying) startGame();
    };
    const onKeyUp = (e: KeyboardEvent) => {
      if (['ArrowLeft', 'KeyA'].includes(e.code)) keysRef.current.left = false;
      if (['ArrowRight', 'KeyD'].includes(e.code)) keysRef.current.right = false;
    };
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
    };
  }, [isPlaying]);

  // Main game loop
  useEffect(() => {
    if (!isPlaying) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;

    const update = () => {
      // Paddle keyboard movement
      const paddle = paddleRef.current;
      if (keysRef.current.left && paddle.x > 0) {
        paddle.x -= paddle.speed;
      }
      if (keysRef.current.right && paddle.x < canvas.width - paddle.width) {
        paddle.x += paddle.speed;
      }

      // Update balls
      ballsRef.current.forEach((ball, bIndex) => {
        ball.x += ball.vx;
        ball.y += ball.vy;

        // Wall collisions
        if (ball.x - ball.radius < 0) {
          ball.x = ball.radius;
          ball.vx = Math.abs(ball.vx);
          sounds.playHit();
        } else if (ball.x + ball.radius > canvas.width) {
          ball.x = canvas.width - ball.radius;
          ball.vx = -Math.abs(ball.vx);
          sounds.playHit();
        }

        if (ball.y - ball.radius < 0) {
          ball.y = ball.radius;
          ball.vy = Math.abs(ball.vy);
          sounds.playHit();
        }

        // Paddle collision
        const paddleY = canvas.height - 25;
        if (
          ball.y + ball.radius >= paddleY &&
          ball.y - ball.radius <= paddleY + paddle.height &&
          ball.x >= paddle.x &&
          ball.x <= paddle.x + paddle.width &&
          ball.vy > 0
        ) {
          // Calculate bounce angle based on hitting point on paddle
          const hitOffset = (ball.x - (paddle.x + paddle.width / 2)) / (paddle.width / 2);
          const maxAngle = Math.PI / 3;
          const bounceAngle = hitOffset * maxAngle;
          const speed = Math.sqrt(ball.vx * ball.vx + ball.vy * ball.vy);

          ball.vx = speed * Math.sin(bounceAngle);
          ball.vy = -speed * Math.cos(bounceAngle);
          sounds.playLaser();
        }

        // Brick collision
        bricksRef.current.forEach((brick) => {
          if (!brick.intact) return;

          if (
            ball.x + ball.radius > brick.x &&
            ball.x - ball.radius < brick.x + brick.width &&
            ball.y + ball.radius > brick.y &&
            ball.y - ball.radius < brick.y + brick.height
          ) {
            brick.intact = false;
            ball.vy = -ball.vy;
            createParticles(brick.x + brick.width / 2, brick.y + brick.height / 2, brick.color);
            sounds.playCoin();

            setScore((prev) => {
              const newScore = prev + brick.points;
              onScoreUpdate(newScore);
              return newScore;
            });
          }
        });

        // Ball bottom fall (lose life)
        if (ball.y - ball.radius > canvas.height) {
          ballsRef.current.splice(bIndex, 1);
        }
      });

      // Check if all balls lost
      if (ballsRef.current.length === 0) {
        setLives((prev) => {
          const nextLives = prev - 1;
          if (nextLives <= 0) {
            setIsPlaying(false);
            setIsGameOver(true);
            sounds.playGameOver();
          } else {
            // Respawn ball
            ballsRef.current = [{ x: paddle.x + paddle.width / 2, y: canvas.height - 40, vx: 3.5, vy: -3.5, radius: 6 }];
          }
          return nextLives;
        });
      }

      // Check win condition
      const remainingBricks = bricksRef.current.filter((b) => b.intact);
      if (remainingBricks.length === 0 && bricksRef.current.length > 0) {
        setIsPlaying(false);
        setIsWin(true);
        sounds.playWin();
        confetti({ particleCount: 100, spread: 80 });
      }

      // Update particles
      particlesRef.current.forEach((p, index) => {
        p.x += p.vx;
        p.y += p.vy;
        p.alpha -= 0.03;
        if (p.alpha <= 0) {
          particlesRef.current.splice(index, 1);
        }
      });

      // DRAWING
      ctx.fillStyle = '#060913';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw bricks
      bricksRef.current.forEach((b) => {
        if (!b.intact) return;
        ctx.save();
        ctx.fillStyle = b.color;
        ctx.shadowColor = b.color;
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.roundRect(b.x, b.y, b.width, b.height, 4);
        ctx.fill();

        // Highlight stripe
        ctx.fillStyle = 'rgba(255,255,255,0.2)';
        ctx.fillRect(b.x + 2, b.y + 2, b.width - 4, 3);
        ctx.restore();
      });

      // Draw paddle
      const paddleY = canvas.height - 25;
      ctx.save();
      ctx.fillStyle = '#ec4899';
      ctx.shadowColor = '#ec4899';
      ctx.shadowBlur = 14;
      ctx.beginPath();
      ctx.roundRect(paddle.x, paddleY, paddle.width, paddle.height, 6);
      ctx.fill();
      ctx.restore();

      // Draw balls
      ballsRef.current.forEach((ball) => {
        ctx.save();
        ctx.fillStyle = '#ffffff';
        ctx.shadowColor = '#38bdf8';
        ctx.shadowBlur = 12;
        ctx.beginPath();
        ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // Draw particles
      particlesRef.current.forEach((p) => {
        ctx.save();
        ctx.globalAlpha = p.alpha;
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      animId = requestAnimationFrame(update);
    };

    animId = requestAnimationFrame(update);
    return () => cancelAnimationFrame(animId);
  }, [isPlaying, initBricks, onScoreUpdate]);

  return (
    <div className="flex flex-col items-center justify-center w-full max-w-lg mx-auto select-none">
      {/* Header bar with stats */}
      <div className="flex items-center justify-between w-full mb-3 px-4 py-2.5 rounded-2xl bg-slate-900/90 border border-slate-800 backdrop-blur-md">
        <div className="flex items-center gap-3">
          <span className="text-pink-400 font-bold text-lg">Score: {score}</span>
          <div className="flex items-center gap-1">
            {Array.from({ length: 3 }).map((_, i) => (
              <Heart
                key={i}
                className={`w-4 h-4 ${i < lives ? 'text-red-500 fill-red-500' : 'text-slate-700'}`}
              />
            ))}
          </div>
        </div>
        <div className="flex items-center gap-1.5 text-slate-400 text-sm">
          <Trophy className="w-4 h-4 text-amber-400" />
          <span>Best:</span>
          <span className="font-bold text-white">{Math.max(score, highScore)}</span>
        </div>
      </div>

      {/* Canvas */}
      <div className="relative w-full aspect-[4/3] max-w-[400px] rounded-3xl overflow-hidden border-2 border-slate-800 shadow-2xl shadow-pink-950/30 bg-slate-950">
        <canvas
          ref={canvasRef}
          width={400}
          height={380}
          onMouseMove={handleMouseMove}
          onTouchMove={handleTouchMove}
          className="w-full h-full block cursor-none"
        />

        {/* Start / Game Over / Win Overlay */}
        {(!isPlaying || isGameOver || isWin) && (
          <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-10">
            {isWin ? (
              <div className="space-y-4">
                <div className="w-16 h-16 mx-auto rounded-3xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-3xl text-emerald-400 animate-bounce">
                  🏆
                </div>
                <h3 className="text-2xl font-black text-white">Victory! All Bricks Smashed!</h3>
                <p className="text-slate-300 text-sm">
                  Total Score: <span className="font-black text-pink-400 text-base">{score}</span>
                </p>
                <button
                  onClick={startGame}
                  className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-400 text-white font-black shadow-xl shadow-pink-500/30 flex items-center gap-2 mx-auto transition-all active:scale-95 cursor-pointer text-sm"
                >
                  <RotateCcw className="w-4 h-4" />
                  Play Next Round
                </button>
              </div>
            ) : isGameOver ? (
              <div className="space-y-4">
                <div className="w-16 h-16 mx-auto rounded-3xl bg-red-500/20 border border-red-500/40 flex items-center justify-center text-3xl text-red-400">
                  💥
                </div>
                <h3 className="text-2xl font-black text-white">Ball Lost! Game Over</h3>
                <p className="text-slate-300 text-sm">
                  Final Score: <span className="font-black text-pink-400 text-base">{score}</span>
                </p>
                <button
                  onClick={startGame}
                  className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-400 text-white font-black shadow-xl shadow-pink-500/30 flex items-center gap-2 mx-auto transition-all active:scale-95 cursor-pointer text-sm"
                >
                  <RotateCcw className="w-4 h-4" />
                  Try Again
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="w-16 h-16 mx-auto rounded-3xl bg-pink-500/20 border border-pink-500/40 flex items-center justify-center text-3xl text-pink-400 animate-pulse">
                  🧱
                </div>
                <div>
                  <h3 className="text-2xl font-black text-white mb-1">Neon Brick Breaker</h3>
                  <p className="text-xs text-slate-400">Control the paddle and smash through colorful brick layers</p>
                </div>
                <button
                  onClick={startGame}
                  className="px-8 py-3.5 rounded-2xl bg-gradient-to-r from-pink-500 to-rose-600 hover:from-pink-400 text-white font-black shadow-xl shadow-pink-500/30 flex items-center gap-2 mx-auto transition-all active:scale-95 cursor-pointer text-base"
                >
                  <Play className="w-5 h-5 fill-current" />
                  START GAME
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      <div className="mt-3 text-xs text-slate-400 text-center">
        💡 Move your mouse or drag on touch screen to control the paddle
      </div>
    </div>
  );
};
