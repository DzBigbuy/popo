import { GameCategory } from '../types';

export interface CategoryTheme {
  id: GameCategory;
  label: { ar: string; en: string };
  emoji: string;
  tagline: { ar: string; en: string };
  // Tab Styling
  tabActive: string;
  tabInactive: string;
  badgeActive: string;
  badgeInactive: string;
  // Page Atmosphere
  pageBg: string;
  pageRadial: string;
  isDarkTheme: boolean;
  textColor: string;
  // Card Glow & Borders
  cardBorder: string;
  cardHoverBorder: string;
  cardHoverShadow: string;
  cardTitleHoverBg: string;
  cardTitleHoverBorder: string;
  // Header and Search bar styling
  headerBg: string;
  headerBorder: string;
  searchBorder: string;
  searchFocusRing: string;
  searchIconColor: string;
  // Primary Color
  accentColor: string;
}

export const CATEGORY_THEMES: Record<GameCategory, CategoryTheme> = {
  all: {
    id: 'all',
    label: { ar: 'الكل (جميع الألعاب)', en: 'All Games' },
    emoji: '🕹️',
    tagline: { ar: 'أكبر تشكيلة ألعاب مجانية وممتعة بدون تحميل', en: 'The ultimate arcade library' },
    tabActive: 'bg-gradient-to-r from-purple-600 via-violet-600 to-indigo-600 border-purple-400 text-white shadow-lg shadow-purple-500/40 scale-[1.03]',
    tabInactive: 'bg-white/90 hover:bg-white border-purple-100 hover:border-purple-300 text-slate-700 hover:text-purple-700',
    badgeActive: 'bg-white/20 text-white',
    badgeInactive: 'bg-purple-100/90 text-purple-700',
    pageBg: '#ede6f6',
    pageRadial: 'radial-gradient(at 20% 20%, rgba(192, 132, 252, 0.22) 0, transparent 50%), radial-gradient(at 80% 80%, rgba(167, 139, 250, 0.25) 0, transparent 50%), radial-gradient(at 50% 10%, rgba(238, 242, 255, 0.4) 0, transparent 60%)',
    isDarkTheme: false,
    textColor: 'text-slate-800',
    cardBorder: 'border-purple-200/60',
    cardHoverBorder: 'hover:border-purple-500',
    cardHoverShadow: 'hover:shadow-purple-500/30',
    cardTitleHoverBg: 'group-hover:bg-purple-950/85',
    cardTitleHoverBorder: 'group-hover:border-purple-400/60',
    headerBg: 'bg-[#f6f2fd]/90',
    headerBorder: 'border-purple-200/70',
    searchBorder: 'border-purple-200',
    searchFocusRing: 'focus:border-purple-500 focus:ring-purple-400/20',
    searchIconColor: 'text-purple-600',
    accentColor: '#9333ea',
  },

  girls: {
    id: 'girls',
    label: { ar: 'أزياء وبنات وتجميل', en: 'Girls & Fashion' },
    emoji: '👗',
    tagline: { ar: 'عالم الأناقة والموضة، التلبيس، المكياج وقصات الشعر الزاهية', en: 'Vibrant fashion, dress-up, makeup & salon games' },
    // Bright vivid pink & rose styling
    tabActive: 'bg-gradient-to-r from-pink-500 via-rose-500 to-fuchsia-500 border-pink-300 text-white shadow-lg shadow-pink-500/45 scale-[1.03] ring-1 ring-pink-400',
    tabInactive: 'bg-pink-50/90 hover:bg-pink-100/90 border-pink-200 hover:border-pink-400 text-pink-700 hover:text-pink-900',
    badgeActive: 'bg-white/25 text-white',
    badgeInactive: 'bg-pink-200/80 text-pink-800 font-extrabold',
    pageBg: '#fff0f6',
    pageRadial: 'radial-gradient(at 15% 15%, rgba(244, 114, 182, 0.35) 0, transparent 50%), radial-gradient(at 85% 85%, rgba(251, 113, 133, 0.3) 0, transparent 50%), radial-gradient(at 50% 10%, rgba(253, 231, 243, 0.6) 0, transparent 60%)',
    isDarkTheme: false,
    textColor: 'text-pink-950',
    cardBorder: 'border-pink-200/70',
    cardHoverBorder: 'hover:border-pink-400',
    cardHoverShadow: 'hover:shadow-pink-500/40',
    cardTitleHoverBg: 'group-hover:bg-pink-950/85',
    cardTitleHoverBorder: 'group-hover:border-pink-400/60',
    headerBg: 'bg-[#fff0f6]/95',
    headerBorder: 'border-pink-200/80',
    searchBorder: 'border-pink-200',
    searchFocusRing: 'focus:border-pink-500 focus:ring-pink-400/25',
    searchIconColor: 'text-pink-600',
    accentColor: '#ec4899',
  },

  racing: {
    id: 'racing',
    label: { ar: 'سيارات وسباقات', en: 'Cars & Racing' },
    emoji: '🏎️',
    tagline: { ar: 'سرعة قصوى، سباقات شوارع، دريفت وتحديات قيادة احترافية', en: 'High-octane highway racing, speed & drift challenges' },
    // Dark intense asphalt, carbon & fierce fiery red
    tabActive: 'bg-gradient-to-r from-red-600 via-zinc-950 to-red-800 border-red-500 text-white shadow-lg shadow-red-600/50 scale-[1.03] ring-1 ring-red-500/60',
    tabInactive: 'bg-zinc-900/90 hover:bg-zinc-800 border-zinc-700 hover:border-red-500/60 text-zinc-300 hover:text-red-400',
    badgeActive: 'bg-red-500 text-white',
    badgeInactive: 'bg-zinc-800 text-red-400 border border-zinc-700',
    pageBg: '#0e0f14',
    pageRadial: 'radial-gradient(at 15% 15%, rgba(220, 38, 38, 0.35) 0, transparent 50%), radial-gradient(at 85% 85%, rgba(249, 115, 22, 0.25) 0, transparent 50%), radial-gradient(at 50% 10%, rgba(30, 41, 59, 0.6) 0, transparent 60%)',
    isDarkTheme: true,
    textColor: 'text-zinc-100',
    cardBorder: 'border-zinc-800',
    cardHoverBorder: 'hover:border-red-500',
    cardHoverShadow: 'hover:shadow-red-600/50',
    cardTitleHoverBg: 'group-hover:bg-red-950/90',
    cardTitleHoverBorder: 'group-hover:border-red-500/70',
    headerBg: 'bg-[#111218]/95',
    headerBorder: 'border-zinc-800',
    searchBorder: 'border-zinc-700',
    searchFocusRing: 'focus:border-red-500 focus:ring-red-500/30',
    searchIconColor: 'text-red-500',
    accentColor: '#ef4444',
  },

  action: {
    id: 'action',
    label: { ar: 'أكشن وحروب', en: 'Action & Combat' },
    emoji: '💥',
    tagline: { ar: 'معارك قتالية، إطلاق نار، استراتيجيات حربية ومواجهات ملحمية', en: 'Explosive combat, shooting, wars and heroic battles' },
    // Fiery Amber & Orange explosion
    tabActive: 'bg-gradient-to-r from-orange-600 via-amber-600 to-red-600 border-orange-400 text-white shadow-lg shadow-orange-600/40 scale-[1.03]',
    tabInactive: 'bg-orange-50/90 hover:bg-orange-100 border-orange-200 hover:border-orange-400 text-orange-800 hover:text-orange-950',
    badgeActive: 'bg-white/20 text-white',
    badgeInactive: 'bg-orange-200/80 text-orange-900',
    pageBg: '#fef5ee',
    pageRadial: 'radial-gradient(at 20% 20%, rgba(249, 115, 22, 0.28) 0, transparent 50%), radial-gradient(at 80% 80%, rgba(239, 68, 68, 0.25) 0, transparent 50%), radial-gradient(at 50% 10%, rgba(254, 243, 199, 0.5) 0, transparent 60%)',
    isDarkTheme: false,
    textColor: 'text-amber-950',
    cardBorder: 'border-orange-200/70',
    cardHoverBorder: 'hover:border-orange-500',
    cardHoverShadow: 'hover:shadow-orange-500/40',
    cardTitleHoverBg: 'group-hover:bg-orange-950/85',
    cardTitleHoverBorder: 'group-hover:border-orange-400/60',
    headerBg: 'bg-[#fef5ee]/95',
    headerBorder: 'border-orange-200/80',
    searchBorder: 'border-orange-200',
    searchFocusRing: 'focus:border-orange-500 focus:ring-orange-400/25',
    searchIconColor: 'text-orange-600',
    accentColor: '#f97316',
  },

  adventure: {
    id: 'adventure',
    label: { ar: 'مغامرات وأوبي', en: 'Adventure & Obby' },
    emoji: '🏃',
    tagline: { ar: 'تحديات الأوبي والباركور، القفز واستكشاف العوالم المجهولة', en: 'Thrilling Obby parkour, running and world exploration' },
    // Emerald & Cyan Jungle Adventure
    tabActive: 'bg-gradient-to-r from-emerald-500 via-teal-600 to-cyan-600 border-emerald-400 text-white shadow-lg shadow-emerald-500/40 scale-[1.03]',
    tabInactive: 'bg-emerald-50/90 hover:bg-emerald-100 border-emerald-200 hover:border-emerald-400 text-emerald-800 hover:text-emerald-950',
    badgeActive: 'bg-white/20 text-white',
    badgeInactive: 'bg-emerald-200/80 text-emerald-900',
    pageBg: '#eef9f5',
    pageRadial: 'radial-gradient(at 20% 20%, rgba(16, 185, 129, 0.28) 0, transparent 50%), radial-gradient(at 80% 80%, rgba(6, 182, 212, 0.25) 0, transparent 50%), radial-gradient(at 50% 10%, rgba(209, 250, 229, 0.5) 0, transparent 60%)',
    isDarkTheme: false,
    textColor: 'text-emerald-950',
    cardBorder: 'border-emerald-200/70',
    cardHoverBorder: 'hover:border-emerald-400',
    cardHoverShadow: 'hover:shadow-emerald-500/40',
    cardTitleHoverBg: 'group-hover:bg-emerald-950/85',
    cardTitleHoverBorder: 'group-hover:border-emerald-400/60',
    headerBg: 'bg-[#eef9f5]/95',
    headerBorder: 'border-emerald-200/80',
    searchBorder: 'border-emerald-200',
    searchFocusRing: 'focus:border-emerald-500 focus:ring-emerald-400/25',
    searchIconColor: 'text-emerald-600',
    accentColor: '#10b981',
  },

  two_player: {
    id: 'two_player',
    label: { ar: 'ألعاب لشخصين 2P', en: '2 Players' },
    emoji: '👥',
    tagline: { ar: 'تحديات ثنائية ومنافسات حماسية على نفس الجهاز مع أصدقائك', en: 'Head-to-head multiplayer duels on the same device' },
    // Electric Indigo & Purple duel
    tabActive: 'bg-gradient-to-r from-indigo-600 via-purple-600 to-blue-600 border-indigo-400 text-white shadow-lg shadow-indigo-500/40 scale-[1.03]',
    tabInactive: 'bg-indigo-50/90 hover:bg-indigo-100 border-indigo-200 hover:border-indigo-400 text-indigo-800 hover:text-indigo-950',
    badgeActive: 'bg-white/20 text-white',
    badgeInactive: 'bg-indigo-200/80 text-indigo-900',
    pageBg: '#edf1fc',
    pageRadial: 'radial-gradient(at 20% 20%, rgba(99, 102, 241, 0.28) 0, transparent 50%), radial-gradient(at 80% 80%, rgba(168, 85, 247, 0.25) 0, transparent 50%), radial-gradient(at 50% 10%, rgba(224, 231, 255, 0.5) 0, transparent 60%)',
    isDarkTheme: false,
    textColor: 'text-indigo-950',
    cardBorder: 'border-indigo-200/70',
    cardHoverBorder: 'hover:border-indigo-400',
    cardHoverShadow: 'hover:shadow-indigo-500/40',
    cardTitleHoverBg: 'group-hover:bg-indigo-950/85',
    cardTitleHoverBorder: 'group-hover:border-indigo-400/60',
    headerBg: 'bg-[#edf1fc]/95',
    headerBorder: 'border-indigo-200/80',
    searchBorder: 'border-indigo-200',
    searchFocusRing: 'focus:border-indigo-500 focus:ring-indigo-400/25',
    searchIconColor: 'text-indigo-600',
    accentColor: '#6366f1',
  },

  sports: {
    id: 'sports',
    label: { ar: 'رياضة وكرة قدم', en: 'Sports & Soccer' },
    emoji: '⚽',
    tagline: { ar: 'بطولات كرة القدم، ركلات الترجيح والمباريات الرياضية الحية', en: 'Championship soccer, penalty shootouts & dynamic athletic matches' },
    // Vibrant Grass Green & Stadium Pitch
    tabActive: 'bg-gradient-to-r from-green-600 via-lime-600 to-emerald-700 border-green-400 text-white shadow-lg shadow-green-600/40 scale-[1.03]',
    tabInactive: 'bg-green-50/90 hover:bg-green-100 border-green-200 hover:border-green-400 text-green-800 hover:text-green-950',
    badgeActive: 'bg-white/20 text-white',
    badgeInactive: 'bg-green-200/80 text-green-900',
    pageBg: '#f0f9ee',
    pageRadial: 'radial-gradient(at 20% 20%, rgba(34, 197, 94, 0.28) 0, transparent 50%), radial-gradient(at 80% 80%, rgba(132, 204, 22, 0.25) 0, transparent 50%), radial-gradient(at 50% 10%, rgba(220, 252, 231, 0.5) 0, transparent 60%)',
    isDarkTheme: false,
    textColor: 'text-green-950',
    cardBorder: 'border-green-200/70',
    cardHoverBorder: 'hover:border-green-500',
    cardHoverShadow: 'hover:shadow-green-500/40',
    cardTitleHoverBg: 'group-hover:bg-green-950/85',
    cardTitleHoverBorder: 'group-hover:border-green-400/60',
    headerBg: 'bg-[#f0f9ee]/95',
    headerBorder: 'border-green-200/80',
    searchBorder: 'border-green-200',
    searchFocusRing: 'focus:border-green-500 focus:ring-green-400/25',
    searchIconColor: 'text-green-600',
    accentColor: '#22c55e',
  },

  cooking: {
    id: 'cooking',
    label: { ar: 'طبخ ومطاعم', en: 'Cooking & Food' },
    emoji: '🍳',
    tagline: { ar: 'إعداد أشهى الأطباق والحلويات وإدارة أشهر المطابخ العالمية', en: 'Master chefs, baking cakes, restaurant management & tasty recipes' },
    // Warm Honey, Tangerine & Caramel
    tabActive: 'bg-gradient-to-r from-amber-500 via-orange-500 to-yellow-500 border-amber-300 text-white shadow-lg shadow-amber-500/40 scale-[1.03]',
    tabInactive: 'bg-amber-50/90 hover:bg-amber-100 border-amber-200 hover:border-amber-400 text-amber-800 hover:text-amber-950',
    badgeActive: 'bg-white/20 text-white',
    badgeInactive: 'bg-amber-200/80 text-amber-900',
    pageBg: '#fef8ee',
    pageRadial: 'radial-gradient(at 20% 20%, rgba(245, 158, 11, 0.28) 0, transparent 50%), radial-gradient(at 80% 80%, rgba(251, 146, 60, 0.25) 0, transparent 50%), radial-gradient(at 50% 10%, rgba(254, 243, 199, 0.5) 0, transparent 60%)',
    isDarkTheme: false,
    textColor: 'text-amber-950',
    cardBorder: 'border-amber-200/70',
    cardHoverBorder: 'hover:border-amber-400',
    cardHoverShadow: 'hover:shadow-amber-500/40',
    cardTitleHoverBg: 'group-hover:bg-amber-950/85',
    cardTitleHoverBorder: 'group-hover:border-amber-400/60',
    headerBg: 'bg-[#fef8ee]/95',
    headerBorder: 'border-amber-200/80',
    searchBorder: 'border-amber-200',
    searchFocusRing: 'focus:border-amber-500 focus:ring-amber-400/25',
    searchIconColor: 'text-amber-600',
    accentColor: '#f59e0b',
  },

  puzzle: {
    id: 'puzzle',
    label: { ar: 'ألغاز وذكاء', en: 'Puzzles & Brain' },
    emoji: '🧠',
    tagline: { ar: 'تحديات منطقية، فرز ألوان، بازل جواهر وتدريب العقل والذاكرة', en: 'Brain teasers, water sorting, block jewels and logic riddles' },
    // Electric Cyan & High-tech Teal
    tabActive: 'bg-gradient-to-r from-cyan-500 via-blue-600 to-teal-500 border-cyan-300 text-white shadow-lg shadow-cyan-500/40 scale-[1.03]',
    tabInactive: 'bg-cyan-50/90 hover:bg-cyan-100 border-cyan-200 hover:border-cyan-400 text-cyan-800 hover:text-cyan-950',
    badgeActive: 'bg-white/20 text-white',
    badgeInactive: 'bg-cyan-200/80 text-cyan-900',
    pageBg: '#edf8fa',
    pageRadial: 'radial-gradient(at 20% 20%, rgba(6, 182, 212, 0.28) 0, transparent 50%), radial-gradient(at 80% 80%, rgba(59, 130, 246, 0.25) 0, transparent 50%), radial-gradient(at 50% 10%, rgba(207, 250, 254, 0.5) 0, transparent 60%)',
    isDarkTheme: false,
    textColor: 'text-cyan-950',
    cardBorder: 'border-cyan-200/70',
    cardHoverBorder: 'hover:border-cyan-400',
    cardHoverShadow: 'hover:shadow-cyan-500/40',
    cardTitleHoverBg: 'group-hover:bg-cyan-950/85',
    cardTitleHoverBorder: 'group-hover:border-cyan-400/60',
    headerBg: 'bg-[#edf8fa]/95',
    headerBorder: 'border-cyan-200/80',
    searchBorder: 'border-cyan-200',
    searchFocusRing: 'focus:border-cyan-500 focus:ring-cyan-400/25',
    searchIconColor: 'text-cyan-600',
    accentColor: '#06b6d4',
  },

  classic: {
    id: 'classic',
    label: { ar: 'ألعاب كلاسيكية', en: 'Retro & Classics' },
    emoji: '🏆',
    tagline: { ar: 'ألعاب الأركيد والزمن الجميل، تتريس، ثعبان، بونغ و2048', en: 'Legendary nostalgic retro arcade masterpieces' },
    // Retro Gold & Arcade Amber
    tabActive: 'bg-gradient-to-r from-yellow-500 via-amber-600 to-orange-600 border-yellow-300 text-white shadow-lg shadow-yellow-500/40 scale-[1.03]',
    tabInactive: 'bg-yellow-50/90 hover:bg-yellow-100 border-yellow-200 hover:border-yellow-400 text-yellow-800 hover:text-yellow-950',
    badgeActive: 'bg-white/20 text-white',
    badgeInactive: 'bg-yellow-200/80 text-yellow-900',
    pageBg: '#fbf7ee',
    pageRadial: 'radial-gradient(at 20% 20%, rgba(234, 179, 8, 0.28) 0, transparent 50%), radial-gradient(at 80% 80%, rgba(217, 119, 6, 0.25) 0, transparent 50%), radial-gradient(at 50% 10%, rgba(254, 240, 138, 0.5) 0, transparent 60%)',
    isDarkTheme: false,
    textColor: 'text-amber-950',
    cardBorder: 'border-yellow-200/70',
    cardHoverBorder: 'hover:border-yellow-400',
    cardHoverShadow: 'hover:shadow-yellow-500/40',
    cardTitleHoverBg: 'group-hover:bg-amber-950/85',
    cardTitleHoverBorder: 'group-hover:border-yellow-400/60',
    headerBg: 'bg-[#fbf7ee]/95',
    headerBorder: 'border-yellow-200/80',
    searchBorder: 'border-yellow-200',
    searchFocusRing: 'focus:border-yellow-500 focus:ring-yellow-400/25',
    searchIconColor: 'text-yellow-600',
    accentColor: '#eab308',
  },
};
